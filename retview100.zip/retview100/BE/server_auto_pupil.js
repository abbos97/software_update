require("./device_ip_connect.js");
const express = require("express");
const app = express();
const db = require("../database/dbInterface.js");
const serialport = require("../serialport/serialport.js");
const { port, setListener, write } = require("../serialport/serialport.js");
// const https = require("https");
const { https: httpsFR } = require("follow-redirects");
const cors = require("cors");
const mysql = require("mysql");

const WebSocket = require("ws");
const wss = new WebSocket.Server({ port: 8080 });
const fs = require("fs");
const path2 = require("path");
const session = require("express-session");

const fse = require("fs-extra");
const unzipper = require("unzipper");

const formidable = require("formidable");
const closeProgram = (callback) => {
  db.query('update processid set id="0" where name="el"', (err, result) => {
    callback(result);
  });
};

const { exec } = require("child_process");
const { execSync } = require("child_process");

// 23-09-05 add s by mclee : GRR Mode Implement
const { spawn } = require("child_process");
// 23-09-05 add e by mclee : GRR Mode Implement
const fsp = require("fs").promises; // fs.promises 사용

const util = require("util");
const execAsync = util.promisify(exec); // exec → Promise 기반으로 변환

const imgPathDir = "/home/nvidia/i-view100/CAP";
//const work_dir = '/home/nvidia/Workspace/server';	// add for NodeJS 실행화일 (2024/04/30)
const work_dir = "/home/nvidia/Workspace/server"; // add for NodeJS 실행화일 (2024/04/30)
//const work_dir = '/media/nvidia/sd_card';
const destinationPath = "/home/nvidia/i-view100/preview_images";
const capture_pngPath = "/home/nvidia/i-view100/CAP/capture.png";
const cp_org_pngPath = "/home/nvidia/i-view100/CAP/capture_org.png";

const maxImages = 8;

app.use(
  session({
    secret: "123456789",
    resave: false,
    saveUninitialized: true,
  })
);
app.use("/captured-img-for-preview", express.static(imgPathDir));
app.use("/captured-img-for-preview", express.static(destinationPath));

const maxImgGammaPath = "/home/nvidia/i-view100/max_img_0911";

app.get("/captured-img-for-preview", async (req, res) => {
  log(`====/captured-img-for-preview Start  ====`);

  //	await Node_sleep(1800);
  await Node_sleep(1000);

  fs.readdir(imgPathDir, async (err, files) => {
    if (err) {
      console.log("ERROR reading directory:", err);
      return res.status(500).json({ error: "Internal Server Error" });
    }

    const imgFiles = files.filter((file) => file === "capture.png");
    //const imgFiles = files.filter((file) => file === 'capture.jpg');

    if (!fs.existsSync(destinationPath)) {
      fs.mkdirSync(destinationPath);
    }
    log(`====/captured-img-for-preview proce 1  ====`);

    for (let i = 0; i < imgFiles.length; i++) {
      const file = imgFiles[i];
      const sourceFile = path2.join(imgPathDir, file);
      const fType = path2.extname(file);
      const newName = `img_${Date.now()}_${i + 1}${fType}`;
      const destinationFile = path2.join(destinationPath, newName);
      console.log("NewFileName :", sourceFile, destinationFile);

      log(`====/captured-img-for-preview proce 1-1  ====`);

      const cpcommand = `cp ${sourceFile} ${destinationFile}`;

      await new Promise((resolve, reject) => {
        exec(cpcommand, (error, stdout, stderr) => {
          if (error) {
            console.error(`Error during file backup: ${error.message}`);
            reject(error);
            return;
          }
          if (stderr) {
            console.error(`cp stderr: ${stderr}`);
          }
          console.log("Backup completed.");
          resolve();
        });
      });
      log(`====/captured-img-for-preview proce 1-2  ====`);
    }
    log(`====/captured-img-for-preview proce 2  ====`);

    const filesInDestination = await fs.promises.readdir(destinationPath);
    const sortedFiles = filesInDestination
      .map((file) => ({
        file,
        ctime: fs.statSync(path2.join(destinationPath, file)).ctime,
      }))
      .sort((a, b) => b.ctime.getTime() - a.ctime.getTime());

    const filesToDelete = sortedFiles.slice(maxImages);
    log(`====/captured-img-for-preview proce 3  ====`);

    for (const { file } of filesToDelete) {
      const filePath = path2.join(destinationPath, file);
      await fs.promises.unlink(filePath).catch((err) => {
        console.log(`Error deleting ${file}:`, err);
      });
    }
    log(`====/captured-img-for-preview proce 4  ====`);
    const imgUrls = sortedFiles
      .slice(0, maxImages)
      .map(({ file }) => `/captured-img-for-preview/${file}`);
    res.status(200).json({ images: imgUrls.reverse() });

    log(`====/captured-img-for-preview proce 5  ====`);

    /*
                  console.log('copy  start.');
		  const cp_org_command = `cp ${capture_pngPath} ${cp_org_pngPath}`;

                  await new Promise((resolve, reject) => {
                          exec(cp_org_command, (error, stdout, stderr) => {
                                  if (error) {
                                          console.error(`Error during file copy: ${error.message}`);
                                          reject(error);
                                          return;
                                  }
                                  if (stderr) {
                                          console.error(`copy stderr: ${stderr}`);
                                  }
                                  console.log('copy  completed.');
                                  resolve();
                          });
                  });
                  console.log('copy End.');
		  */

    console.log("remove  start.");
    const rmcommand = `rm -f ${capture_pngPath}`;
    console.log("remove  start. rmcommand", rmcommand);

    await new Promise((resolve, reject) => {
      exec(rmcommand, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error during file delete: ${error.message}`);
          reject(error);
          return;
        }
        if (stderr) {
          console.error(`cp stderr: ${stderr}`);
        }
        console.log("remove  completed.");
        resolve();
      });
    });
    log(`/captured-img-for-preview End`);
  });
  //await Node_sleep(1000);
  //serialport.write('YSZM51');
});

app.delete("/captured-img-for-preview/:index", (req, res) => {
  const { index } = req.params;
  const indexToDelete = parseInt(index, 10);
  console.log(
    `=================== captured-img-for-preview/:index ======================`
  );
  fs.readdir(destinationPath, (err, files) => {
    if (err) {
      console.log(`Error reading copy image file ${destinationPath}`);
      return res.status(500).json({ error: "Invalid index" });
    }
    if (index < 0 || index >= files.length) {
      return res.status(400).json({ error: "Invalid index" });
    }

    const filetoDelete = files[index];
    const filePath = path2.join(destinationPath, filetoDelete);
    fs.unlink(filePath, (err) => {
      if (err) {
        console.log(`Error deleting image ${filetoDelete}`);
        return res.status(500).json({ error: "Internal Server Error" });
      }
      console.log(`Delete ${filetoDelete} from ${destinationPath}`);
      res.json({ message: "Image deleted successfully" });
    });
  });
});

app.delete("/delete-all-images", async (req, res) => {
  console.log(`=================== delete-all-images ======================`);
  await deleteAllImagesFromPreview(res);
});

async function deleteAllImagesFromPreview(res) {
  fs.readdir(destinationPath, (err, files) => {
    if (err) {
      console.log(`Error reading image files from ${destinationPath}: ${err}`);
      return res.status(500).json({ error: `Internal server error` });
    }

    if (files === 0) {
      return res.json({ message: `No images to delete` });
    }

    files.forEach((file, index) => {
      const filePath = path2.join(destinationPath, file);
      fs.unlink(filePath, (err) => {
        if (err) {
          console.log(`Error deleting image ${file}`);
          return res.status(500).json({ error: "`Internal Server error" });
        }

        console.log(`Deleted ${file} from ${destinationPath}`);

        if (index === files.length - 1) {
          return res.json({ message: "All images deleted successfully" });
        }
      });
    });
  });
}

// 2025-09-15 by MAX =========================> start

const retview100_url =
  "https://github.com/abbos97/software_update/raw/main/retview100.zip";
const savePath = "/home/nvidia/Workspace/retview100.zip";
const FePath = "/home/nvidia/Workspace/app-build";
const BePath = "/home/nvidia/Workspace/server";

// downloader: auto-redirect + timeout + xatoda faylni tozalash
function downloadZip(url, dest, timeoutMs = 60000) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);
    const req = httpsFR.get(url, (res) => {
      if (res.statusCode !== 200) {
        file.close(() => fs.unlink(dest, () => {}));
        return reject(new Error(`Download failed: ${res.statusCode}`));
      }
      res.pipe(file);
      file.on("finish", () => file.close(resolve));
    });
    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error(`Download timeout after ${timeoutMs}ms`));
    });
    req.on("error", (err) => {
      file.close(() => fs.unlink(dest, () => {}));
      reject(err);
    });
  });
}

async function swapDir(targetBase, finalName, newDirSrc, stamp) {
  const final = path2.join(targetBase, finalName);
  const bak = `${final}_bak_${stamp}`;
  const incoming = path2.join(targetBase, `${finalName}_new_${stamp}`);

  await fse.ensureDir(targetBase);
  await fse.copy(newDirSrc, incoming, { overwrite: true, dereference: true });

  const existed = await fse.pathExists(final);
  if (existed) await fse.move(final, bak, { overwrite: true });

  await fse.move(incoming, final, { overwrite: true });
  if (await fse.pathExists(bak)) await fse.remove(bak);
}

async function swapFile(targetDir, finalName, newFileSrc, stamp) {
  const final = path2.join(targetDir, finalName);
  const bak = `${final}.bak_${stamp}`;
  const incoming = path2.join(targetDir, `${finalName}.new_${stamp}`);

  await fse.ensureDir(targetDir);
  await fse.copy(newFileSrc, incoming, { overwrite: true });
  await fse.chmod(incoming, 0o755);

  const existed = await fse.pathExists(final);
  if (existed) await fse.move(final, bak, { overwrite: true });

  await fse.move(incoming, final, { overwrite: true });
  if (await fse.pathExists(bak)) await fse.remove(bak);
}

app.post("/sw-update", async (req, res) => {
  const stamp = Date.now();
  const tmp = `/tmp/retview_${stamp}`;

  // butun operatsiya uchun “sigorta” timeout (masalan 2 daqiqa)
  const overallTimeout = setTimeout(() => {
    // Eslatma: bu faqat log; real abort uchun abort-controller kerak bo‘lardi.
    console.error("Update timeout: overall operation exceeded 120s");
  }, 120000);

  try {
    console.log("➡️  Download start");
    await downloadZip(retview100_url, savePath, 60000);
    console.log("✅ Download ok");

    console.log("➡️  Extract start");
    await fse.ensureDir(tmp);
    await fse
      .createReadStream(savePath)
      .pipe(unzipper.Extract({ path: tmp }))
      .promise();
    console.log("✅ Extract ok");

    const feBuildSrc = path2.join(tmp, "retview100", "FE", "build");
    const beBinSrc = path2.join(
      tmp,
      "retview100",
      "BE",
      "server_auto_pupil.js"
    );

    if (!(await fse.pathExists(feBuildSrc)))
      throw new Error("FE/build not found");
    if (!(await fse.pathExists(beBinSrc)))
      throw new Error("BE/server_auto_pupil-linux not found");

    console.log("➡️  FE swap");
    await swapDir(FePath, "build", feBuildSrc, stamp);
    console.log("✅ FE swap ok");

    console.log("➡️  BE swap");
    await swapFile(BePath, "server_auto_pupil-linux", beBinSrc, stamp);
    console.log("✅ BE swap ok");

    await fse.remove(tmp);

    clearTimeout(overallTimeout);

    await fse.remove(tmp);
    await fse.remove(savePath);

    return res.json({
      result: true,
      saved_to: savePath,
      fe_deployed_to: path2.join(FePath, "build"),
      be_deployed_to: path2.join(BePath, "server_auto_pupil-linux"),
    });
  } catch (err) {
    try {
      await fse.remove(tmp);
    } catch {}
    clearTimeout(overallTimeout);
    return res
      .status(500)
      .json({ result: false, error: err.message || String(err) });
  }
});

// app.post("/test-update",  (req, res) => {
//   const file = fs.createWriteStream(savePath);

//   https
//     .get(retview100_url, (response) => {
//       if (response.statusCode === 302 && response.headers.location) {
//         return https.get(response.headers.location, (res2) => {
//           res2.pipe(file);
//           file.on("finish", () => {
//             file.close(() => res.json({ ok: true, saved_to: savePath }));
//           });
//         });
//       }

//       if (response.statusCode !== 200) {
//         return res.status(500).json({
//           result: false,
//           error: "Download failed",
//           code: response.statusCode,
//         });
//       }

//       response.pipe(file);

//       file.on("finish", () => {
//         file.close(() => {

//           // TODO:

//           (async () => {
//             const stamp = Date.now()
//             const tmp = `/tmp/retview_${stamp}`

//             await fse.ensureDir(tmp)
//             await fse.createReadStream(savePath).pipe(unzipper.Extract({path: tmp})).promise()

//             const feBuildSrc = path2.join(tmp, "FE", "build");
//             const beBinSrc  = path2.join(tmp, "BE", `server_auto_pupil-linux`)

//             if(!(await fse.pathExists(feBuildSrc))) throw new Error("FE/build not found!")
//             if(!(await fse.pathExists(beBinSrc))) throw new Error("BE/server_auto_pupil-linux not found!")

//             async function swapDir(targetBase, finalName, newDirSrc) {
//               const final = path2.join(targetBase, finalName)
//               const bak = `${final}_bak_${stamp}`
//               const incoming = path2.join(targetBase, `${finalName}_new_${stamp}`)

//               await fse.ensureDir(targetBase)
//               await fse.copy(newDirSrc, incoming, {overwrite: true, dereference: true});
//               const existed = await fse.move(final, bak, {overwrite: true})
//               if(existed) await fse.move(final, bak, {overwrite: true})
//               await fse.move(incoming, final, {overwrite: true})
//               if(await fse.pathExists(bak)) await fse.remove(bak)
//             }

//             async function swapFile(targetDir, finalName, newFileSrc) {
//               const final = path2.join(targetDir, finalName)
//               const bak = `${final}.bak_${stamp}`
//               const incoming = path2.join(targetDir, `${finalName}.new_${stamp}`)

//               await fse.ensureDir(targetDir)
//               await fse.copy(newFileSrc, incoming, {overwrite: true})
//               await fse.chmod(incoming, 0o755)
//               const existed = await fse.pathExists(final)
//               if(existed) await fse.move(final, bak, {overwrite: true})
//               await fse.move(incoming, final, {overwrite: true})
//               if(await fse.pathExists(bak)) await fse.remove(bak)
//             }

//             await swapDir(FePath, "build", feBuildSrc)

//             await swapFile(BePath, "server_auto_pupil-linux", beBinSrc)

//             await fse.remove(tmp)
//           })()

//           res.json({ result: true, saved_to: savePath });
//         });
//       });
//     })
//     .on("error", (err) => {
//       res
//         .status(500)
//         .json({ result: false, error: err.message, internet: false });
//     });
// });

// 2025-09-15 by MAX =========================> end

// TODO
const shutpassword = "0000";
app.post("/shutdown", (req, res) => {
  exec(
    `echo "${shutpassword}" | sudo -S shutdown -h now`,
    (error, stdout, stderr) => {
      if (error) {
        console.log(`Error: ${error.message}`);
        return res.status(500).send("Shutdown failed");
      }

      console.log("Devoce shutting down...");
      res.send("Shutting down...");
    }
  );
});

// 2023-03-28 by MAX =========================> end

const MAX_IMAGE_SZ = 8;

// 22-03-22 : OPER_HOME_DIR 매크로 변수 추가 및 명칭 "i-view100"으로 정의
// 운영 관련 모든 파일에 대한 상위 경로 지정하여 사용하도록 변경
// (이유 : 향후 계정변경이 발생하는 경우 최상위만 변경하면 편리해짐)
const OPER_HOME_DIR = "/home/nvidia/i-view100/";

// Jetson Nano Dev. Kit(B01) 에서는 user가 home
// const OPER_HOME_DIR = "/home/user/i-view100/"

// 22-04-05 add : sleep() 함수 구현
const userSleep = (ms) => {
  log(`==== userSleep Start ====`);
  console.log("userSleep Start ", ms);
  const wakeUpTime = Date.now() + ms;
  while (Date.now() < wakeUpTime) {}
};

// // 21-10-25
// const getToday = () => {
//   let d = new Date()
//   let y = d.getFullYear()
//   let m = d.getMonth() + 1
//   let dt = d.getDate()
//   m = (m < 10 ? `0${m}` : m)
//   dt = (dt < 10 ? `0${dt}` : dt)
//   return `${y}${m}${dt}`
// }

let BackLight_Time = 0;
let channel = undefined;
let debugChannel = undefined;
let debug = {
  send: (message) => {
    if (debugChannel && debugChannel.OPEN) {
      debugChannel.send(message);
    }
  },
};

//	let x_quotient = 0;		// Quotient 초기화

let wait_time = 0; // wait_time 초기화

let eye_position = "OD";
let S1_received = 0;
let S2_received = 0;
let AutoFocusProc = 0;
let Forward_cnt = 0;

let LWE_Data = 0;
//	let thres_Uniformity = 0;

let Auto_Loop_cnt = 0;
let Add_sum = 0; // Human Test org ; 1100

//	let bz_cnt = 0; // Human Test org ; 1100

let Auto_Retin_sts = 0;

let s1_cnt = 0;

let Auto_Status = 0;

wss.on("connection", function (ws) {
  setInterval(() => {
    //	ws.send('X')
  }, 1000 * 20);
  ws.onmessage = (e) => {
    console.log(e.data);
    if (e.data === "d") {
      if (debugChannel && debugChannel.OPEN) debugChannel.close();
      debugChannel = ws;
      debug.send("from server : debug open.");
    } else if (e.data === "a") {
      if (channel && channel.OPEN) channel.close();
      console.log("channel open");
      channel = ws;
    }
  };
  ws.onclose = () => {
    console.log("socket close");
  };
  ws.onerror = () => {
    console.log("socket error");
  };
});

app.use(cors());
app.use(express.json());
app.get("/*", (req, res) => {
  //	let path = `${__dirname}${req.originalUrl}`
  let path = `${work_dir}${req.originalUrl}`;
  if (req.originalUrl === "/") {
    //      path = `${__dirname}/index.html`
    path = `${work_dir}/index.html`;
  }
  res.sendFile(`${path}`, (err) => {
    if (err) {
      res.end("");
    }
  });
});

app.post("/test-send", (req, res) => {
  console.log("to app from serial : " + req.body.message);
  channel.send(req.body.message);
  res.json({ message: "success" });
});

app.post("/api/logs", (req, res) => {
  const { message } = req.body;
  console.log(
    "======================= REACT LOGS start ========================="
  );
  console.log(message);
  console.log(
    "======================= REACT LOGS end ========================="
  );
  res.json({ success: true });
});

function autoTrackWrite(message) {
  const at_path = OPER_HOME_DIR + "auto_track.dat";
  console.log(at_path);

  // Read the existing content of the file.
  fs.promises
    .readFile(at_path, "utf8")
    .then((existingData) => {
      // Split the existing data into lines.
      const lines = existingData.split("\n");

      // Create a map to store the data.
      const dataMap = new Map();

      // Copy the existing data into the map, including comments.
      for (const line of lines) {
        if (!line.startsWith("#")) {
          const [key, value] = line.split(" ");
          if (key && value) {
            dataMap.set(key, value);
          }
        }
      }
      // Update the new data values from the message.
      if (message.up) {
        dataMap.set("U", message.up);
      }
      if (message.right) {
        dataMap.set("R", message.right);
      }
      if (message.down) {
        dataMap.set("D", message.down);
      }
      if (message.left) {
        dataMap.set("L", message.left);
      }
      // Reconstruct the updated content with comments.
      let updatedContent = lines
        .filter((line) => line.startsWith("#"))
        .join("\n"); // Retain comments
      updatedContent +=
        "\n" +
        Array.from(dataMap)
          .map(([key, value]) => `${key} ${value}`)
          .join("\n"); // Add updated data
      // Write the updated data back to the file.
      return fs.promises.writeFile(at_path, updatedContent, "utf8");
    })
    .then(() => {
      console.log("Data saved successfully");
    })
    .catch((err) => {
      console.log("Error writing to auto track file:", err);
    });

  return message;
}

// 2023-09-21 add end for save auto track data values by Max

// 21-10-20 save led setting values
async function ledSetWrite(message) {
  console.log("ledSetWrite");
  var writeData;
  var ledType = "L" + `${message.ledType}`;
  var saveData =
    "L" +
    `${message.ledType}` +
    " " +
    `${message.brightness}` +
    " " +
    `${message.testMode}` +
    " " +
    `${message.testValue}` +
    " " +
    `${message.testFixPosition}` +
    " " +
    message.wruntime +
    " " +
    message.wshoottime +
    " " +
    message.wdelaytime;

  const path = OPER_HOME_DIR + "led_set.dat";
  console.log(path);

  fs.readFile(path, "utf8", (err, result) => {
    if (err) {
      console.error(err);
      return;
    }
    var rowData = result.toString().split("\n");
    for (i in rowData) {
      // console.log(rowData[i], i);
      if (ledType == rowData[i].split(" ")[0]) {
        rowData[i] = saveData;
      }
    }

    for (i = 0; i < 4; i++) {
      if (i == 0) writeData = rowData[i] + "\n";
      else writeData += rowData[i] + "\n";
    }

    fs.writeFile(path, writeData, "utf8", (err) => {
      if (err) {
        console.error(err);
        return;
      }
    });
  });

  let wruntime = message.wruntime;
  console.log("wruntime1", wruntime);

  setTimeout(() => {
    updateCamParaDat(wruntime);
  }, 1000);
}

function updateCamParaDat(wruntime) {
  console.log("updateCamParaDat", wruntime);
  // 파일 경로
  const filePath = OPER_HOME_DIR + "cam_para.dat";

  fs.readFile(filePath, "utf8", (err, data) => {
    if (err) {
      console.error("파일을 읽을 수 없습니다.", err);
      return;
    }

    //		const updatedData = data.replace(/ID{0x0098091c};CHK{1:2500:1:380}=VAL\[(\d+)\]/, `ID{0x0098091c};CHK{1:2500:1:380}=VAL[${wruntime}]`);
    const updatedData = data.replace(
      /(ID{0x0098091c};CHK{1:2500:1:380}=VAL{)(\d+)(})/,
      `$1${wruntime}$3`
    );

    fs.writeFile(filePath, updatedData, "utf8", (err) => {
      if (err) {
        console.log("파일을 업데이트할 수 없습니다.", err);
      } else {
        console.log("파일이 업데이트되었습니다.");
      }
    });
  });
}

// 22-02-25 : Save shoot parameters
function saveShootParameters(delayTime) {
  console.log("saveShootParameters");
  const path = OPER_HOME_DIR + "shoot_parameter.dat";
  console.log(path);

  fs.writeFile(path, delayTime, "utf8", (err) => {
    if (err) {
      console.error(err);
      return;
    }
  });
}

// 22-02-25 : Load shoot parameters
app.post("/shoot_parameters", (req, res) => {
  console.log("shoot_parameters");
  const path = OPER_HOME_DIR + "shoot_parameter.dat";
  fs.readFile(path, "utf8", (err, result) => {
    if (err) {
      console.error(err);
      return;
    }
    //// console.log(result);
    res.json({ err, result: result });
  });
});

//2023-12-08 by MAX  ======== start
function controlCommadData(command) {
  const filePath = "/home/nvidia/i-view100/control_command_data.dat";
  fs.promises
    .readFile(filePath, "utf8")
    .then((existingData) => {
      const lines = existingData.split("\n");

      const dataMap = new Map();

      for (const line of lines) {
        if (!line.startsWith("#")) {
          const [key, value] = line.split(" ");
          if (key && value) {
            dataMap.set(key, value);
          }
        }
      }

      let numData = "";
      let strData = "";

      for (let i = 0; i < command.message.length; i++) {
        if (isNaN(command.message[i])) {
          strData += command.message[i];
        } else {
          numData += command.message[i];
        }
      }

      if (command.message) {
        dataMap.set(`${strData}`, numData);
      }

      let updatedContent = lines
        .filter((line) => line.startsWith("#"))
        .join("\n");

      updatedContent +=
        "\n" +
        Array.from(dataMap)
          .map(([key, value]) => `${key} ${value}`)
          .join("\n");

      controlData = updatedContent;
      return fs.promises.writeFile(filePath, updatedContent, "utf8");
      // .then(() => updatedContent); // Return the updatedContent
    })
    .then(() => {
      console.log("Data saved successfully");
      // return updatedContent; // Return the updatedContent
    })
    .catch((err) => {
      console.log("Error writing to control command data file:", err);
      throw err; // Propagate the error
    });

  return command.message;
}

app.post("/getDataFromControlCommand", (req, res) => {
  console.log("======== getDataFromControlCommand =======");
  const filePath = "/home/nvidia/i-view100/control_command_data.dat";

  fs.readFile(filePath, "utf8", (err, result) => {
    if (err) {
      console.log("ERROR getDataFromControlCommand ===>", err);
      return;
    }

    const controlData = result
      .toString()
      .split("/n")
      .filter((item) => !item.startsWith("#"));
    res.json({ err, data: controlData });
  });
});
//2023-12-08 by MAX  ======== end

// 22-02-18 : 'wdelaytime(IR Off->White LED On 유지 시간)' added
app.post("/buttonClick", async (req, res) => {
  let command = req.body;
  //serialport.write(command.message)
  console.log(`Receive Data from app(React) :`);
  console.log(command);
  console.log("===================================\n");
  console.log("RCV:" + command.message);

  if (typeof command.message === "object") {
    console.log("buttonClick_1");
    let msg = command.message;
    // change s for black color display by mclee(2025/0507)
    //	await ledSetWrite(msg);

    console.log("Org BackTime Rcv : ", BackLight_Time, msg.wruntime);

    if (msg.wruntime === "0000") {
      console.log(
        "Wrong BackLight_Time wruntime: ",
        BackLight_Time,
        msg.wruntime
      );
      msg.wruntime = BackLight_Time;
    }
    BackLight_Time = msg.wruntime;
    console.log("update BackLight_Time : ", BackLight_Time);
    await ledSetWrite(msg);

    //		BackLight_Time = msg.wruntime;
    // change e for black color display by mclee(2025/0507)
    console.log("Call to  setBacklightCompensation 01:");
    await setBacklightCompensation();

    console.log("update BackLight_Time : ", BackLight_Time);

    serialport.write(
      `L${msg.ledType}${msg.brightness}${msg.testMode}${msg.testValue}${msg.testFixPosition}${msg.wruntime}${msg.wshoottime}${msg.wdelaytime}`
    );
    debug.send(
      "from app : " +
        `${msg.ledType}${msg.brightness}${msg.testMode}${msg.testValue}${msg.testFixPosition}${msg.wruntime}${msg.wshoottime}${msg.wdelaytime}`
    );
  } else if (typeof command.message === "string") {
    console.log("2");
    const commandMap = {
      focus_plus: "MF+0003", // 21-10-18 0002 => 0020, 0020->0005(22-11-03)
      focus_minus: "MF-0003", // 0020->0005(22-11-03)
      move_forward: "MZ+0020",
      move_backward: "MZ-0020",
      //	move_backward:'MZ-0040',
      move_up: "MY+0010",
      move_down: "MY-0010",
      move_right: "MX+0005",
      move_left: "MX-0005",
      move_chin_up: "MC+0019",
      move_chin_down: "MC-0020",
      shoot_finish: "Z", // 22-02-15 : added
      shoot1: "S1",
      shoot2: "S2",
      "F+": "F+",
      F0: "F0",
      "F-": "F-",
      open_protector: "I",
      close_protector: "X",
      do_test: "A",
      stop_test: "a",
      J: "J",
    };

    // 22-02-25 added(s) : S2 이후 복귀 지연 시간 파싱 및 저장
    console.log(
      "S1_received, AutoFocusProc, S2_received",
      S1_received,
      AutoFocusProc,
      S2_received
    );

    if (command.message.includes("SHOOT_PARA")) {
      console.log("buttonClick_3");
      console.log("send command : " + "Shoot Parameters");
      var splitStr = command.message.split("SHOOT_PARA");
      console.log("delay time : " + splitStr[1]);
      saveShootParameters(splitStr[1]);
      return;
    }
    // 23-08-08 add(s) by mclee : Implementation of AutoTracking function in Aetina B'd
    else if (command.message.includes("AG")) {
      //	let centerX = 400;	 // LCD X 중심점 (800 x 600 기준)
      //	let centerY = 300;	 // LCD X 중심점 (800 x 600 기준)
      let centerX = 408; // LCD X 중심점 (800 x 600 기준)
      let centerY = 278; // LCD X 중심점 (800 x 600 기준)
      let distanceFromCenter = 0;
      let clicksPerPixel = 0; // 이동 클릭수 기준 (94 클릭을 400 픽셀로 나눔)
      let x_mv_cnt = 0;
      let y_mv_cnt = 0;

      console.log("RCV AG Auto Tracking Process");
      console.log(command.message);

      const pos_x = parseInt(command.message.substr(2, 3)); // 문자열을 정수로 변환
      const pos_y = parseInt(command.message.substr(5, 3)); // 문자열을 정수로 변환

      console.log("POS X : " + pos_x); // 출력: First part: 787
      console.log("POS Y : " + pos_y); // 출력: Second part: 581

      Main_AutoPupilSearch(pos_x, pos_y);
    }
    // 23-08-08 add e by mclee : Implementation of AutoTracking function in Aetina B'd

    // 24-03-07 add by mclee : AutoFocusng Function
    else if (
      command.message.includes("AG") &&
      S1_received === 1 &&
      AutoFocusProc === 0 &&
      S2_received === 0
    ) {
      // Auto Focusing Function

      AutoFocusProc = 1;
      log(`Start Auto Focsuing`);
      //	Main_AutoFocusProcess();
    }
    // 24-03-07 add by mclee : AutoFocusng Function
    else {
      console.log("buttonClick_4");
    }
    // 22-02-25 added(e)

    if (!commandMap[command.message]) {
      //23-08-25 change s by mclee : Auto Tracking
      if (!command.message.includes("AG")) {
        console.log("buttonClick_5");
        console.log("message", command);
        serialport.write(command.message);

        // 메시지가 'LE'로 시작하는지 확인
        if (command.message.startsWith("LE")) {
          // 정규 표현식을 사용하여 'LE' 뒤의 숫자 추출

          console.log("meassage:LE");
          const match = command.message.match(/LE(\d+)/);
          if (match) {
            LWE_Data = match[1]; // 'LE' 뒤의 숫자 추출
            Atuto_Retina_UniformityDataSeve();
            console.log("LE 뒤의 숫자:", LWE_Data); // 결과 출력
          } else {
            console.log("LE 패턴을 찾을 수 없습니다.");
          }
        }
        controlCommadData(command);
      }
      //23-08-25 change e by mclee : Auto Tracking
      //debug.send('from app : ' + command.message)
    } else {
      debug.send("from app : " + commandMap[command.message]);
      if (
        commandMap[command.message] === "MF+0003" ||
        commandMap[command.message] === "MF-0003"
      ) {
        console.log("buttonClick_7");

        for (let i = 0; i < 1; i++) {
          setTimeout(() => {
            serialport.write(commandMap[command.message]);
          }, 20);
        }
      } else {
        log(`==== Transfer message received from react to IF/FW ====`);
        //	console.log('Transfer message received from react to IF/FW')
        //	debug.send('from app : ' + commandMap[command.message])
        console.log("Receive Z Auto_Status", Forward_cnt, Auto_Status);
        if (commandMap[command.message] === "Z") {
          console.log("buttonClick_5 shoot_finish", Auto_Status, Add_sum);

          //	Auto_Status = 0;
          //	userSleep(20);

          if (Auto_Status === 5) {
            console.log("buttonClick_5-1 shoot_finish", Auto_Status, Add_sum);
            Add_sum = 0;
            AutoPupil_LI_Serial(0);
            userSleep(40);
            //	AutoPupil_LF_Serial(0);
          }
          console.log("buttonClick_5-1 shoot_finish", Auto_Status, Add_sum);
          //	userSleep(20);

          setTimeout(() => {
            console.log(
              "buttonClick_5-2 shoot_finish Auto_Status, Add_sum",
              Auto_Status,
              Add_sum
            );
            if (Auto_Status === 5) {
              Auto_Status = 0;
              Add_sum = 0;

              //	serialport.write('YSZM80');
              serialport.write("YSZM51");
              //	userSleep(40);
              AutoPupil_LF_Serial(0);

              userSleep(40);
            }
            S1_received = 0;
            S2_received = 0;
            AutoFocusProc = 0;
            //	serialport.write('YSZM80');
            //	userSleep(40);

            //	AutoPupil_LI_Serial(0);

            //	userSleep(100);
            //	AutoRecoveryCamData();
            //	userSleep(10);

            //	AutoPupil_LF_Serial(0);
            //	userSleep(1000);
            //	userSleep(10);

            //	extractLWValue();
            //	AutoPupil_LW_LE_ModifiedSerial();
            //	userSleep(30);
          }, 2000);
        }

        if (commandMap[command.message] === "S2") {
          if (AutoFocusProc === 1 || S2_received === 1) {
            console.log("If AutoFocusing is in progress, discard S2.  ");
          } else {
            S2_received = 1;
            console.log("If Also, AutoFocusing is in progress, discard S2.  ");
          }
        } else if (commandMap[command.message] === "S1") {
          serialport.write("YSZM0");
          userSleep(100);
          S1_received = 1;
          Add_sum = 0; // Human Test org ; 1100

          Auto_Status = 1;

          log(`=== Auto SHoot Start === `);
          console.log("LWE_Data, Auto_Loop_cnt ", LWE_Data, Auto_Loop_cnt);
          return;

          // white 비율계산시에는 IR이 켜지면 안됨. retina 파악이 완료되면 S1(SZM 1로 설정) 전송. 이후 IR이 켜지면서 AutoFocusing 처리
          // add e for auto retina search by mclee (2024/07/25)
        } else {
          serialport.write(commandMap[command.message]);
        }
      }
    }
  }
  res.json({ message: "get-success" });
});

// 2023-09-14 add start fot AutoTracking Data by Max
app.post("/btnClick", (req, res) => {
  try {
    let command = req.body;
    console.log(` Data from  from max :`);
    console.log("this is btnClick function => ", command);
    console.log("===================================\n");

    const message = command.message;
    const saveData = autoTrackWrite(message);
    res.json({ data: saveData });
  } catch (err) {
    console.log("error with btnClick: ", err.message);
  }
});

app.post("/getDataFromAutoTrack", (req, res) => {
  console.log("getDataFromAutoTrack=======");

  const path = OPER_HOME_DIR + "auto_track.dat";
  console.log(path);

  fs.readFile(path, "utf8", (err, result) => {
    if (err) {
      console.error(err);
      return;
    }

    //	const autoData = result.toString().split("\n");
    const autoData = result
      .toString()
      .split("\n")
      .filter((line) => !line.startsWith("#"));
    console.log(autoData);
    res.json({ err, result: autoData });
  });
});
// 2023-09-14 add end fot AutoTracking Data by Max

app.post("/program-close", (req, res) => {
  let command = req.body;
  log(command);
  res.json({ message: "get-success" });
  channel.close();
  closeProgram((result) => {
    console.log(result);
  });
});

// AI 테스트 처리용
app.post("/ai-request", (req, res) => {
  let form = formidable({ multiples: true });
  form.parse(req, (err, fields, files) => {
    if (err) {
      console.log(err);
      return;
    }
    let result = Math.random() * 5;
    res.end(`${Math.floor(result)}`);
  });
});

// 22-01-26 : Nodejs 버전업으로 인해 path대신 filepath를 사용
app.post("/upload", (req, res) => {
  console.log("/upload");
  //	let form = formidable({ multiples: true, uploadDir: `${__dirname}/images` })
  let form = formidable({ multiples: true, uploadDir: `${work_dir}/images` }); // change NodeJs 살향 화일 (2024/04/40)

  let dirExist = false;

  form.parse(req, (err, fields, files) => {
    if (err) {
      console.log(err);
      res.json({ message: "error" });
      return;
    } else {
      console.log("success");
      // 21-10-22 : 이미지 저장 폴더 이름 변경(이름_핸드폰번호)
      // 22-02-28 : dir에 상위 폴더로 "name-birthday"가 추가되었음
      // 22-03-14 : name -> patUUID

      // change NodeJs 살향 화일 (2024/04/40)
      ///	let dir = `${__dirname}/images/${fields.patUUID}-${fields.birthday}/${fields.checkUUID}`
      let dir = `${work_dir}/images/${fields.patUUID}-${fields.birthday}/${fields.checkUUID}`;

      fs.mkdir(`${dir}`, (err) => {
        if (err) {
          console.log(err);
          res.json({ result: "fail", message: "error" });
          return;
        } else {
          for (let number in files) {
            // console.log(`debug:${fields.phone}:${fields.birthday}:${fields.gender}:${fields.name}`)
            // 22-01-26 : 라즈베리파이는 path -> filepath (formdable의 버전이 2.x로 높아서 생기는 현상)
            //// console.log(`src : ${files[number].path}`)
            // 21-10-13 : 파일 확장자 jpeg->jpg
            //// console.log(`${dir}/${number}.jpg`)
            fs.copyFile(
              files[number].filepath,
              `${dir}/${number}.jpg`,
              (err) => {
                //		fs.copyFile(files[number].filepath, `${dir}/${number}.png`, (err) => {
                if (err) {
                  res.json({ result: "fail", err });
                  return;
                }
                fs.unlink(files[number].filepath, (err) => {
                  if (err) {
                    res.json({ result: "fail", err });
                    return;
                  }
                });
              }
            );
          }
          // 22-02-28 modified : parent->visit_log, phone 필드는 삭제
          // 22-03-14 patUUID added
          let sql =
            `insert into visit_log (checkUUID, birthday, gender, patUUID, name, leftResult, rightResult, imageSize, checkDate)` +
            ` values("${fields.checkUUID}", "${fields.birthday}", "${
              fields.gender
            }", "${fields.patUUID}",  
								"${fields.name}", ${fields.leftResult}, ${fields.rightResult}, ${
              Object.keys(files).length
            }, now());`;
          //// console.log(sql)
          db.query(sql, (err, result) => {
            if (err) {
              res.json({ result: "fail", err, fields, files });
            } else {
              res.json({ result: "success" });
            }
          });

          userSleep(20);

          // 22-04-05 : patUUID 필드 추가
          for (let idx = 0; idx < Object.keys(files).length; idx++) {
            let sql =
              `insert into disease (checkUUID, patUUID, name, imageIndex, dr, amd, glaucoma, eyePos)` +
              ` values("${fields.checkUUID}", "${fields.patUUID}", "${
                fields.name
              }", "${idx}", 0, 0, 0, "${fields.eyeData[idx * 2]}");`;
            //// console.log(sql)
            db.query(sql, (err, result) => {
              if (err) {
                console.log("disease row added Fail");
              } else {
                console.log("disease row added OK");
              }
            });
            userSleep(2);
          }

          for (let idx = 0; idx < fields.eyeData.length; idx += 2)
            console.log("eyeData" + idx + ":" + `${fields.eyeData[idx]}`);
        }
      });
    }
  });
});

// 사용자 로그인 체크(DB 접속)
// app.post('/user-login', (req, res) => {
// 	let user = req.body
// 	db.query(`select count(*) as count from user where id='${user.id}' and password='${user.password}'`, (err, result) => {
// 		if(err){
// 			res.json({result:'fail', message:err})
// 		}else{
// 			res.json({result:'success', message:result})
// 		}
// 	})
// })

// app.post('/lang-db', (req, res) => {
// 	const {lang} = req.body;
// 	// updateLanguage(lang)

// 	if(lang === "KOR" || lang === "ENG") {
// 		updateLanguage(lang)
// 	}

// 	const connection = mysql.createConnection({
//         host: 'localhost',
//         user: 'umvision',
//         password: '1234',
//         database: 'fundus',
//         port: 3306,
//         charset: 'utf8'
//     });

//     connection.connect((err) => {
// 		if(err) {
// 			return res.json({error: "connect error"})
// 		}
// 		const sql = "SELECT value FROM system_info WHERE item = 'Language'";
// 		connection.query(sql, (error, result) => {
// 			if(error) {
// 				connection.end();
// 				return res.json({error: "Can not get data from db"});
// 			}
// 			connection.end();
// 			return res.json({result: result[0].value})
// 		})

// 	})
// })

app.post("/user-login", (req, res) => {
  let user = req.body;
  const selectedLanguage = req.body.lang;
  db.query(
    `select count(*) as count from user where id='${user.id}' and password='${user.password}'`,
    (err, result) => {
      if (err) {
        return res.json({ result: "failed", message: err });
      }
      let checkUser = JSON.parse(JSON.stringify(result))[0].count;
      if (checkUser <= 0) {
        return res.json({
          result: "failed",
          message: "Not found with these credentials",
        });
      }
      updateLanguage(selectedLanguage);
      return res.json({ result: "success", rt: req.body });
    }
  );
});

app.post("/lang-db", (req, res) => {
  const { lang } = req.body;
  // updateLanguage(lang)

  if (lang === "KOR" || lang === "ENG") {
    updateLanguage(lang);
  }

  const connection = mysql.createConnection({
    host: "localhost",
    user: "umvision",
    password: "1234",
    database: "fundus",
    port: 3306,
    charset: "utf8",
  });

  connection.connect((err) => {
    if (err) {
      return res.json({ error: "connect error" });
    }
    const sql = "SELECT value FROM system_info WHERE item = 'Language'";
    connection.query(sql, (error, result) => {
      if (error) {
        connection.end();
        return res.json({ error: "Can not get data from db" });
      }
      connection.end();
      return res.json({ result: result[0].value });
    });
  });
});

function updateLanguage(language) {
  const connection = mysql.createConnection({
    host: "localhost",
    user: "umvision",
    password: "1234",
    database: "fundus",
    port: 3306,
    charset: "utf8",
  });

  connection.connect((err) => {
    if (err) {
      console.error("Error connecting to MariaDB: " + err.stack);
      return;
    }

    console.log("Connected to MariaDB as id " + connection.threadId);

    const sql = "UPDATE system_info SET value = ? WHERE item = 'Language'";
    connection.query(sql, [language], (error, results) => {
      if (error) {
        console.error("Error updating language:", error.message);
      } else {
        console.log("Language updated successfully");
      }
      connection.end();
    });
  });
}

function isValidEmail(email) {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    return false;
  }
  const [localPart, domainPart] = email.split("@");
  if (localPart.length < 1 || localPart.length > 64) {
    return false;
  }
  const domainParts = domainPart.split(".");
  if (
    domainParts.length < 2 ||
    domainParts.some((part) => part.length < 1 || part.length > 63)
  ) {
    return false;
  }
  const localPartPattern = /^[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+$/;
  if (!localPartPattern.test(localPart)) {
    return false;
  }
  const domainPartPattern = /^[a-zA-Z0-9-]+$/;
  if (!domainParts.every((part) => domainPartPattern.test(part))) {
    return false;
  }
  return true;
}

app.post("/register", (req, res) => {
  const { id, password, email } = req.body;
  console.log(req.body);
  if (
    !id ||
    !password ||
    !email ||
    id.length <= 2 ||
    password.length <= 3 ||
    email.length <= 10
  ) {
    return res.json({ result: "failed", message: "Credential error" });
  }

  let userEmail = isValidEmail(email);
  if (!userEmail) {
    return res.json({ message: userEmail });
  }

  db.query('SHOW COLUMNS FROM user WHERE Field = "email"', (e, r) => {
    if (e) return res.json({ error: e });
    const emailEx = r.length > 0;

    if (!emailEx) {
      db.query(
        "ALTER TABLE user ADD COLUMN email VARCHAR(55)",
        (err, result) => {
          if (err) return res.json({ error: err });

          let checkExistingUser = `SELECT EXISTS (SELECT * FROM user WHERE id='${id}' AND email='${email}') AS count`;

          db.query(checkExistingUser, (checkError, checkResult) => {
            if (checkError) {
              console.error("Error checking for existing user:", checkError);
              return res
                .status(500)
                .json({ result: "failed", message: "Something went wrong" });
            }

            const countUser = JSON.parse(JSON.stringify(checkResult))[0].count;

            if (countUser > 0) {
              return res.json({
                result: "exists",
                message: "The same user exists",
              });
            }

            let sql = `INSERT INTO user (id, password, email) 
						VALUES("${id}", "${password}", "${email}");`;
            // console.log(sql)
            db.query(sql, (err, result) => {
              if (err) {
                console.log(err);
                return res.json({
                  result: "failed",
                  message: "Something went wrong",
                });
              } else {
                console.log(result);
                return res.json({ result: "success" });
              }
            });
          });
        }
      );
    } else {
      let checkExistingUser = `SELECT EXISTS (SELECT * FROM user WHERE id='${id}' AND email='${email}') AS count`;

      db.query(checkExistingUser, (checkError, checkResult) => {
        if (checkError) {
          console.error("Error checking for existing user:", checkError);
          return res
            .status(500)
            .json({ result: "failed", message: "Something went wrong" });
        }

        const countUser = JSON.parse(JSON.stringify(checkResult))[0].count;

        if (countUser > 0) {
          return res.json({
            result: "exists",
            message: "The same user exists",
          });
        }

        let sql = `INSERT INTO user (id, password, email) 
						VALUES("${id}", "${password}", "${email}");`;
        // console.log(sql)
        db.query(sql, (err, result) => {
          if (err) {
            console.log(err);
            return res.json({
              result: "failed",
              message: "Something went wrong",
            });
          } else {
            console.log(result);
            return res.json({ result: "success" });
          }
        });
      });
    }
  });
});

// ======================================================= timer ===========================================================

const writeData = (isActive, timer, res) => {
  let sql = `INSERT INTO settings (id, isActive, timer) 
				   VALUES(1, "${isActive}", "${timer}")
				   ON DUPLICATE KEY UPDATE isActive="${isActive}", timer="${timer}";`;
  db.query(sql, (insertError, insertResult) => {
    if (insertError) {
      console.log("Error inserting values:", insertError);
      return res.status(500).json({
        result: "failed",
        message: "Error inserting values",
        error: insertError,
      });
    }
    db.query("SELECT * FROM settings", (error, result) => {
      if (error) {
        return res.json({
          result: "failed",
          message: "Error getting timer data",
        });
      }
      const { isActive, timer } = result[0];
      console.log(typeof isActive);
      res.json({ isActive, timer });
    });
  });
};

app.post("/setting-get-timer", (req, res) => {
  let { turn_btn, timer_f } = req.body;

  db.query(`SHOW TABLES LIKE 'settings'`, (err, result) => {
    if (err) {
      console.log("Error line: 1210", err);
      return res
        .status(500)
        .json({ result: "failed", message: "Something went wrong" });
    }

    const tableExists = result.length > 0;
    if (!tableExists) {
      db.query(
        "CREATE TABLE settings (id INT AUTO_INCREMENT PRIMARY KEY, isActive VARCHAR(5) NOT NULL, timer INT NOT NULL CHECK (timer >= 0 AND timer <= 1200))",
        (createTableError, createTableRes) => {
          if (createTableError) {
            console.log("Error creating table:", createTableError);
            return res.status(500).json({
              result: "failed",
              message: "Error creating table",
              error: createTableError,
            });
          }
          writeData("false", 0, res);
        }
      );
    } else {
      if (turn_btn === "turn_btn") {
        return db.query("SELECT * FROM settings", (error, result) => {
          if (error) {
            return res.json({
              result: "failed",
              message: "Error getting timer data",
            });
          }
          let { isActive, timer } = result[0];
          timer = timer === 0 ? 30 : timer;
          isActive = isActive === "false" ? "true" : "false";
          writeData(isActive, timer, res);
        });
      }

      if (turn_btn === "change_time") {
        const isTrue = timer_f > 0 ? "true" : "false";
        return writeData(isTrue, timer_f, res);
      }

      db.query("SELECT * FROM settings", (err, result) => {
        if (err) {
          return res.json({
            result: "failed",
            message: "Error getting timer data",
          });
        }
        let { isActive, timer } = result[0];
        res.json({ isActive, timer });
      });
    }
  });
});

// ======================================================= timer ===========================================================

app.post("/find-gmail", (req, res) => {
  let { id } = req.body;

  db.query(`SELECT * FROM user WHERE id='${id}'`, (userError, getUserData) => {
    if (userError) {
      return res.json({ err: "Error can not get user Email", userError });
    }

    let data = JSON.parse(JSON.stringify(getUserData));
    if (data.length === 0) {
      return res.json({ result: "failed" });
    }

    let userId = data[0].email.split("@")[0];
    if (userId.length <= 2) {
      userId = userId.slice(0, 1) + "*";
    } else if (userId.length <= 3) {
      userId = userId.slice(0, 1) + "*".repeat(userId.length - 1);
    } else if (userId.length <= 4) {
      userId =
        userId.slice(0, 1) + "*".repeat(userId.length - 2) + userId.slice(-1);
    } else {
      userId =
        userId.slice(0, 2) + "*".repeat(userId.length - 2) + userId.slice(-1);
    }
    userId = userId + "@" + data[0].email.split("@")[1];

    return res.json({ data: userId });
  });
});

app.post("/find-username", (req, res) => {
  const { email } = req.body;

  const validEmail = isValidEmail(email);
  if (!validEmail) {
    return res.json({ result: "failed" });
  }

  db.query(
    `SELECT * FROM user WHERE email='${email}'`,
    (userError, getUserData) => {
      if (userError) {
        return res.json({ result: "failed", userError });
      }

      let data = JSON.parse(JSON.stringify(getUserData));
      if (data.length === 0) {
        return res.json({ result: "failed" });
      }

      let userId = data[0].id;
      if (userId.length <= 2) {
        userId = userId.slice(0, 1) + "*";
      } else if (userId.length <= 3) {
        userId = userId.slice(0, 1) + "*".repeat(userId.length - 1);
      } else if (userId.length <= 4) {
        userId =
          userId.slice(0, 1) + "*".repeat(userId.length - 2) + userId.slice(-1);
      } else {
        userId =
          userId.slice(0, 2) + "*".repeat(userId.length - 2) + userId.slice(-1);
      }
      return res.json({ data: userId });
    }
  );
});

let changePwUser = {};
app.post("/verfy", (req, res) => {
  let { id, email } = req.body;
  id = id.trim();
  email = email.trim();
  if (id.length <= 0 || email.length <= 0) {
    return res.json({ result: "failed" });
  }

  db.query(
    `SELECT * FROM user WHERE id='${id}' AND email='${email}'`,
    (error, data) => {
      if (error) {
        return res.json({ result: "failed" });
      }
      if (data.length <= 0)
        return res.json({ result: "failed", info: "not found user" });
      req.session.changePwUser = {
        id,
        email,
      };
      return res.json({ result: "success" });
    }
  );
});

app.post("/change-password", (req, res) => {
  let { pw } = req.body;
  pw = pw.trim();

  if (pw.length <= 0) {
    return res.json({ result: "failed", info: "not found user" });
  }

  const changePwUserId = req.session.changePwUser.id;
  const changePwUserEmail = req.session.changePwUser.email;

  db.query(
    `UPDATE user SET password='${pw}' WHERE id='${changePwUserId}' AND email='${changePwUserEmail}'`,
    (updateError, updateData) => {
      if (updateError) {
        return res.json({ result: "failed", info: "Update failed" });
      }

      return res.json({
        result: "success",
        info: "Password updated successfully",
      });
    }
  );
});

//21-10-20 file read
app.post("/led_set", (req, res) => {
  console.log("led_set");

  const path = OPER_HOME_DIR + "led_set.dat";
  console.log(path);

  fs.readFile(path, "utf8", (err, result) => {
    if (err) {
      console.error(err);
      return;
    }
    var rowData = result.toString().split("\n");
    console.log(rowData);
    // for (i in rowData) {
    // 	console.log(rowData[i]);
    // }
    // console.log(result);
    res.json({ err, result: rowData });
  });
});

// I-VIEW 시스템 정보 조회 : 22-02-10
app.post("/get-system-info", (req, res) => {
  console.log("get-system-info");
  db.query(`select * from system_info;`, (err, result) => {
    // console.log(result)
    res.json({ err, result });
  });
});

// 환자 목록 조회 기능 : 22-02-07
app.post("/get-patient-list2", (req, res) => {
  console.log("get-patient-list2");
  //	DebugLog('== get-patient-list2  ===');

  // console.log('get-patient-list2')
  db.query(`SELECT * FROM patient ORDER BY name;`, (err, result) => {
    res.json({ err, result });
  });
});

// 촬영 데이터 조회 기능 : 22-02-09
// 22-03-14 : patUUID 항목 추가
app.post("/get-visit-list", (req, res) => {
  console.log("get-visit-list");
  db.query(
    `SELECT name, birthday, gender, DATE_FORMAT(checkDate, '%Y-%m-%d %T') as checkDate,
							checkUUID, patUUID, leftResult, rightResult, imageSize
							FROM visit_log ORDER BY insert_order DESC;`,
    (err, result) => {
      // console.log(result)
      res.json({ err, result });
    }
  );
});

// 환자 정보 수정 업데이트
app.post("/update-patient", (req, res) => {
  console.log("update-patient");
  let patient = req.body;
  db.query(
    `update patient set name='${patient.name}', birthday='${patient.birthday}', phone='${patient.phone}', 
				gender='${patient.gender}' where checkUUID='${patient.checkUUID}';`,
    (err, result) => {
      if (err) {
        res.json({ result: "fail", message: err });
      } else {
        res.json({ result: "success" });
      }
    }
  );
});

// 환자 정보 조회 기능에서 특정 환자들 검색
// 22-03-22 add & modified
app.post("/search-patient-name", (req, res) => {
  console.log("search-patient-name");
  let patient = req.body;
  console.log("SSSS(NAME) : ", patient.name);
  db.query(
    `select * from patient where name like '%${patient.name}%';`,
    (err, result) => {
      if (err) {
        res.json({ result: "fail", message: err });
      } else {
        res.json({ result: "success", message: result });
      }
    }
  );
});

app.post("/search-patient-birthday", (req, res) => {
  console.log("search-patient-birthday");
  let patient = req.body;
  console.log("SSSS(BIRTH) : ", patient.birthday);
  db.query(
    `select * from patient where birthday like '%${patient.birthday}%';`,
    (err, result) => {
      if (err) {
        res.json({ result: "fail", message: err });
      } else {
        res.json({ result: "success", message: result });
      }
    }
  );
});

// 방문 환자 정보 조회 기능에서 특정 환자들 검색
// 22-02-09
// 22-03-02 : query 구문 수정
// 22-03-14 : patUUID 항목 추가
app.post("/search-visit-patient", (req, res) => {
  console.log("search-visit-patient");
  let patient = req.body;
  let sql = `SELECT name, birthday, gender, DATE_FORMAT(checkDate, '%Y-%m-%d %T') as checkDate,
		checkUUID, patUUID, leftResult, rightResult, imageSize
		FROM visit_log WHERE name LIKE '%${patient.name}%' ORDER BY insert_order DESC;`;
  // console.log("sql(search-visit-patient) : " + sql)
  db.query(sql, (err, result) => {
    if (err) {
      res.json({ result: "fail", message: err });
    } else {
      res.json({ result: "success", message: result });
    }
  });
});

// 환자 정보 등록
// 22-02-08
// 22-03-14 : patUUID 처리 구문 추가
app.post("/patient-register", (req, res) => {
  console.log("patient-register");

  // change NodeJs 살향 화일 (2024/04/40)
  //	let form = formidable({ multiples: true, uploadDir: `${__dirname}/images` })
  let form = formidable({ multiples: true, uploadDir: `${work_dir}/images` });
  form.parse(req, (err, fields, files) => {
    if (err) {
      console.log(err);
      res.json({ message: "error" });
      return;
    } else {
      console.log("success");
      // 이미지 저장 상위 폴더
      // 22-03-14 : name->patUUID
      // change NodeJs 살향 화일 (2024/04/40)
      //	let dir = `${__dirname}/images/${fields.patUUID}-${fields.birthday}`
      let dir = `${work_dir}/images/${fields.patUUID}-${fields.birthday}`;

      // SELECT EXISTS(SELECT * FROM patient WHERE name = 'kimmh' AND birthday = '19710112');
      let sql = `SELECT EXISTS (SELECT * FROM patient WHERE name='${fields.name}' AND birthday='${fields.birthday}') AS count`;
      // console.log("sql(patient-register) : " + sql)
      db.query(sql, (err, result) => {
        if (err) {
          res.json({ result: "fail", message: err });
        } else {
          let dupCheck = JSON.parse(JSON.stringify(result));
          //console.log(dupCheck)
          //console.log(dupCheck[0].count)
          if (dupCheck[0].count == 0) {
            console.log("Registered");
            fs.mkdir(`${dir}`, (err) => {
              if (err) {
                console.log(err);
                return;
              } else {
                let sql = `INSERT INTO patient (name, birthday, gender, patUUID) 
														VALUES("${fields.name}", "${fields.birthday}", "${fields.gender}", "${fields.patUUID}");`;
                // console.log(sql)
                db.query(sql, (err, result) => {
                  if (err) {
                    console.log(err);
                    return;
                  } else {
                    console.log(result);
                  }
                });
              }
            });
          } else {
            console.log("Duplicated");
          }
          res.json({ result: "success", message: result });
        }
      });
    }
  });
});

// 폴더 및 하위에 존재하는 파일들까지 모두 삭제
// 22-02-09
var deleteFolderRecursive = function (path) {
  // existsSync: 파일/폴더 존재여부 체크
  if (fs.existsSync(path)) {
    // readdirSync(path): 디렉토리 안의 파일의 이름을 배열로 반환
    fs.readdirSync(path).forEach(function (file, index) {
      var curPath = path + "/" + file;
      if (fs.lstatSync(curPath).isDirectory()) {
        // lstatSync: stat값을 반환함, isDirectory(): 디렉토리인지 파악
        deleteFolderRecursive(curPath); // 재귀(recursive)
      } else {
        // delete file
        fs.unlinkSync(curPath); // unlinkSync: 파일 삭제
      }
    });
    fs.rmdirSync(path); // rmdirSync: 폴더 삭제
  }
};

// 환자 정보 삭제
// 22-02-09
app.post("/delete-patient2", (req, res) => {
  console.log("/delete-patient2");
  let patient = req.body;
  //console.log(patient)
  // 22-04-05 modified : name -> patUUID
  // change NodeJs 살향 화일 (2024/04/40)
  //	let path = `${__dirname}/images/${patient.patUUID}-${patient.birthday}`
  let path = `${work_dir}/images/${patient.patUUID}-${patient.birthday}`;
  console.log(path);
  let sqlStrBuf = `DELETE FROM patient WHERE name='${patient.name}' AND birthday='${patient.birthday}'`;
  //console.log(sqlStrBuf)
  db.query(sqlStrBuf, (err, result) => {
    if (err) {
      res.json({ result: "fail", message: err });
    } else {
      deleteFolderRecursive(path);

      // 22-04-05 added (s)
      console.log("Pat UUID = ", patient.patUUID);
      sqlStrBuf = `DELETE FROM visit_log WHERE patUUID='${patient.patUUID}';`;
      db.query(sqlStrBuf, (err, result) => {
        if (err) {
          console.log("Delete disease data(visit_log) : Fail", sqlStrBuf);
        } else {
          console.log("Delete disease data(visit_log) : Success", sqlStrBuf);
        }
      });

      // 질병 데이터 삭제
      sqlStrBuf = `DELETE FROM disease WHERE patUUID='${patient.patUUID}';`;
      db.query(sqlStrBuf, (err, result) => {
        if (err) {
          console.log("Delete disease data(disease) : Fail", sqlStrBuf);
        } else {
          console.log("Delete disease data(disease) : Success", sqlStrBuf);
        }
      });
      // 22-04-05 added (e)

      res.json({ result: "success" });
    }
  });
});

// 21-11-10 added
// 질병 상태 취득
app.post("/get-disease", (req, res) => {
  console.log("/get-disease");
  let patient = req.body;
  let sql = `select dr, amd, glaucoma, eyePos from disease where checkUUID='${patient.checkUUID}' order by imageIndex asc;`;
  // console.log(sql)
  db.query(sql, (err, result) => {
    if (err) {
      res.json({ result: "fail", message: err });
    } else {
      // console.log(result)
      res.json({ result: "success", message: result });
    }
  });
});

// 22-03-31 added
// 디스크 사용 정보 취득
app.post("/get-disk-usage", (req, res) => {
  console.log("get-disk-usage");
  //	DebugLog('==== get-disk-usage ==== ');

  //	setTimeout(() => {
  UpdateUsedDiskData();
  //	}, 50);

  // 지연 타이머 설정
  const delay = 350; // 350 msec 지연

  setTimeout(() => {
    //		console.log('Read Disk Data');

    //	DebugLog('==== Read-disk Datas==== ');
    let sql = `SELECT total, used, free FROM disk_usage`;

    db.query(sql, (err, result) => {
      if (err) {
        console.log("get-disk-usage fail");
        //	DebugLog('==== get-disk-usage fail==== ');
        res.json({ result: "fail", message: err });
      } else {
        //	console.log(result)
        console.log("get-disk-usage success");
        console.log("Query Result:", result);

        //	DebugLog('==== get-disk-usage success====');
        res.json({ result: "success", message: result });
      }
    });
  }, delay);
});

// 22-09-14 added
// Language 정보 획득(다국어 표시를 위한 정보)
app.post("/get-lang-info", (req, res) => {
  console.log("/get-lang-info");

  //	DebugLog('==== /get-lang-info  ==== ');

  let sql = `SELECT value FROM system_info WHERE item = 'Language';`;
  //console.log(sql)
  db.query(sql, (err, result) => {
    if (err) {
      res.json({ result: "fail", message: err });
    } else {
      // console.log(result)
      //	DebugLog('==== get-lang-info success ==== ');
      res.json({ result: "success", message: result });
    }
  });
});

// 21-11-15 added
// AI 파일 처리
app.post("/ai-check-file", (req, res) => {
  let form = formidable({ multiples: true });
  var buf;

  form.parse(req, (err, fields, files) => {
    let filename = `${fields.filename}`;
    if (err) {
      console.log(err);
      return;
    } else {
      console.log("success");
      console.log(filename);

      fs.stat(`${fields.filename}`, function (error, stats) {
        console.log("파일 크기: ", stats.size);
        buf = new Buffer(stats.size);
      });

      fs.open(`${fields.filename}`, "r", function (err, fd) {
        if (err) {
          console.log("file read : fail");
        } else {
          fs.read(
            fd,
            buf,
            0,
            buf.length,
            null,
            function (err, byteRead, result) {
              if (err) throw err;
              //console.log("이미지 사이즈0 :" + result.length)
              res.json({ result: "success", message: buf });
              //console.log("이미지 사이즈 :" + byteRead)
              fs.close(fd);

              // for test
              // fs.open('/tmp/image_write.jpg', 'w', function(err, fd){
              // 	if(err) throw err;
              // 	fs.write(fd, buf, 0, buf.length, null, function(err, written, buffer){
              // 		fs.close(fd)
              // 	})
              // })
            }
          );
        }
      });
    }
  });
});

// 21-11-29 added
// 21-12-22 modify : 정상, 비정상 처리 보완
// AI 가상 질병 데이터 DB 저장
app.post("/update-disease", (req, res) => {
  console.log("/update-disease");
  let form = formidable({ multiples: true });
  let diseaseStr = ["amd", "glaucoma", "dr"];

  form.parse(req, (err, fields, files) => {
    if (err) {
      console.log(err);
      return;
    } else {
      // console.log(`${ fields.checkUUID }`)
      // console.log(`${ fields.imageIndex }`)
      // console.log(`${ fields.result }`)
      // console.log('success')
      // 21-12-09 : res.json() return 값들 주석 처리하여 통신 버퍼 막히는 문제 해결
      // 기존 데이터 초기화
      console.log("result : " + fields.result);
      if (fields.result >= 1) {
        let sqlStr = `update disease set amd='0', glaucoma='0', dr='0' where checkUUID='${fields.checkUUID}' AND imageIndex='${fields.imageIndex}';`;
        db.query(sqlStr, (err, result) => {
          if (err) {
            // res.json({result:'fail', message:err})
          } else {
            console.log("update-disease normal");
            if (fields.result == 1) {
              res.json({ result: "success" });
              return;
            }
          }
        });
      }

      if (fields.result >= 2) {
        // 새로운 데이터로 업데이트
        sqlStr = `update disease set ${diseaseStr[fields.result - 2]} = '${
          fields.result
        }' 
							where checkUUID='${fields.checkUUID}' AND imageIndex='${fields.imageIndex}';`;

        // console.log("Disease Update : " + sqlStr)
        db.query(sqlStr, (err, result) => {
          if (err) {
            // res.json({result:'fail', message:err})
          } else {
            // 21-12-22 added : Node.js의 경우 응답 처리를 안해도 버퍼에 문제가 생기는 현상이 있어서 강제 응답 전송
            res.json({ result: "success" });
            console.log("update-disease abnormal");
          }
        });
      }
    }
  });
});

app.post("/camera-manual", async (req, res) => {
  console.log("//camera-manual");

  let form = formidable({ multiples: true });

  serialport.write("YSZM51");

  try {
    // 1. form.parse()를 Promise로 변환하여 사용
    const fields = await new Promise((resolve, reject) => {
      form.parse(req, (err, fields, files) => {
        if (err) {
          console.log("Form parsing error:", err);
          return reject(err);
        }
        resolve(fields);
      });
    });

    // 2. exec을 await으로 실행
    const path = OPER_HOME_DIR + "uvc_set.sh";
    console.log(path);
    const { stdout } = await execPromise(path);
    console.log("stdout:", stdout);
    // 3. sleep 및 추가 동작 실행
    await Node_sleep(200);
    console.log("Call to  setBacklightCompensation 00:");
    //	await setBacklightCompensation();
    //	await Node_sleep(50);

    await AutoRecoveryCamData();
    await Node_sleep(200);

    await setBacklightCompensation();
    //	await Node_sleep(50);

    // 4. 성공 응답
    return res.json({ result: "success" });
  } catch (error) {
    console.log("Error:", error);
    return res.status(500).json({ result: "error", message: error.message });
  }
});

// Execute the 'df -h' command to get disk usage information
function UpdateUsedDiskData() {
  //	DebugLog('function UpdateUsedDiskData');
  console.log("function UpdateUsedDiskData");

  exec("df -h /dev/mmcblk1p1", (error, stdout, stderr) => {
    if (error) {
      console.error(`Error executing df: ${error}`);
      return;
    }

    // Split the output into lines and skip the header
    const lines = stdout.split("\n").slice(1);

    // Process each line to extract and display disk usage information
    lines.forEach((line) => {
      const columns = line.split(/\s+/);
      //		DebugLog('UpdateUsedDiskData2', columns.length);
      if (columns.length >= 6) {
        const filesystem = columns[0];
        const sizeWithUnit = columns[1];
        const usedWithUnit = columns[2];
        const availWithUnit = columns[3];
        const usePercentage = columns[4];
        const mountedOn = columns[5];

        // Extract numeric values and units
        const sizeValue = parseFloat(sizeWithUnit);
        const usedValue = parseFloat(usedWithUnit);
        const availValue = parseFloat(availWithUnit);
        const sizeUnit = sizeWithUnit.slice(-1);
        const usedUnit = usedWithUnit.slice(-1);
        const availUnit = availWithUnit.slice(-1);

        // Calculate numeric values in GB
        const totalGB = sizeUnit === "G" ? sizeValue : sizeValue / 1024;
        const usedGB = usedUnit === "G" ? usedValue : usedValue / 1024;
        const freeGB = availUnit === "G" ? availValue : availValue / 1024;

        //			DebugLog('UpdateUsedDiskData5', totalGB, usedGB, freeGB);
        // 디스크 정보를 응답으로 보내기

        console.log(`Filesystem: ${filesystem}`);
        console.log(`Total1: ${totalGB} `);
        console.log(`Used1: ${usedGB} `);
        console.log(`freeGB1: ${freeGB} `);
        console.log(`Use%: ${usePercentage}`);
        console.log(`Mounted on: ${mountedOn}`);

        db.query(
          `update disk_usage set total='${totalGB}', used='${usedGB}', free='${freeGB}';`,
          (err, result) => {
            if (err) {
              console.error("Error updating in the database:");
              //	DebugLog('Error Update');
            } else {
              console.log("Disk updated  successfully");
              //	DebugLog('Disk updated  successfully');
            }
          }
        );
      }
    });
  });
}

//23-08-25 add s by mclee : e-con device GRR Mode Process
async function SaveWhiteOnTime() {
  console.log("SaveWhiteOnTime");

  const path = OPER_HOME_DIR + "cam_para.dat";
  console.log(path);
  // 파일 내용 읽기
  fs.readFile(path, "utf8", (err, data) => {
    console.log("save-camera-parameter 7");
    console.log(path);
    if (err) {
      console.error(`Error reading file: ${err}`);
      return;
    }
    // 정규식 패턴
    const regex = /ID{0x0098091c};CHK{[^}]+}=VAL{(\d+)}/;

    // 정규식으로 매칭
    const match = data.match(regex);

    //	console.log('save-camera-parameter 8')
    if (match) {
      let val = match[1]; // 매칭된 그룹 값

      while (val.length < 4) {
        val = "0" + val; // 4자리가 아니면 앞에 0 추가
      }

      BackLight_Time = val;

      console.log("Found BackLight_Time:", BackLight_Time);
    } else {
      console.log("VAL not found.");
    }
  });
}

async function SaveWhiteOnTime_1() {
  console.log("SaveWhiteOnTime_1");
  const path = OPER_HOME_DIR + "led_set.dat";
  console.log(path);

  fs.readFile(OPER_HOME_DIR + "led_set.dat", "utf8", (err, data) => {
    console.log("save-camera-parameter 9");
    console.log(path);
    if (err) {
      console.error(`Error reading file: ${err}`);
      return;
    }

    // 라인 분할
    const lines = data.split("\n");

    //	console.log('newValue : ', newValue);
    // LW 라인 찾기 및 수정
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].startsWith("LW")) {
        const parts = lines[i].split(" ");
        if (parts.length >= 8) {
          //		parts[5] = newValue.toString();	// 수정된 값으로 변경
          parts[5] = BackLight_Time.toString(); // 수정된 값으로 변경
          console.log("String : ", BackLight_Time.toString());
          console.log("part[5] : ", parts[5]);
          lines[i] = parts.join(" "); // 수정된 라인으로 조립
          break; // 찾았으면 루프 중단
        }
      }
    }

    console.log("save-camera-parameter 10");
    // 수정된 내용으로 파일 쓰기
    const modifiedData = lines.join("\n");
    console.log("modifiedData : \n", modifiedData);

    console.log(path);

    fs.writeFile(path, modifiedData, "utf8", (err) => {
      if (err) {
        console.error(`Error writing file: ${err}`);
        return;
      }
      console.log("Value updated successfully.");
    });
  });
}

async function LW_Report_Serial() {
  // 파일 경로
  const path = OPER_HOME_DIR + "led_set.dat";

  console.log(path);

  // 파일 읽기 및 처리
  fs.readFile(path, "utf8", (err, data) => {
    if (err) {
      console.error("파일을 읽는 중 오류 발생:", err);
      return;
    }
    // 각 줄 별로 처리
    const lines = data.split("\n");
    lines.forEach((line) => {
      if (line.startsWith("LW")) {
        const cleanedLine = line.replace(/\s+/g, ""); // 공백 제거
        console.log("전송데이터:", cleanedLine);
        // 시리얼 포트를 통해 데이터 전송
        serialport.write(cleanedLine, (err) => {
          if (err) {
            console.error("데이터 전송 오류 :", err);
          } else {
            console.log("데이터 전송 완료");
          }
        });
      }
    });
  });
}
//23-08-25 add e by mclee : e-con device GRR Mode Process

// 22-03-15 added
// "ecam_tk1_guvcview" 외부 프로그램 기동
// 22-03-17 modified : GUI 프로그램은 외부 기동이 안되므로 카메라 파라미터 저장하는
// 방향으로 기능 선회(uvcdynctrl 명령어 사용)
app.post("/save-camera-parameter", async (req, res) => {
  console.log("save-camera-parameter");

  let form = formidable({ multiples: true });
  form.parse(req, (err, fields, files) => {
    console.log("save-camera-parameter 1");
    if (err) {
      console.log(err);
      return;
    } else {
      //		console.log('save-camera-parameter 2')
      var exec = require("child_process").exec,
        child;
      const path = OPER_HOME_DIR + "save_cam_para.sh";
      console.log(path);

      child = exec(path, function (error, stdout, stderr) {
        //			console.log('save-camera-parameter 4')
        // console.log('stdout : ' + stdout);
        // console.log('stderr:  ' + stderr);
        if (error != null) {
          console.log("exec error : " + error);
        }
      });
      res.json({ result: "success" });
    }
  });

  //23-09-06 add s by mclee : e-con device GRR Mode Process
  await SaveWhiteOnTime();
  await SaveWhiteOnTime_1();
  await LW_Report_Serial();
  //23-09-06 add e by mclee : e-con device GRR Mode Process
});

// 22-03-17 added : 카메라 파라미터 불러오기
app.post("/load-camera-parameter", (req, res) => {
  console.log("/load-camera-parameter");

  let form = formidable({ multiples: true });
  form.parse(req, (err, fields, files) => {
    if (err) {
      console.log(err);
      return;
    } else {
      //// console.log("Load camera parameters.")
      var exec = require("child_process").exec,
        child;
      const path = OPER_HOME_DIR + "load_cam_para.sh";
      console.log(path);
      child = exec(path, function (error, stdout, stderr) {
        // console.log('stdout : ' + stdout);
        // console.log('stderr:  ' + stderr);
        if (error != null) {
          console.log("exec error : " + error);
        }
      });
      res.json({ result: "success" });
    }
  });
});

// 22-03-04 modified : 뉴 시나리오에 맞게 전면 수정
// 22-03-15 : patUUID 처리 추가, delete-shoot-data => delete-filming-data
app.post("/delete-filming-data", (req, res) => {
  console.log("/delete-filming-data");
  let patient = req.body;
  db.query(
    `delete from visit_log where checkUUID='${patient.checkUUID}';`,
    (err, result) => {
      if (err) {
        res.json({ result: "fail", message: err });
      } else {
        for (let i = 0; i < patient.imageSize; i++) {
          // 21-10-13 : 파일 확장자 jpeg->jpg
          // change NodeJs 살향 화일 (2024/04/40)
          //	fs.unlinkSync(`${__dirname}/images/${patient.patUUID}-${patient.birthday}/${patient.checkUUID}/${i}.jpg`)
          fs.unlinkSync(
            `${work_dir}/images/${patient.patUUID}-${patient.birthday}/${patient.checkUUID}/${i}.jpg`
          );
        }
        // change NodeJs 살향 화일 (2024/04/40)
        //	fs.rmdirSync(`${__dirname}/images/${patient.patUUID}-${patient.birthday}/${patient.checkUUID}`)
        fs.rmdirSync(
          `${work_dir}/images/${patient.patUUID}-${patient.birthday}/${patient.checkUUID}`
        );
        res.json({ result: "success" });
      }
    }
  );

  // 질병 데이터 삭제
  db.query(
    `delete from disease where checkUUID='${patient.checkUUID}';`,
    (err, result) => {
      if (err) {
        console.log("Delete disease data(visit_log) : Fail");
      } else {
        console.log("Delete disease data(visit_log) : Success");
      }
    }
  );
});

// 21-11-03 added : 환자 목록에서 선택된 이미지 삭제 기능
app.post("/patient-image-delete", (req, res) => {
  console.log("/patient-image-delete");
  let patient = req.body;
  //console.log(patient)
  // change NodeJs 살향 화일 (2024/04/40)
  //console.log(`${__dirname}/images/${patient.checkUUID}/${patient.rightResult}.jpg`)
  fs.unlinkSync(
    `${work_dir}/images/${patient.checkUUID}/${patient.rightResult}.jpg`
  );
  //console.log(patient.rightResult, ":", patient.imageSize);
  for (let idx = patient.rightResult; idx < patient.imageSize; idx++) {
    // change NodeJs 살향 화일 (2024/04/40)
    //	src = `${__dirname}/images/${patient.checkUUID}/${idx+1}.jpg`;
    //	dst = `${__dirname}/images/${patient.checkUUID}/${idx}.jpg`;
    src = `${work_dir}/images/${patient.checkUUID}/${idx + 1}.jpg`;
    dst = `${work_dir}/images/${patient.checkUUID}/${idx}.jpg`;
    //console.log(src);
    //console.log(dst);
    fs.rename(src, dst, function (err) {
      if (err) throw err;
      //console.log('rename complete')
    });
  }
  db.query(
    `update patient set imageSize='${patient.imageSize}' where checkUUID='${patient.checkUUID}';`,
    (err, result) => {
      if (err) {
        res.json({ result: "fail", message: err });
      } else {
        res.json({ result: "success" });
      }
    }
  );

  // 21-12-02 : 저장 이미지 삭제 이후 나머지 데이터 순차 정렬
});

//	app.listen(8000, () => {
app.listen(8000, async () => {
  console.log("http server is running on port 8000!");
  console.log("websocket server is running on port 8080!");
  await deleteAllImagesFromPreview();
  // 21-10-20 : 향후 부팅 이후 하단으로 LED 설정값들 전송하기 위한 구현 예상 위치
  // 파일에서 설정값 로딩하여 시리얼 포트를 통해서 데이터 전송
  // 21-12-13 : 파일 로딩 없이 현재 최적화된 값으로 강제 전송
  // setTimeout(() => serialport.write(`LW47R99103000250`), 2000);
  // 21-12-16 added : 카메라 수동모드 스크립트 실행 처리

  // 23-06-21 changed s : 카메라 LED Data I/F B'd로 전달 by mclee

  console.log("\n");

  log(`== START NodeJS START ==`);
  await async_log(`== START NodeJS START ==`);
  //	console.log('== START NodeJS  ===');
  //		console.log('== Pkg Version : V2.0.0.4, Date : 2025/01/23 PM 15:20  ===');
  console.log("== Pkg Version : V2.0.0.6, Date : 2025/07/14 PM 13:25  ===");

  /*
	//23-09-06 add s by mclee : e-con device GRR Mode Process
		setTimeout(() => {
			SaveWhiteOnTime();
		}, 5);
	//23-09-06 add e by mclee : e-con device GRR Mode Process

		setTimeout(() => {
			SaveWhiteOnTime_1();
		}, 30);

		setTimeout(() => {
			await setBacklightCompensation();
		}, 50);

		setTimeout(() => {
			AF_LW_systemData();
		}, 100);

		setTimeout(() => {
			Save_AutoS1_ForwardData();
		}, 150);
		*/
  //	await async_log(`== START NodeJS START ==`)
  await SaveWhiteOnTime();
  await SaveWhiteOnTime_1();
  console.log("Call to  setBacklightCompensation 02:");
  await setBacklightCompensation();
  await AF_LW_systemData();
  await Save_AutoS1_ForwardData();
});

// add s for Black Screen Problem by mclee (2025/01/24)

async function setBacklightCompensation() {
  console.log("setBacklightCompensation started");

  const cam_path = OPER_HOME_DIR + "cam_para.dat";
  console.log(cam_path);
  //    console.log('setBacklightCompensation path', path);
  //
  try {
    const data = await fsp.readFile(cam_path, "utf8");
    //       console.log('File read successfully.');

    // 정규식으로 데이터 추출
    const backlightRegex = /#Backlight Compensation\s*ID\{.*?}=VAL\{(\d+)\}/;
    const exposureRegex = /#Exposure \(Absolute\)\s*ID\{.*?}=VAL\{(\d+)\}/;

    const backlightMatch = data.match(backlightRegex);
    const exposureMatch = data.match(exposureRegex);
    // console.log('Backlight match:', backlightMatch);
    // console.log('Exposure match:', exposureMatch);
    //
    if (backlightMatch && exposureMatch) {
      const backlightValue = parseInt(backlightMatch[1], 10);
      const exposureValue = parseInt(exposureMatch[1], 10);

      console.log("Extracted values:");
      console.log("Backlight Compensation:", backlightValue);
      console.log("Exposure (Absolute):", exposureValue);

      // V4L2 명령 실행
      await setV4L2Control("backlight_compensation", backlightValue);
      await Node_sleep(100);
      await setV4L2Control("exposure_absolute", exposureValue);
    } else {
      onsole.error("Failed to extract required values from cam_para.dat.");
    }
  } catch (err) {
    console.error("Error reading or processing file:", err.message);
  }
}

async function setBrightnessMode(brightnessValue, customValue) {
  log(`==  setBrightnessMode Start==`);
  console.log(
    "brightness, customValue with mode:",
    brightnessValue,
    customValue
  );
  const cam_path = OPER_HOME_DIR + "cam_para.dat";
  console.log(cam_path);
  const MIN_BRIGHTNESS = -15;
  const MAX_BRIGHTNESS = 15;

  try {
    if (brightnessValue === 0) {
      // cam_para.dat에서 읽기
      const data = await fsp.readFile(cam_path, "utf8");
      const brightnessRegex =
        /#Brightness\s*ID\{.*?\};CHK\{.*?\}=VAL\{(-?\d+)\}/;
      const brightnessMatch = data.match(brightnessRegex);

      if (brightnessMatch) {
        const extractedValue = parseInt(brightnessMatch[1], 10);

        if (
          extractedValue < MIN_BRIGHTNESS ||
          extractedValue > MAX_BRIGHTNESS
        ) {
          console.error(
            `Extracted brightness value ${extractedValue} is out of range (${MIN_BRIGHTNESS} to ${MAX_BRIGHTNESS}).`
          );
          return;
        }

        console.log("Extracted brightness from file:", extractedValue);
        await setV4L2Control("brightness", extractedValue);
      } else {
        console.error("Brightness value not found in cam_para.dat.");
      }
    } else if (brightnessValue === 1) {
      // 사용자 정의 값 사용
      if (
        typeof customValue !== "number" ||
        isNaN(customValue) ||
        customValue < MIN_BRIGHTNESS ||
        customValue > MAX_BRIGHTNESS
      ) {
        console.error(
          `Invalid custom brightness value. Must be a number between ${MIN_BRIGHTNESS} and ${MAX_BRIGHTNESS}.`
        );
        return;
      }

      console.log("Using custom brightness value:", customValue);
      await setV4L2Control("brightness", customValue);
    } else {
      console.error("Invalid brightness mode. Must be 0 (file) or 1 (custom).");
    }
  } catch (err) {
    console.error("Error in setBrightnessMode:", err.message);
  }
}

async function setSaturationMode(saturationValue, customValue) {
  log(`==  setSaturationMode Start==`);
  console.log("tSaturation, c_value :", saturationValue, customValue);

  const cam_path = OPER_HOME_DIR + "cam_para.dat";
  console.log(cam_path);
  const MIN_SATURATION = 0;
  const MAX_SATURATION = 60;
  console.log(cam_path);

  try {
    if (saturationValue === 0) {
      // cam_para.dat에서 읽기
      const data = await fsp.readFile(cam_path, "utf8");
      const saturationRegex = /#Saturation\s*ID\{.*?\};CHK\{.*?\}=VAL\{(\d+)\}/;
      const saturationMatch = data.match(saturationRegex);

      if (saturationMatch) {
        const extractedValue = parseInt(saturationMatch[1], 10);

        if (
          extractedValue < MIN_SATURATION ||
          extractedValue > MAX_SATURATION
        ) {
          console.error(
            `Extracted saturation value ${extractedValue} is out of range (${MIN_SATURATION}-${MAX_SATURATION}).`
          );
          return;
        }

        console.log("Extracted saturation from file:", extractedValue);
        await setV4L2Control("saturation", extractedValue);
      } else {
        console.error("Saturation value not found in cam_para.dat.");
      }
    } else if (saturationValue === 1) {
      // 사용자 정의 값 사용
      if (
        typeof customValue !== "number" ||
        isNaN(customValue) ||
        customValue < MIN_SATURATION ||
        customValue > MAX_SATURATION
      ) {
        console.error(
          `Invalid custom saturation value. Must be a number between ${MIN_SATURATION} and ${MAX_SATURATION}.`
        );
        return;
      }

      console.log("Using custom saturation value:", customValue);
      await setV4L2Control("saturation", customValue);
    } else {
      console.error("Invalid saturation mode. Must be 0 (file) or 1 (custom).");
    }
  } catch (err) {
    console.error("Error in setSaturationMode:", err.message);
  }
}

async function setExposure_absolute(exposureMode, customValue) {
  log(`==  setExposure_absolute Start==`);
  console.log("exposureMode, customValue :", exposureMode, customValue);

  const cam_path = OPER_HOME_DIR + "cam_para.dat";
  console.log(cam_path);
  const MIN_EXPOSURE = 1;
  const MAX_EXPOSURE = 10000;

  console.log(cam_path);

  try {
    let exposureValue;

    if (exposureMode === 0) {
      // cam_para.dat에서 Exposure (Absolute) 값 읽기
      const data = await fsp.readFile(cam_path, "utf8");

      // 정확한 노출 라인 패턴: "#Exposure (Absolute)"로 시작하는 줄에서 VAL 값 추출
      const exposureRegex = /#Exposure\s*\(Absolute\)[^\n]*?VAL\{(\d+)\}/;
      const exposureMatch = data.match(exposureRegex);

      if (exposureMatch) {
        exposureValue = parseInt(exposureMatch[1], 10);

        if (exposureValue < MIN_EXPOSURE || exposureValue > MAX_EXPOSURE) {
          console.error(
            `Extracted exposure value ${exposureValue} is out of range (${MIN_EXPOSURE}-${MAX_EXPOSURE}).`
          );
          return;
        }

        console.log("Extracted exposure from file:", exposureValue);
      } else {
        console.error("Exposure (Absolute) value not found in cam_para.dat.");
        return;
      }
    } else if (exposureMode === 1) {
      // 사용자 정의 값 사용
      if (
        typeof customValue !== "number" ||
        isNaN(customValue) ||
        customValue < MIN_EXPOSURE ||
        customValue > MAX_EXPOSURE
      ) {
        console.error(
          `Invalid custom exposure value. Must be a number between ${MIN_EXPOSURE}-${MAX_EXPOSURE}.`
        );
        return;
      }

      exposureValue = customValue;
      console.log("Using custom exposure value:", exposureValue);
    } else {
      console.error("Invalid exposure mode. Must be 0 (file) or 1 (custom).");
      return;
    }

    // exposure_auto를 수동(1)으로 설정 후 absolute 값 설정
    // await setV4L2Control('exposure_auto', 1);
    await setV4L2Control("exposure_absolute", exposureValue);
  } catch (err) {
    console.error("Error in setExposure_absolute:", err.message);
  }
}

// V4L2 설정을 위한 함수
async function setV4L2Control(controlName, controlValue) {
  const command = `/usr/bin/v4l2-ctl --set-ctrl=${controlName}=${controlValue}`;
  console.log(`Executing command: ${command}`);
  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error executing command: ${command}`);
      console.error(stderr.trim());
    } else {
      //console.log(`Command executed successfully: ${stdout.trim()}`);
    }
  });
}
// add e for Black Screen Problem by mclee (2025/01/24)

db.query("show tables;", () => {});

// 2022-04-05 : 'X' 데이터는 정확한 의미를 알 수 없는 데이터 이므로 channel 통신으로 보내지 않음
//
//	serialport.setListener(function(data) {
serialport.setListener(async function (data) {
  // change for image conotrol by mclee (2025-01-03)

  if (data != "X") {
    console.log("Received from IF FW", data);

    // 23-11-09 add s by mclee : GRR Mode Implement
    if (channel && channel.OPEN) {
      if (data === "WF") {
      } else if (data === "S2") {
        console.log("No1 S2 Auto_Status =", Auto_Status);

        if (Auto_Status === 5) {
          console.log("Already Received S2 =");
          return;
        }

        //	if(Auto_Status === 4 || Auto_Status === 0)	{
        if (Auto_Status === 4 || (Auto_Status === 0 && S1_received === 1)) {
          if (Auto_Status === 4) {
            Auto_Status = 5;
          } else {
            Auto_Status = 0;
          }

          try {
            await GrrCaptureProcess();
            console.log("Capture process O.K:");
          } catch (error) {
            console.error("Error in capture process:", error);
          }

          //	await Node_sleep(100);
          /*
						console.log('== Send to React  ==', data);
						log(`channel data : ${data}`)
						channel.send(data)
						await Pre_ImageProcess();
						*/
          if (Auto_Status === 5) {
            //	await Node_sleep(10);
          }

          await Pre_ImageProcess();

          console.log("== Send to React  ==", data);
          log(`channel data : ${data}`);
          channel.send(data);

          // add for image conotrol by mclee (2025-01-03)
        } else {
          Auto_Status = 5;
          console.log("== Send to React  ==", data);
          log(`channel data : ${data}`);
          channel.send(data);
          debug.send("from serial : " + data);
        }
        //Auto_Status = 0;
      } else {
        // 24-03-07 add by mclee : AutoFocusng Function
        if (data === "RR") {
          eye_position = "OD";
          console.log("eye_position =", eye_position);
        } else if (data === "RL") {
          eye_position = "OS";
          console.log("eye_position =", eye_position);
        } else if (data === "S1") {
          console.log("== Rcv S1 ==");
          S1_received = 1;
          console.log("Auto_Status =", Auto_Status);
          serialport.write("S1");
          userSleep(10);

          if (Auto_Status !== 0) {
            //	Auto_Status = 5;	//Auto Shoot End
            //	await Node_sleep(5);
            //		userSleep(30);
            console.log("==Auto Shoot Stop Add_sum==", Add_sum);
            if (Auto_Status < 3) {
              log(`channel data : ${"S1"}`);
              channel.send("S1");
              //	await Node_sleep(20);
              userSleep(100);
            }

            /*
							const fszm_d = Add_sum / 20;
							const last_fszm_d = Math.abs(Math.round(fszm_d + 2));
							console.log('Add_sum, fszm_d lat_fszm_d=', Add_sum, fszm_d, last_fszm_d); 
							serialport.write('YSZM'+last_fszm_d);
							userSleep(100);
							*/
            //serialport.write('YSZM80')

            log(` Convert S1 -> S2`);
            Auto_Status = 5; //Auto Shoot End
            data = "S2";
            S2_received = 1;
            serialport.write("S2");
            //	Auto_Status = 5;	//Auto Shoot End
            userSleep(100);
            serialport.write("YSZM80");
            await AutoRecoveryCamData();
            //	userSleep(10);
          } else {
            console.log("S1 Normal YSZM51");
            serialport.write("YSZM51");
          }
        }
        // 24-03-07 add by mclee : AutoFocusng Function

        console.log("== Send to React  ==", data);
        log(`channel data : ${data}`);
        channel.send(data);
        debug.send("from serial : " + data);
      }
    }
  }
  // 23-11-09 add e by mclee : GRR Mode Implement
});

// 22-02-25 : milliSeconds 정보 처리 추가
const log = (msg) => {
  let d = new Date();
  let hours = d.getHours();
  hours = `${hours < 10 ? `0${hours}` : hours}`;
  let minutes = d.getMinutes();
  minutes = `${minutes < 10 ? `0${minutes}` : minutes}`;
  let seconds = d.getSeconds();
  seconds = `${seconds < 10 ? `0${seconds}` : seconds}`;
  let milliSeconds = d.getMilliseconds();
  console.log(`${hours}.${minutes}.${seconds}-${milliSeconds} : ${msg}`);
};

async function async_log(msg) {
  const d = new Date();
  const year = d.getFullYear();
  const month = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  const hours = `${d.getHours()}`.padStart(2, "0");
  const minutes = `${d.getMinutes()}`.padStart(2, "0");
  const seconds = `${d.getSeconds()}`.padStart(2, "0");
  const milliseconds = `${d.getMilliseconds()}`.padStart(3, "0");
  console.log(
    `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds} : ${msg}`
  );
}

/*
	function OldDeviceKill() { 
		
		const filename = "/dev/video0";
		const command = `lsof -t ${filename}`; 
		
		exec(command, (error, stdout, stderr) => {
			if (error) {
				console.error(`Error executing command: ${stderr}`);
				return;
			} 
			
			const pid = stdout.trim(); 
			
			if (pid) {
			// Construct the command to kill the process by PID
				const killCommand = `kill -15 ${pid}`;
			// Execute the kill command
				exec(killCommand, (killError, killStdout, killStderr) => {
					if (killError) {
						console.error(`Error killing process: ${killStderr}`);
						return;
					}
					console.log(`Process with PID ${pid} killed successfully.`);
				//	DebugLog('OldDeviceKill SUCCESS');
				});
			} else {
				console.error("No process using the file.");
			}

		});
	}

*/

// 23-09-05 add e by mclee : GRR Mode Implement

function LED_data_Report_IF() {
  //	DebugLog('LED_data_Report_IF');
  console.log("LED_data_Report_IF");

  const path = OPER_HOME_DIR + "led_set.dat";

  console.log(path);

  fs.readFile(path, "utf8", (err, data) => {
    if (err) {
      console.error(err);
      return;
    }

    console.log(data);
    // 스페이스 제외한 데이터 추출
    const filteredData = data.replace(/ /g, "");

    // 라인 단위로 데이터 전송
    const lines = filteredData.split("\n");

    console.log(lines.length);

    let line_len = lines.length - 1;
    console.log(lines.length, line_len);
    let index = 0;
    const intervalDuration = 20; // 시간 간격 설정 (단위: 밀리초)

    // 지정된 시간 간격으로 데이터 전송
    const sendDataInterval = setInterval(() => {
      console.log(index);

      if (index >= line_len) {
        clearInterval(sendDataInterval); // 모든 데이터 전송이 완료되면 반복 작업 종료
        console.log("data send complete to serial");
        return;
      }

      const line = lines[index];
      serialport.write(line);
      index++;
    }, intervalDuration); // 지정된 시간 간격으로 데이터 전송
  });
}

function V4L2_command_proce() {
  //		DebugLog('V4L2_command_proce');
  console.log("V4L2_command_proce");

  const v4l2CtlCommand =
    "v4l2-ctl -d /dev/video0 --get-ctrl=backlight_compensation";

  exec(v4l2CtlCommand, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error executing v4l2-ctl: ${error.message}`);
      return;
    }

    if (stderr) {
      console.error(`v4l2-ctl error: ${stderr}`);
      return;
    }

    // 'stdout'에는 'backlight_compensation' 값을 포함하고 있습니다.
    BackLight_Time = stdout.trim();

    // 'stdout'에는 'backlight_compensation' 값을 포함하고 있습니다.
    console.log("update backlight_compensation data");
    console.log(`BackLight_Time: ${BackLight_Time}`);
  });
}

// 현재 날짜를 YYYY-MM-DD 형식으로 반환하는 함수
function getCurrentDate() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0"); // 월은 0부터 시작하므로 1을 더하고 두 자리로 패딩
  const day = String(now.getDate()).padStart(2, "0"); // 일을 두 자리로 패딩
  return `${year}-${month}-${day}`;
}

function getCurrentDate() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

/*
	const logDirectory = '/home/nvidia/i-view100/LOG/';
	const logFileName = `DebugLog_${getCurrentDate()}.dat`;
	const logFilePath = `${logDirectory}${logFileName}`;



	function DebugLog(...args) {
	//	const timestamp = new Date().toISOString();	//  UTC 기준시각
	//	const timestamp = new Date().toLocaleString(); // 현지 시간으로 변환
		const now = new Date();
		
		const year = now.getFullYear();
		const month = String(now.getMonth() + 1).padStart(2, '0');
		const day = String(now.getDate()).padStart(2, '0');
		const hour = String(now.getHours()).padStart(2, '0');
		const minute = String(now.getMinutes()).padStart(2, '0');
		const second = String(now.getSeconds()).padStart(2, '0');
		const millisecond = String(now.getMilliseconds()).padStart(3, '0'); 
		
		const timestamp = `[${year}-${month}-${day} ${hour}:${minute}:${second}.${millisecond}]`;
		const logMessage = `[${timestamp}] ${args.join(' ')}\n`;
		// 로그 파일 생성 및 권한 설정
		
		fs.open(logFilePath, 'a', (openErr, fd) => {
			if (openErr) {
				console.error('Open Error');
			} else {
				// 파일 권한 설정 (이 예제에서는 0o666 사용하여 읽기 및 쓰기 권한 설정)
				fs.fchmod(fd, 0o777, (chmodErr) => 
					{ if (chmodErr) {
						console.error('Owner Chmod Error', chmodErr);
					} else {
						// 로그를 파일에 추가
						fs.write(fd, logMessage, (writeErr) => {
							if (writeErr) {
							//	console.error('Log write error in File', writeErr);
							} else {
							//	console.log('Log Add Success');
							}
							// 파일 닫기
							fs.close(fd, (closeErr) => {
								if (closeErr) {
									console.error('Log close error', closeErr);
								}
							});
						});
					}
				});
			}
		});
	}
*/

let R_AT, L_AT, U_AT, D_AT;

function Save_AutoTrackingData() {
  const atrackPath = OPER_HOME_DIR + "auto_track.dat";
  console.log(atrackPath);

  //const lines = autopath.split('\n');
  // 파일을 동기적으로 읽어와 data 변수에 할당

  const at_data = fs.readFileSync(atrackPath, "utf8");

  const lines = at_data.split("\n");

  for (const line of lines) {
    const parts = line.trim().split(" ");
    if (parts.length >= 2) {
      const command = parts[0];
      const value = parseFloat(parts[1]);

      switch (command) {
        case "R":
          R_AT = value;
          break;

        case "L":
          L_AT = value;
          break;
        case "U":
          U_AT = value;
          break;
        case "D":
          D_AT = value;
          break;

        default:
          console.warn(`알 수 없는 명령: ${command}`);
          break;
      }
    }
  }

  console.log("U_AT:", U_AT);
  console.log("R_AT:", R_AT);
  console.log("D_AT:", D_AT);
  console.log("L_AT:", L_AT);
}

let S1_1, S1_2, S1_3, S1_4, S1_5;
let S1_C1, S1_C2, S1_C3, S1_C4, S1_C5;
let Add_Z, Add_C_Z;
let BSZ_1, BSZ_C1;

function Save_AutoS1_ForwardData() {
  console.log("Save_AutoS1_ForwardData");

  const s1forwdataPath = OPER_HOME_DIR + "auto_s1.dat"; // OPER_HOME_DIR 경로가 제대로 설정되어 있어야 합니다

  try {
    const s1_data = fs.readFileSync(s1forwdataPath, "utf8");
    const lines = s1_data.split("\n"); // 줄 단위로 나눕니다

    for (const line of lines) {
      const trimmedLine = line.trim();
      if (trimmedLine === "" || trimmedLine === "~" || trimmedLine === "#") {
        continue; // 빈 줄 또는 '~'만 있는 줄은 건너뛰기
      }

      const parts = trimmedLine.split(/\s+/); // 공백 기준으로 나눕니다

      if (parts.length >= 2) {
        const command = parts[0];
        const rawValue = parts[1]; // 원래 문자열 값을 유지
        let value = parseFloat(rawValue); // 숫자로 변환

        if (isNaN(value)) {
          //	console.warn(`잘못된 값: ${line}`);
          continue;
        }
        // 포맷 값 생성: 부호와 숫자 부분 분리 후 5자리 유지
        const formattedValue =
          value >= 0
            ? `+${value.toFixed(0).padStart(4, "0")}`
            : `-${Math.abs(value).toFixed(0).padStart(4, "0")}`;

        // 숫자 값과 원본 문자열을 각각 저장
        switch (command) {
          case "1":
            S1_1 = value;
            S1_C1 = formattedValue;
            break;

          case "2":
            S1_2 = value;
            S1_C2 = formattedValue;
            break;

          case "3":
            S1_3 = value;
            S1_C3 = formattedValue;
            break;

          case "4":
            S1_4 = value;
            S1_C4 = formattedValue;
            break;

          case "5":
            S1_5 = value;
            S1_C5 = formattedValue;
            break;

          case "AZ":
            Add_Z = value;
            Add_C_Z = formattedValue;
            break;

          case "BSZ1":
            BSZ_1 = value;
            BSZ_C1 = formattedValue;
            break;

          case "BSZ2":
            BSZ_2 = value;
            BSZ_C2 = formattedValue;
            break;

          case "BSZ3":
            BSZ_3 = value;
            BSZ_C3 = formattedValue;
            break;

          case "BSZ4":
            BSZ_4 = value;
            BSZ_C4 = formattedValue;
            break;

          case "BSZ5":
            BSZ_5 = value;
            BSZ_C5 = formattedValue;
            break;
          case "#":
            console.warn(`# Skip : ${command}`);
            break;
        }
      }
    }

    console.log("S1_1:", S1_1, "S1_C1:", S1_C1);
    console.log("S1_2:", S1_2, "S1_C2:", S1_C2);
    console.log("S1_3:", S1_3, "S1_C3:", S1_C3);
    console.log("S1_4:", S1_4, "S1_C4:", S1_C4);
    console.log("S1_5:", S1_5, "S1_C5:", S1_C5);
    console.log("S1_5:", S1_5, "S1_C5:", S1_C5);
    console.log("Add_Z:", Add_Z, "Add_C_Z:", Add_C_Z);
    console.log("BSZ_1:", BSZ_1, "BSZ_C_1:", BSZ_C1);
    console.log("BSZ_2:", BSZ_2, "BSZ_C_2:", BSZ_C2);
    console.log("BSZ_3:", BSZ_3, "BSZ_C_3:", BSZ_C3);
    console.log("BSZ_4:", BSZ_4, "BSZ_C_4:", BSZ_C4);
    console.log("BSZ_5:", BSZ_5, "BSZ_C_5:", BSZ_C5);
  } catch (error) {
    console.error("파일 읽기 오류:", error);
  }
}

async function GrrCaptureProcess() {
  console.log("== GrrCaptureProcess START = 3156 x 2340 ==");

  /*
		if (isExecuting) {
			console.warn('GrrCaptureProcess is already running.'); 
			return; // 이미 실행 중이면 종료
		} 
		*/

  isExecuting = true;

  const cppExecutablePath = "/home/nvidia/i-view100/umi_grr_capture";
  const command = `${cppExecutablePath} ${BackLight_Time}`;

  await new Promise((resolve, reject) => {
    //	const exec = require('child_process').exec;
    exec(command, (error, stdout, stderr) => {
      //	isExecuting = false; // 실행 완료 후 플래그 해제
      if (error) {
        console.error(`Error executing C++ program: ${error.message}`);
        reject(error);
        return;
      }
      if (stderr) {
        console.error(`C++ program STDERR: ${stderr}`);
        return reject(new Error(`Error output: ${stderr}`));
      }
      console.log(`C++ program output: ${stdout}`);
      resolve(stdout);
      console.log("== GrrCaptureProcess END = 3156 x 2340 ==");
    });
  });
}

// 24-03-07 add by mclee : AutoFocusng Function

async function Main_AutoFocusProcess() {
  log(`Main_AutoFocusProcess start`);

  let auto_wtimer = 10;
  let auto_focus_index = 0;
  let AF_dir = 0xff;
  let currentAF_ratio = 0;

  let sharpness_array = [];

  auto_focus_index = 0;

  await AutoRecoveryCamData();

  /*
		AutoPupil_LI_Serial(0);


		await AutoRecoveryCamData();
		await Node_sleep(40);	

		await AutoPupil_LF_Serial(0);
		await Node_sleep(40);	
		*/

  await extractLWValue();
  await AutoPupil_LW_LE_ModifiedSerial();
  await Node_sleep(10);
  await Node_sleep(20);

  /*
		const yszm_d = Add_sum / 20;
		const last_yszm_d = Math.abs(Math.round(yszm_d + 1));
		console.log('Add_sum, yszm_d lat_yszm_d=', Add_sum, yszm_d, last_yszm_d); 
		serialport.write('YSZM'+last_yszm_d);
		await Node_sleep(10);	
		*/

  // 실행
  await repeatAutoFocus();

  // 반복 함수 정의
  async function repeatAutoFocus() {
    console.log(
      "= Start repeatAutoFocus 1 Add_sum =",
      auto_focus_index,
      Add_sum
    );

    auto_wtimer = 10;
    await Node_sleep(auto_wtimer);

    //	await S2_Send_to_IF_Proc();

    /*

			if(auto_focus_index < 22)	{
				console.log('= Start repeatAutoFocus 1-1 =', auto_focus_index);
				AF_dir = 1;
			//	await Move_AF_Motor_Proc(1);

				auto_focus_index++;
				await	repeatAutoFocus();
			}
			/*
			else if(auto_focus_index >= 10 && auto_focus_index <= 19)	{
				console.log('= Start repeatAutoFocus 1-1 =', auto_focus_index);
				AF_dir = -1;
			//	await Move_AF_Motor_Proc(1);
				auto_focus_index++;

				await	repeatAutoFocus();
			}
			*/

    log(`======repeatAutoFocus Start======`);

    console.log("= Start repeatAutoFocus Cnt =", auto_focus_index);

    if (auto_focus_index === 0) {
      auto_wtimer = 100;
    } else {
      auto_wtimer = 500;
    }
    await Node_sleep(auto_wtimer);

    await autoFocus();

    currentAF_ratio = sharpness_array[auto_focus_index];

    if (auto_focus_index === 0) {
      console.log("= repeatAutoFocus index = 0");

      AF_dir = 1; // Firsrt, focus direction is forward
      await Move_AF_Motor_Proc(1);

      auto_focus_index++;

      await repeatAutoFocus();
    } else if (auto_focus_index === 1) {
      console.log("= repeatAutoFocus index = 1");

      AF_dir = -1; // focus direction is backward
      await Move_AF_Motor_Proc(2); // AF Position is 1 -> 0 -> -1

      auto_focus_index++;
      await repeatAutoFocus();
    } else if (auto_focus_index === 2) {
      console.log("= repeatAutoFocus index = 2");

      // sharpness_array의 전체 값을 출력합니다.
      console.log("sharpness_array의 전체 값:", sharpness_array);

      let maxSharpness = Math.max(...sharpness_array);
      let maxSIndex = sharpness_array.indexOf(maxSharpness);

      console.log(
        `가장 큰 Sharpness 비율: ${maxSIndex} (인덱스: ${maxSIndex})`
      );
      console.log("최대값:", maxSharpness);
      console.log("최대값의 인덱스:", maxSIndex);

      switch (maxSIndex) {
        case 0:
          console.log("= 0 :  position is Sharpness Max");
          AF_dir = 1; // Focus Motor position 0
          await Move_AF_Motor_Proc(1);
          AF_dir = 0; // Focus direction is Stop
          break;

        case 1:
          console.log("= 1 :  position is Sharpness Max");
          AF_dir = 1; // focus direction is forward
          await Move_AF_Motor_Proc(3);
          break;
        case 2:
          console.log("= 2 :  position is Sharpness Max");
          AF_dir = -1; // focus direction is backward
          await Move_AF_Motor_Proc(1);
          break;
      }

      if (AF_dir === 0) {
        await S2_Send_to_IF_Proc();
      } else {
        auto_focus_index++;
        await repeatAutoFocus();
      }
    } else if (auto_focus_index >= 3 && auto_focus_index < 8) {
      console.log("= repeatAutoFocus index = 3 ~ 8");

      let af_diff = 0;

      if (AF_dir === 1 && auto_focus_index === 3) {
        console.log("= repeatAutoFocus index = 4-1");
        af_data =
          sharpness_array[auto_focus_index] -
          sharpness_array[auto_focus_index - 2];
      } else {
        console.log("= repeatAutoFocus index = 4-1");
        af_data =
          sharpness_array[auto_focus_index] -
          sharpness_array[auto_focus_index - 1];
      }

      let re_data = Math.abs(af_data); // 절대값으로 변환

      console.log("= repeatAutoFocus index = 3", af_data, re_data);

      if (af_data < 0) {
        console.log("= repeatAutoFocus re_data Negative");

        AF_dir = AF_dir * -1;
        await Move_AF_Motor_Proc(1); // focus Motor go to previous location
        AF_dir = 0; // Focus Motor move stop
        await Node_sleep(200);

        console.log(
          "=== Previous position moved to maximumd and AutoFocusProcess"
        );

        await S2_Send_to_IF_Proc();
      } else {
        console.log("= repeatAutoFocus re_data Positive");

        await Move_AF_Motor_Proc(1);
        auto_focus_index++;

        await repeatAutoFocus();
      }
    }
  }

  //	let last_yszm_d = 0;

  async function S2_Send_to_IF_Proc() {
    log(` S2_Send_to_IF_Proc Start : S2`);

    await Node_sleep(20);
    Auto_Status = 4; // Auto Search End
    //	log(` S2_Send_to_IF_Proc Start : S2`)
    //	serialport.write('S2');
    //	await Node_sleep(30);
    const yszm_d = Add_sum / 20;
    const last_yszm_d = Math.abs(Math.round(yszm_d + 2));
    serialport.write("YSZM" + last_yszm_d);
    await Node_sleep(30);

    serialport.write("S2");
    //	await Node_sleep(30);
  }

  async function autoFocus() {
    log(`== autoFocus start==`);
    console.log("= autoFocus start=", auto_focus_index);
    await ffmpeg_capture_proc1(0, auto_focus_index);
    //	await Node_sleep(200);

    try {
      //	const contrast = await calculateContrast(auto_focus_index, eye_position);
      const shaprness = await calculateSharprnss(
        auto_focus_index,
        eye_position
      );

      sharpness_array[auto_focus_index] = shaprness;
      console.log(`Calcu_shaprness: ${shaprness}`);
      console.log(
        `sharpness_array[${auto_focus_index}] : ${sharpness_array[auto_focus_index]}`
      );
    } catch (error) {
      console.error(`Error in calculateSharprnss: ${error}`);
    }
  }

  async function Move_AF_Motor_Proc(af_cnt) {
    console.log("= Move_AF_Motor_Proc proces start=", af_cnt);

    //	let real_afmove = 6 * af_cnt;
    let real_afmove = 4 * af_cnt;

    if (AF_dir === 1) {
      // focus motor direction is forward
      serialport.write("MF+00" + real_afmove);
    } else if (AF_dir === -1) {
      // focus motor direction is forward
      serialport.write("MF-00" + real_afmove);
    } else {
      console.log("= AF_dir =", AF_dir);
    }

    switch (af_cnt) {
      case 0:
        auto_wtimer = 0; // 0 msec
        break;

      case 1: // Z step 20
        //	auto_wtimer = 216; // 216 msec
        auto_wtimer = 180; // 216 msec
        break;
      case 2: // Z step 20
        //	auto_wtimer = 432; // 336 msec
        auto_wtimer = 300; // 336 msec
        break;
      case 3: // Z step 20
        //	auto_wtimer = 580; // 336 msec
        auto_wtimer = 450; // 336 msec
        break;
    }
    await Node_sleep(auto_wtimer);
  }
}

// 24-03-07 add by mclee : AutoFocusng Function

async function calculateContrast(con_index, eye_pos) {
  log(`calculateContrast START`);

  let org_imgPath;
  const cppExecontrastPath = "/home/nvidia/i-view100/umi_autofocus";

  // 이미지 경로 설정 (전역 변수 auto_focus_index 사용)
  if (eye_pos === "OD") {
    // 오른쪽 눈
    //	org_imgPath = `/home/nvidia/i-view100/AF/s1_od_${con_index}.jpg`;
    org_imgPath = `/home/nvidia/i-view100/AF/AutoF_od_${con_index}.jpg`;
  } else {
    //	org_imgPath = `/home/nvidia/i-view100/AF/s1_os_${con_index}.jpg`;
    org_imgPath = `/home/nvidia/i-view100/AF/AutoF_os_${con_index}.jpg`;
  }

  // 실행할 명령어 정의
  const command = spawn(cppExecontrastPath, [org_imgPath]);
  //  console.log('= Running command:', command);

  return new Promise((resolve, reject) => {
    let stdout = "";
    let stderr = "";

    // stdout 데이터 수집
    command.stdout.on("data", (data) => {
      stdout += data.toString();
    });

    // stderr 데이터 수집
    command.stderr.on("data", (data) => {
      stderr += data.toString();
    });

    // 명령어 실행 완료 시
    command.on("close", (code) => {
      console.log("= calculateContrast END =");
      if (code !== 0) {
        console.error(`Command exited with code ${code}`);
        console.error(`Command returned an error: ${stderr}`);
        return reject(
          new Error(stderr || `Command failed with exit code ${code}`)
        );
      }

      // stdout에서 "Cal_contrast: " 문자열을 찾아 대비 값 추출
      const contrastIndex = stdout.indexOf("Cal_contrast:");
      if (contrastIndex === -1) {
        console.error(`Invalid contrast value: ${stdout}`);
        return reject(new Error("Invalid contrast value"));
      }

      // 대비 값 추출
      const contrastString = stdout.substring(contrastIndex + 13).trim(); // "Cal_contrast: "의 길이는 13
      const contrast = parseFloat(contrastString);

      if (isNaN(contrast)) {
        console.error(`Invalid contrast value: ${stdout}`);
        return reject(new Error("Invalid contrast value"));
      }

      resolve(contrast); // 대비 값을 반환
    });
  });
}

/*

	async function calculateSharprnss(sh_index, eye_pos) {
	    log(`calculateSharprnss START`)

	    let org_imgPath;
	    const cppExesharpnesstPath = '/home/nvidia/i-view100/umi_autofocus2';

	    // 이미지 경로 설정 (전역 변수 auto_focus_index 사용)
	    if (eye_pos === "OD") {  // 오른쪽 눈
		org_imgPath = `/home/nvidia/i-view100/AF/AutoF_od_${sh_index}.jpg`;
	    } else {
		org_imgPath = `/home/nvidia/i-view100/AF/AutoF_os_${sh_index}.jpg`;
	    }

	    // 실행할 명령어 정의
	    const command = spawn(cppExesharpnesstPath, [org_imgPath], eye_pos, 160);

	    return new Promise((resolve, reject) => {
		let stdout = '';
		let stderr = '';

		// stdout 데이터 수집
		command.stdout.on('data', (data) => {
		    stdout += data.toString();
		});

		// stderr 데이터 수집
		command.stderr.on('data', (data) => {
		    stderr += data.toString();
		});

		// 명령어 실행 완료 시
		command.on('close', (code) => {
		    if (code !== 0) {
			console.error(`Command exited with code ${code}`);
			console.error(`Command returned an error: ${stderr}`);
			return reject(new Error(stderr || `Command failed with exit code ${code}`));
		    }

		    // stdout에서 "Cal_sharpness: " 문자열을 찾아 대비 값 추출
		    const sharpnessIndex = stdout.indexOf('Cal_sharpness:');
		    if (sharpnessIndex === -1) {
			console.error(`Invalid sharpness value: ${stdout}`);
			return reject(new Error("Invalid sharpness value"));
		    }

		    // sharpness 값 추출
		    const sharsharpnesspnessString = stdout.substring(sharpnessIndex + 14).trim(); // "Cal_sharpness: "의 길이는 14
		    const sharpness = parseFloat(sharpnessString);

		    if (isNaN()) {
			console.error(`Invalid sharpness value: ${stdout}`);
			return reject(new Error("Invalid sharpness value"));
		    }

		    resolve(sharpness);  // sharpness 값을 반환
		});
	    });
	}
	*/

// sharpness 계산 함수
async function calculateSharprnss(sh_index, eye_pos) {
  log(`calculateSharprnss START`);
  console.log(`calculateSharpness START: index=${sh_index}, eye=${eye_pos}`);

  const cppExeSharpnessPath = "/home/nvidia/i-view100/umi_autofocus3";
  let org_imgPath;
  let move_x_offset;

  // 입력 이미지 경로 설정
  if (eye_pos === "OD") {
    org_imgPath = `/home/nvidia/i-view100/AF/AutoS1_ODF${sh_index}.jpg`;
    move_x_offset = -160;
  } else {
    org_imgPath = `/home/nvidia/i-view100/AF/AutoS1_OSF${sh_index}.jpg`;
    move_x_offset = 160;
  }

  console.log(org_imgPath);

  // spawn 호출 시 argv 배열 (inputPath, eyeType, shiftX)
  // const args = [org_imgPath, eye_pos, "160"];
  const args = [org_imgPath, eye_pos, move_x_offset];
  const command = spawn(cppExeSharpnessPath, args);
  return new Promise((resolve, reject) => {
    let stdout = "";
    let stderr = "";
    command.stdout.on("data", (data) => {
      stdout += data.toString();
    });

    command.stderr.on("data", (data) => {
      stderr += data.toString();
    });

    command.on("close", (code) => {
      if (code !== 0) {
        return reject(
          new Error(stderr || `Command failed with exit code ${code}`)
        );
      }
      // JSON 파싱하여 sharpness 값 추출
      try {
        const result = JSON.parse(stdout);
        if (result.status === "success" && !isNaN(result.sharpness)) {
          resolve(result.sharpness);
        } else {
          reject(new Error("Invalid result: " + stdout));
        }
      } catch (e) {
        reject(new Error("JSON parse error: " + stdout));
      }
    });
  });
}

async function AutoPupil_Z_Forward(adjustedZStep, zf_quotient, zf_remainder) {
  log(`AutoPupil_Z_Forward Start`);
  console.log("z, q, f", adjustedZStep, zf_quotient, zf_remainder);

  await ChangeAutoRetinaCamData();

  serialport.write("MZ+0000");
  await Node_sleep(10);
  //	await setExposure_absolute(1,500);
  //	await Node_sleep(40);
  //	await setSaturationMode(1, 0);

  //	await setBrightnessMode(1,4);
  serialport.write("YSZM0");
  //	await Node_sleep(50);
  //	await ChangeAutoRetinaCamData();
  await Node_sleep(30);

  setTimeout(() => {
    let idx = 0;
    let intervalduration = 750; // 시간 간격 설정 (단위: 밀리초)

    // 지정된 시간 간격으로 데이터 전송
    const send_z_datainterval = setInterval(async () => {
      log(`send_z_datainterval START`);
      console.log("add Sum", idx, Add_sum);
      if (Auto_Status !== 1) {
        clearInterval(send_z_datainterval); // 모든 데이터 전송이 완료되면 반복 작업 종료
        return;
      }
      console.log(idx);
      if (idx < zf_quotient) {
        // Human
        log(`======send MZ+0250 start======`);
        serialport.write("MZ+0250");
        Add_sum = Add_sum + 250;
      } else if (idx === zf_quotient) {
        log(`======send MZ+LAST start======`);
        console.log("Last Sum", idx, Add_sum);

        if (zf_remainder !== 0) {
          if (zf_remainder < 10) serialport.write(`MZ+000${zf_remainder}`);
          else if (zf_remainder < 100) serialport.write(`MZ+00${zf_remainder}`);
          else serialport.write(`MZ+0${zf_remainder}`);

          Add_sum += zf_remainder;
          console.log("Last Sum", idx, Add_sum);
        }
        clearInterval(send_z_datainterval);
        //	userSleep(200);
        //	await Node_sleep(250);
        await Node_sleep(300);

        //	return;
        Main_S1_AutoSearchRetina();
      }
      idx++;
    }, intervalduration); // 지정된 시간 간격으로 데이터 전송
  }, 1);
}

async function Search_Retina_preporcess() {
  log(`Search_Retina_preporcess Start`);
  //	return;

  //	S1_received = 1;
  Add_sum = 0; // Human Test org ; 1100

  Auto_Status = 1;
  log(`=== Auto SHoot Start === `);

  //	adjustedZStep = 1200;
  //	adjustedZStep = 1000;

  const zf_quotient = Math.floor(adjustedZStep / 250); // 반올림 대신 버림 (내림)
  const zf_remainder = adjustedZStep % 250; // 나머지

  console.log(
    "adjustedZStep, zf_quotient, zf_remainde:r",
    adjustedZStep,
    zf_quotient,
    zf_remainder
  );

  await AutoPupil_Z_Forward(adjustedZStep, zf_quotient, zf_remainder);
}

async function AutoPupil_LF_Serial(mode = 0, lfValue = 0) {
  log(`AutoPupil_LF_Serial Start`);
  console.log("모드:", mode, "입력 LF 값:", lfValue);

  const path = OPER_HOME_DIR + "led_set.dat";
  console.log(path);

  fs.readFile(path, "utf8", (err, data) => {
    if (err) {
      console.error("파일을 읽는 중 오류 발생:", err);
      return;
    }

    const lines = data.split("\n");

    lines.forEach((line) => {
      const match = line.match(/^LF\s*(\d+)/); // LF로 시작하는 줄 찾기
      if (match) {
        const originalLfValue = match[1]; // 원래 LF 값
        let targetLine = line;

        if (mode === 1) {
          const newLF = lfValue.toString().padStart(2, "0");
          targetLine = line.replace(/LF\s*\d+/, `LF ${newLF}`);
          console.log(`LF 변경: 원래=${originalLfValue}, 변경=${newLF}`);
        } else {
          console.log(`LF 유지: ${originalLfValue}`);
        }

        const cleanedLine = targetLine.replace(/\s+/g, "");
        // 시리얼 전송
        serialport.write(cleanedLine, (err) => {
          if (err) {
            console.error("데이터 전송 오류:", err);
          } else {
            console.log("데이터 전송 완료:", cleanedLine);
          }
        });
      }
    });
  });
}

async function AutoPupil_LI_Serial(mode = 0, liValue = 0) {
  log(`AutoPupil_LI_Serial Start`);
  console.log("모드:", mode, "입력 LI 값:", liValue);

  const path = OPER_HOME_DIR + "led_set.dat";
  console.log(path);

  fs.readFile(path, "utf8", (err, data) => {
    if (err) {
      console.error("파일을 읽는 중 오류 발생:", err);
      return;
    }

    const lines = data.split("\n");

    lines.forEach((line) => {
      const match = line.match(/^LI\s*(\d+)/); // LF로 시작하는 줄 찾기
      if (match) {
        const originalLiValue = match[1]; // 원래 LI 값
        let targetLine = line;

        if (mode === 1) {
          const newLI = liValue.toString().padStart(2, "0");
          targetLine = line.replace(/LI\s*\d+/, `LI ${newLI}`);
          console.log(`LI 변경: 원래=${originalLiValue}, 변경=${newLI}`);
        } else {
          console.log(`LI 유지: ${originalLiValue}`);
        }

        const cleanedLine = targetLine.replace(/\s+/g, "");
        // 시리얼 전송
        serialport.write(cleanedLine, (err) => {
          if (err) {
            console.error("데이터 전송 오류:", err);
          } else {
            console.log("데이터 전송 완료:", cleanedLine);
          }
        });
      }
    });
  });
}

async function ChangeAutoRetinaCamData() {
  console.log("ChangeAutoRetinaCamData 호출됨");

  try {
    const { stdout, stderr } = await execAsync(
      "/usr/bin/uvcdynctrl -L /home/nvidia/i-view100/auto_retina.dat"
    );
    if (stderr && stderr.trim()) {
      console.warn(`?? stderr: ${stderr}`);
    }
    if (stdout && stdout.trim()) {
      console.log(`? stdout: ${stdout}`);
    } else {
      console.log(" Retina 환경 카메라 설정이 적용되었습니다.");
    }
  } catch (error) {
    console.error(`? 실행 오류: ${error.message}`);
  }
}

// ?? 비동기 함수: 카메라 설정 복구
async function AutoRecoveryCamData() {
  console.log("AutoRecoveryCamData 호출됨");

  try {
    const { stdout, stderr } = await execAsync(
      "/usr/bin/uvcdynctrl -L /home/nvidia/i-view100/cam_para.dat"
    );
    if (stderr && stderr.trim()) {
      console.warn(`?? stderr: ${stderr}`);
    }
    if (stdout && stdout.trim()) {
      console.log(`? stdout: ${stdout}`);
    } else {
      console.log("? 카메라 설정이 정상적으로 적용되었습니다.");
    }
  } catch (error) {
    console.error(`? 실행 오류: ${error.message}`);
  }
}

async function AutoPupil_LW_LE_ModifiedSerial() {
  log(`AutoPupil_LW_LE_ModifiedSerial Start`);

  let Ref_Z_ForStep = 1200; // YSZM51 -> 56 click (56 x 20 = 1120 step)

  let TARGET_LE_VAL = 0;

  console.log(`Add_sum: ${Add_sum}, now_pupil_Area:${now_pupil_Area}`);
  //	now_pupil_Area = 35180;
  console.log("change now_pupil_Area :", now_pupil_Area);

  await Calculate_BasicLE_values();

  console.log(`add_offset: ${adjustedLE_values}`);

  const path = OPER_HOME_DIR + "led_set.dat";
  console.log(path);

  const ZforwardRate = Add_sum / Ref_Z_ForStep;
  //	const ZforwardRate = ZforwardRate -1;
  console.log(
    "LW Base, Add_sum, ZforwardRate :",
    LW_Base,
    Add_sum,
    ZforwardRate
  );

  const TARGET_LE_VAL1 = LW_Base + ZforwardRate; // 특정 값으로 변경 (원하는 값으로 대체)

  console.log("TARGET_VAL1 = ", TARGET_LE_VAL1);
  //	const TARGET_LE_VAL2 = Math.ceil(TARGET_LE_VAL1);		// 무조건 올림
  const TARGET_LE_VAL2 = Math.round(TARGET_LE_VAL1); // 무조건  현재 정수값
  console.log("TARGET_VAL2 = ", TARGET_LE_VAL2);

  if (Add_sum > 1300) {
    TARGET_LE_VAL = TARGET_LE_VAL2 + adjustedLE_values - 1; // 특정 값으로 변경 (원하는 값으로 대체)
  } else {
    TARGET_LE_VAL = TARGET_LE_VAL2 + adjustedLE_values - 1; // 특정 값으로 변경 (원하는 값으로 대체)
  }

  console.log("TARGET_LE_VAL =  ", TARGET_LE_VAL);

  // 파일 읽기 및 처리
  fs.readFile(path, "utf8", (err, data) => {
    if (err) {
      console.error("파일을 읽는 중 오류 발생:", err);
      return;
    }
    // 각 줄 별로 처리
    const lines = data.split("\n");
    lines.forEach((line) => {
      const match = line.match(/^LW\s*(\d+)/); // LW 뒤에 오는 숫자 추출

      if (match) {
        const modifiedLine = line.replace(/^LW\s*\d+/, `LE ${TARGET_LE_VAL}`);
        const cleanedLine = modifiedLine.replace(/\s+/g, ""); // 공백 제거
        //	console.log('전송 데이터:', cleanedLine);

        // 시리얼 포트를 통해 데이터 전송
        serialport.write(cleanedLine, (err) => {
          if (err) {
            console.error("데이터 전송 오류:", err);
          } else {
            console.log("데이터 전송 완료");
          }
        });
      }
    });
  });
}

function findRangeIndex(value, ranges) {
  const index = ranges.findIndex(([min, max]) => value >= min && value <= max);
  return index !== -1 ? index : -1; // 배열 인덱스를 그대로 사용
}

// ?? 대역 범위 설정
const ZStepRanges = [
  [50000.0, Infinity], // 1번 대역 (Pupil Area : 40,000 이상 값)           -> 1단계
  [45000.0, 49999.999], // 2번 대역 (Pupil Area : 39,000 ~ 39,999 값) 	    -> 1단계
  [40000.0, 44999.999], // 3번 대역 (Pupil Area : 39,000 ~ 39,999 값) 	    -> 1단계
  [39000.0, 39999.999], // 4번 대역 (Pupil Area : 39,000 ~ 39,999 값) 	    -> 1.5단계
  [38000.0, 38999.999], // 5번 대역 (Pupil Area : 38,000 ~ 38,999 값)       -> 2단계
  [37000.0, 37999.999], // 6번 대역 (Pupil Area : 36,800 ~ 36,999)          -> 2.5 단계
  [36000.0, 36999.999], // 7번 대역 (Pupil Area : 36,800 ~ 36,999)          -> 3 단계
  [35000.0, 35999.999], // 8번 대역 (Pupil Area : 36,800 ~ 36,999)          -> 3 단계
  [34000.0, 34999.999], // 9번 대역 (Pupil Area : 36,800 ~ 36,999)          -> 2 단계
  [33000.0, 33999.999], // 10번 대역 (Pupil Area : 36,800 ~ 36,999)          -> 2 단계
  [32000.0, 32999.999], // 11번 대역 (Pupil Area : 30,000 ~ 36,999 모든 값)  -> 3.5 단계
  [30000.0, 31999.999], // 12번 대역 (Pupil Area : 30,000 ~ 36,999 모든 값)  -> 3.5 단계
  [27000.0, 29999.999], // 13번 대역 (Pupil Area : 30,000 ~ 36,999 모든 값)  -> 4 단계
  [26000.0, 26999.999], // 14번 대역 (Pupil Area : 30,000 ~ 36,999 모든 값)  -> 4 단계
  [25000.0, 25999.999], // 15번 대역 (Pupil Area : 30,000 ~ 36,999 모든 값)  -> 4.5 단계
  [24000.0, 24999.999], // 16번 대역 (Pupil Area : 30,000 ~ 36,999 모든 값)  -> 4.5 단계
  [22000.0, 23999.999], // 17번 대역 (Pupil Area : 30,000 ~ 36,999 모든 값)  -> 4.5 단계
  [21000.0, 21999.999], // 18번 대역 (Pupil Area : 30,000 ~ 36,999 모든 값)  -> 4.5 단계
  [20000.0, 20999.999], // 19번 대역 (Pupil Area : 30,000 ~ 36,999 모든 값)  -> 5 단계
  [19000.0, 19999.999], // 20번 대역 (Pupil Area : 16,790 ~ 17,399 모든 값) -> 5 단계
  [18000.0, 18999.999], // 21번 대역 (Pupil Area : 16,790 ~ 17,399 모든 값) -> 5 단계
  [17000.0, 17999.999], // 22번 대역 (Pupil Area : 16,790 ~ 17,399 모든 값) -> 5 단계
  [16000.0, 16999.999], // 23번 대역 (Pupil Area : 16,790 ~ 17,399 모든 값) -> 5 단계
  [15000.0, 15999.999], // 24번 대역 (Pupil Area : 15,800 ~ 16,789 모든 값) -> 5.5 단계
  [14000.0, 14999.999], // 25번 대역 (Pupil Area : 15,800 ~ 16,789 모든 값) -> 6 단계
  [12000.0, 13999.999], // 26번 대역 (Pupil Area : 15,800 ~ 16,789 모든 값) -> 6 단계
  [11000.0, 11999.999], // 27번 대역 (Pupil Area : 15,800 ~ 16,789 모든 값) -> 6 단계
  [10000.0, 10999.999], // 28번 대역 (Pupil Area : 15,800 ~ 16,789 모든 값) -> 6.5 단계
  [0.0, 9999.999], // 29번 대역 (Pupil 9999 ~ 0)                      ->  7 단계
];
// 	                            1    2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26    27    28    29
//	const adjusZstepvalues = [ 850, 850,  850,  890,   900,  910,  920,  990 , 990,  1000, 1000, 1010, 1010, 1010, 1020, 1030, 1030, 1030, 1040, 1050, 1050, 1050, 1060, 1070, 1080, 1080, 1080, 1080, 1080] // 각 대역별 Z Step 조정 값
const adjusZstepvalues = [
  720, 730, 740, 750, 760, 770, 780, 780, 780, 800, 810, 810, 820, 820, 820,
  830, 830, 830, 840, 840, 840, 850, 850, 860, 860, 860, 870, 880, 890,
]; // 각 대역별 Z Step 조정 값

const PupilRanges = [
  [50000.0, Infinity], // 1번 대역 (Pupil Area : 50,000 이상 값)           -> 1   단계 -4
  [40000.0, 49999.999], // 2번 대역 (Pupil Area : 40,000 ~ 49,999 값) 	    -> 1.5 단계 -3
  [38000.0, 39999.999], // 3번 대역 (Pupil Area : 36,000 ~ 39,999 값) 	    -> 2   단계 -2
  [36000.0, 37999.999], // 4번 대역 (Pupil Area : 36,000 ~ 39,999 값) 	    -> 2.3  단계 -2
  [33000.0, 35999.999], // 5번 대역 (Pupil Area : 33,000 ~ 35,999 값)       -> 2.5 단계 -1
  [29000.0, 32999.999], // 6번 대역 (Pupil Area : 29,000 ~ 32,999)          -> 3   단계, 표준
  [26000.0, 28999.999], // 7번 대역 (Pupil Area : 26,000 ~ 28,999)          -> 3.5 단계 +1
  [23000.0, 25999.999], // 8번 대역 (Pupil Area : 23,000 ~ 25,999)          -> 4   단계 +4
  [22000.0, 22999.999], // 9번 대역 (Pupil Area : 20,000 ~ 22,999 값)       -> 4.5 단계 +6
  [20000.0, 21999.999], // 10번 대역 (Pupil Area : 20,000 ~ 22,999 값)       -> 4.5 단계 +6
  [17000.0, 19999.999], // 11번 대역 (Pupil Area : 17,000 ~ 19,999  값)      -> 5   단계 +9
  [14000.0, 16999.999], // 12번 대역 (Pupil Area : 14,000 ~ 16,999 값)      -> 5.5 단계 +11
  [11000.0, 13999.999], // 13번 대역 (Pupil Area : 11,000 ~ 13,999 값)      -> 6   단계 +12
  [9000.0, 10999.999], // 14번 대역 (Pupil Area :  9,000 ~ 10,999 값)      -> 6.5 단계 +13
  [0.0, 8999.999], // 15번 대역 (Pupil 9999 ~ 0)                       -> 7   단계 +14
];

// 	                            1    2     3     4     5     6     7     8     9     10    11    12    13   14   15
//	const adjusLEvalues =    [ -6,  -5,   -4,   -3,    -2,   -1,   0,    0,    1,    2,    3,    3,    4,   4,   4]; // 각 대역별 LW 조정 값
const adjusLEvalues = [-6, -5, -4, -3, -1, -1, 0, 1, 2, 2, 3, 3, 4, 4, 4]; // 각 대역별 LW 조정 값

let now_pupil_Area = 0;
let LW_Base = 0;
let adjustedZStep = 900;
//	let adjustedLE = 0;
let adjustedLE_values = 0;

async function Cal_BasicZstep_values(inputValues) {
  log(`Cal_BasicZstep_values Start`);
  console.log("inputValues :", inputValues, now_pupil_Area);
  //inputValues = 32207;

  // 잘못된 변수명(inputValue → inputValues) 수정
  if (typeof inputValues !== "number") {
    console.error("Error: inputValues must be a number!", inputValues);
    return;
  }
  const rangeIndex = await findRangeIndex(inputValues, ZStepRanges);
  adjustedZStep = rangeIndex !== -1 ? adjusZstepvalues[rangeIndex] : "N/A";
  //	adjustedZStep = 750;
  console.log(
    `${inputValues}은(는) ${
      rangeIndex + 1
    }번 대역 -> 조정된 ZStep 값: ${adjustedZStep}`
  );
}

async function Calculate_BasicLE_values() {
  log(`Calculate_BasicLE_values Start`);

  console.log("now_pupil_Area :", now_pupil_Area);

  if (typeof now_pupil_Area !== "number") {
    console.error("Error: now_pupil_Area must be a number!", now_pupil_Area);
    return;
  }
  const pupilsize_Index = await findRangeIndex(now_pupil_Area, PupilRanges);
  adjustedLE_values =
    pupilsize_Index !== -1 ? adjusLEvalues[pupilsize_Index] : "N/A";
  console.log(
    `${now_pupil_Area}은(는) ${
      pupilsize_Index + 1
    }번 대역 -> 조정된 LE_Value 값: ${adjustedLE_values}`
  );
}

async function extractLWValue() {
  log(`extractLWValue`);
  const path = OPER_HOME_DIR + "led_set.dat";
  console.log(path);
  try {
    const data = await fsp.readFile(path, "utf8");
    //	const data = fs.readFile(path, 'utf8');
    const match = data.match(/\bLW\s+(\d+)/);

    if (match) {
      LW_Base = parseInt(match[1], 10);
      console.log("LW 값:", LW_Base);
    } else {
      console.log("LW 값이 없습니다.");
      return null;
    }
  } catch (error) {
    console.error("파일을 읽을 수 없습니다.", error);
  }
}

//	let now_pupil_Area = 0;
async function Main_AutoPupilSearch(pupil_x, pupil_y) {
  //	const circuit_X_define = 402;
  //	const circuit_Y_define = 280;
  //	const circuit_X_define = 400;
  //	const circuit_Y_define = 300;
  const circuit_X_define = 392;
  const circuit_Y_define = 292;

  //	const crop_X_define = 402;
  //	const crop_Y_define = 280;
  //	const crop_X_define = 400;
  //	const crop_Y_define = 300;
  const crop_X_define = 392;
  const crop_Y_define = 292;
  let Pupil_result_array = []; // Pupil Data

  let auto_pupil_index = 0;
  let PupilSearch = 0;
  let now_pupil_x = 0;
  let now_pupil_y = 0;
  //	let now_pupil_radius = 0;
  //	let now_pupil_Area = 0;

  let pupil_flag = 0;

  let find_x = 1;
  let find_y = 1;

  let abs_x_div = 12;
  let abs_y_div = 12;

  //	let repeat_pupil_cnt = 3
  //	let repeat_pupil_cnt = 1
  let repeat_pupil_cnt = 2;

  log(`Main_AutoPupilSearch Start`);

  console.log(" Click X pupil  :", pupil_x);
  console.log(" Click y pupil  :", pupil_y);
  console.log(" Auto_Status  :", Auto_Status);

  if (Auto_Status !== 0) {
    console.log(" It's already shooting automatically.");
    return;
  }

  Auto_Status = 1; // White S

  let diff_x = circuit_X_define - pupil_x;
  let diff_y = circuit_Y_define - pupil_y;

  console.log(" diff_x :", diff_x);
  console.log(" diff_y :", diff_y);

  await AutoPupil_LF_Serial(1, 99);
  await Node_sleep(30);
  await setExposure_absolute(1, 100);
  await setSaturationMode(1, 0);
  await setBrightnessMode(1, -1);
  await Node_sleep(10);

  await Move_Y_process(diff_y, 0);
  await Move_X_process(diff_x, 0);

  Auto_Retin_sts = 0;
  Add_sum = 0;

  await repeatAutoSearchPupil();

  async function repeatAutoSearchPupil() {
    log(`== repeatAutoSearchPupil start ==`);
    console.log(
      " auto_pupil_index, find_x, find_y, Auto_Status :",
      auto_pupil_index,
      find_x,
      find_y,
      Auto_Status
    );

    if (Auto_Status !== 1) return;

    if (find_x === 0 && find_y === 0) {
      console.log(" Searching Pupli X,Y Success :");
      if (now_pupil_Area > 80_000) {
        console.log(" now_pupil_Area ls are too large.:", now_pupil_Area);
        now_pupil_Area = 35_000;
      }
      await Cal_BasicZstep_values(now_pupil_Area);
      await Search_Retina_preporcess();
      return;
    }

    if (auto_pupil_index >= repeat_pupil_cnt) {
      console.log(" Searching Pupli Fail: waiting AG Repeat");

      find_x = 0;
      find_y = 0;

      adjustedZStep = 860; // pupil searching 실패시 현재 위치에서 전진

      await Cal_BasicZstep_values(now_pupil_Area);
      await Search_Retina_preporcess();
      return;
    }

    await Node_sleep(10);

    await autoS_Pupil();

    if (now_pupil_Area > 80000) {
      // Size > 100,000 Error
      console.log(
        "now_pupil_Area is larger than 100,000 pixels. Retry Searching pupil:",
        now_pupil_Area
      );
      now_pupil_Area = 35000;
      PupilSearch = 1;
    }

    if (PupilSearch === 0) {
      // Pupil OK

      console.log("Pupil Search Sucess :", PupilSearch);

      diff_x = crop_X_define - now_pupil_x;
      diff_y = crop_Y_define - now_pupil_y;

      console.log(" c_diff_x :", diff_x);
      console.log(" c_diff_y :", diff_y);

      let abs_x = Math.round(Math.abs(diff_x));
      let abs_y = Math.round(Math.abs(diff_y));

      console.log(
        " 1 : abs_y, abs_x, find_y, find_x :",
        abs_y,
        abs_x,
        find_y,
        find_x
      );

      if (abs_y > abs_y_div) {
        find_y = 1; // need search
        await Move_Y_process(diff_y, 1);

        /*
					if(abs_x > abs_x_div)   {
						await Node_sleep(400);
					}
					else	{
						await Node_sleep(100);
					}
					*/
        await Node_sleep(100);
      } else {
        find_y = 0; // Noneed search
      }
      console.log(
        "2 :  abs_y, abs_x, find_y, find_x :",
        abs_y,
        abs_x,
        find_y,
        find_x
      );

      if (abs_x > abs_x_div) {
        find_x = 1;
        await Move_X_process(diff_x, 1);
        await Node_sleep(100);
      } else {
        find_x = 0;
      }

      auto_pupil_index++;
      console.log("Again Pupil Serach :", PupilSearch);
      await repeatAutoSearchPupil();
    } else {
      console.log("Pupil Serach Fail :", PupilSearch);
      auto_pupil_index++;
      await repeatAutoSearchPupil();
    }
  }

  async function Move_X_process(d_x, s_point_x) {
    log(`== Move_X_process start ==`);
    console.log(" d_x pupil_index :", d_x, s_point_x, auto_pupil_index);

    let move_x = 0;
    let x_timer = 50;

    if (d_x === 0) {
      console.log(" Move_X_process 0 Error");
      return;
    }
    console.log(" Move_X_process 0");
    if (d_x < 0) {
      //  Right -> Center
      console.log(" d_x negative Move_X_process 1");
      //	move_x = Math.round(Math.abs(d_x * 0.655));
      move_x = Math.round(Math.abs(d_x * 0.665));
    } else {
      // Left -> Cneter
      console.log(" d_x positive Move_X_process 2");
      //	move_x = Math.round(Math.abs(d_x * 0.670));
      move_x = Math.round(Math.abs(d_x * 0.64));
    }

    /*
			if(auto_pupil_index === 0)	{ 
				console.log(" Move_X_process 1"); 
				if(d_x < 0) { 
					console.log(" Move_X_process 2"); 
					move_x = Math.round(Math.abs(d_x * 0.760)); 
				}
				else {
					console.log(" Move_X_process 3"); 
					move_x = Math.round(Math.abs(d_x * 0.760)); 
				}
			}
			else	{
				console.log(" Move_X_process 4"); 
				if(d_x < 0) { 
					console.log(" Move_X_process 5"); 
					move_x = Math.round(Math.abs(d_x * 0.600)); 
				}
				else {
					console.log(" Move_X_process 6"); 
					move_x = Math.round(Math.abs(d_x * 0.600)); 
				}
			}
			*/
    //
    // 절대값을 반올림한 값으로 변환

    console.log(" move_x :", move_x);
    const x_quotient = Math.floor(move_x / 250); // 몫
    const x_remainder = move_x % 250; // 나머지
    console.log(`몫: ${x_quotient}, 나머지: ${x_remainder}`);

    if (d_x < 0) {
      if (x_quotient > 0) {
        for (let i = 0; i < x_quotient; i++) {
          serialport.write("MX+0250"); // Right 이동 명령
        }
        await Node_sleep(700);
      }

      if (x_remainder < 10 && x_remainder > 0) {
        serialport.write("MX+000" + x_remainder); // Right 이동 명령
        //	x_timer = 250;
        x_timer = 200;
      } else if (x_remainder < 100) {
        serialport.write("MX+00" + x_remainder); // Right 이동 명령
        x_timer = 450;
      } else {
        serialport.write("MX+0" + x_remainder); // Right 이동 명령
        x_timer = 600;
      }
    } else {
      if (x_quotient > 0) {
        for (i = 0; i < x_quotient; i++) {
          serialport.write("MX-0250"); // Left 이동 명령
        }
        await Node_sleep(700);
      }

      if (x_remainder < 10 && x_remainder > 0) {
        serialport.write("MX-000" + x_remainder); // Left 이동 명령
        //	x_timer = 250;
        x_timer = 200;
      } else if (move_x < 100) {
        serialport.write("MX-00" + x_remainder); // Left 이동 명령
        x_timer = 450;
      } else {
        serialport.write("MX-0" + x_remainder); // Left 이동 명령
        x_timer = 600;
      }
    }

    if (s_point_x === 0) {
      //	await Node_sleep(x_timer+1210);
      //	await Node_sleep(x_timer+1000);
      await Node_sleep(x_timer + 950);
    } else {
      //	await Node_sleep(x_timer+100);
      console.log(" d_x positive Move_X_process 3", x_timer);
      await Node_sleep(x_timer + 550);
    }
  }

  async function Move_Y_process(d_y, s_point_y) {
    let move_y = 0;
    let y_timer = 0;

    log(`== Move_Y_process start ==`);
    console.log(" d_y s_point_y:", d_y, s_point_y);

    console.log(" Move_Y_process 0");
    if (d_y < 0) {
      // Down -> Center
      console.log(" d_y negative Move_Y_process 1");
      //	move_y = Math.round(Math.abs(d_y * 0.885));
      move_y = Math.round(Math.abs(d_y * 0.75));
    } else {
      // Up -> Center
      console.log(" d_y positive Move_Y_process 2");
      //	move_y = Math.round(Math.abs(d_y * 0.790));
      move_y = Math.round(Math.abs(d_y * 0.885));
    }
    // 절대값을 반올림한 값으로 변환

    console.log(" move_y :", move_y);
    const y_quotient = Math.floor(move_y / 250); // 몫
    const y_remainder = move_y % 250; // 나머지
    console.log(`몫: ${y_quotient}, 나머지: ${y_remainder}`);

    if (d_y < 0) {
      if (y_quotient > 0) {
        for (let i = 0; i < y_quotient; i++) {
          serialport.write("MY-0250"); // Down 이동 명령
        }
        await Node_sleep(700);
      }

      if (y_remainder < 10 && y_remainder > 0) {
        serialport.write("MY-000" + y_remainder); // Down 이동 명령
        y_timer = 250;
      } else if (y_remainder < 100) {
        serialport.write("MY-00" + y_remainder); // Down 이동 명령
        y_timer = 450;
      } else {
        serialport.write("MY-0" + y_remainder); // Down 이동 명령
        y_timer = 650;
      }
    } else {
      if (y_quotient > 0) {
        for (i = 0; i < y_quotient; i++) {
          serialport.write("MY+0250"); // Up 이동 명령
        }
        await Node_sleep(700);
      }

      if (y_remainder < 10 && y_remainder > 0) {
        serialport.write("MY+000" + y_remainder); // Up 이동 명령
        y_timer = 300;
      } else if (y_remainder < 100) {
        serialport.write("MY+00" + y_remainder); // Up 이동 명령
        y_timer = 500;
      } else {
        serialport.write("MY+0" + y_remainder); // Up 이동 명령
        y_timer = 700;
      }
    }

    if (s_point_y === 0) {
      await Node_sleep(y_timer + 400);
      //	await AutoPupil_LF_Serial(1, 99);
      //	await Node_sleep(30);

      /*
				await AutoPupil_LF_Serial(1, 99);
				await Node_sleep(30);
				await setExposure_absolute(1,100);
				await setSaturationMode(1, 0);
				await setBrightnessMode(1,-1);
				*/

      //	await Node_sleep(y_timer+450);
      //	await Node_sleep(y_timer+400);
      //	await AutoPupil_LF_Serial(1, 99);
    } else {
      //	await Node_sleep(y_timer+650);
      await Node_sleep(y_timer + 640);
    }
  }

  async function autoS_Pupil() {
    log(`==  autoS_Pupil Start==`);

    if (Auto_Status !== 1) {
      return;
    }
    await Node_sleep(50);

    await ffmpeg_capture_proc1(7, auto_pupil_index);

    try {
      await cal_pupil_inform(5);

      PupilSearch = Pupil_result_array[auto_pupil_index].searchResult;
      console.log("First Pupil Search OK Result :", PupilSearch);

      if (PupilSearch === 0) {
        console.log("First Pupil Search OK Result:", PupilSearch);
        console.log("Pupil Data :", Pupil_result_array[auto_pupil_index]);
        now_pupil_x = Pupil_result_array[auto_pupil_index].pupilCenterX;
        now_pupil_y = Pupil_result_array[auto_pupil_index].pupilCenterY;
        now_pupil_Area = Pupil_result_array[auto_pupil_index].pupilArea;
        return;
      }
      /*
				else	{
					try {
						console.log("Retry Pupil Serach method 1 ");
						await cal_pupil_inform(1);
						PupilSearch =  Pupil_result_array[auto_pupil_index].searchResult;
						console.log("Pupil Serach OK Result :", PupilSearch);

						if(PupilSearch === 0)	{
							console.log("Retry Pupil Serach OK Result :", PupilSearch);
							console.log("Pupil Data :", Pupil_result_array[auto_pupil_index]);
							now_pupil_x = Pupil_result_array[auto_pupil_index].pupilCenterX;
							now_pupil_y = Pupil_result_array[auto_pupil_index].pupilCenterY;
							now_pupil_Area = Pupil_result_array[auto_pupil_index].pupilArea;
						}
					}
					catch (error) {
						console.log(`Find Fail Pupil: ${error}`);
						PupilSearch = 1;
						console.log("Retry Pupil Serach Fail Result :", PupilSearch); 
					}

				}
				*/
    } catch (error) {
      console.log(`Find Fail Pupil: ${error}`);
      PupilSearch = 1;
      console.log("Pupil Serach Fail Result :", PupilSearch);
    }
  }

  async function cal_pupil_inform(search_method) {
    log(`==  cal_pupil_inform Start==`);

    const pupil_idx = auto_pupil_index;
    console.log("= Pupil Index :", search_method, pupil_idx);
    let cppExepupilPath;

    /*
			if(search_method === 1)	{
				log(`cal_pupil_inform Start Used c++ umi_auto_pupil_nocrop_mix5`); 
			//	cppExepupilPath = '/home/nvidia/i-view100/./umi_auto_pupil_nocrop_mix1'; 
				cppExepupilPath = '/home/nvidia/i-view100/./umi_auto_pupil_nocrop_mix5'; 
			}
			else	{
				log(`cal_pupil_inform Start Used c++ umi_auto_pupil_nocrop_mix5`); 
			//	cppExepupilPath = '/home/nvidia/i-view100/./umi_auto_pupil_nocrop_mix4'; 
				cppExepupilPath = '/home/nvidia/i-view100/./umi_auto_pupil_nocrop_mix5'; 
			}
			*/

    cppExepupilPath = "/home/nvidia/i-view100/./umi_auto_pupil_nocrop_mix6";

    //	const cppExepupilPath = '/home/nvidia/i-view100/./umi_auto_pupil_nocrop_mix4';

    // 이미지 경로 설정 (전역 변수 auto_pupil_index 사용)
    const input_imgPath = `/home/nvidia/i-view100/AF/AutoPupil_IN_${pupil_idx}.jpg`;
    const output_imgPath = `/home/nvidia/i-view100/AF/AutoPupil_OUT_${pupil_idx}.jpg`;
    console.log(
      "= Running command:",
      cppExepupilPath,
      input_imgPath,
      output_imgPath
    );

    return new Promise((resolve, reject) => {
      let stdout = "";
      let stderr = "";

      // ? spawn 사용 (올바른 코드)
      const command = spawn(cppExepupilPath, [
        input_imgPath,
        output_imgPath,
        200,
      ]);

      // ? stdout 데이터 수집
      command.stdout.on("data", (data) => {
        stdout += data.toString();
        console.log(data.toString().trim()); // 로그 활성화
      });

      // ? stderr 데이터 수집
      command.stderr.on("data", (data) => {
        stderr += data.toString();
        console.log("[STDERR]", data.toString().trim()); // 로그 활성화
      });

      // ? 명령어 실행 완료 시
      command.on("close", (code) => {
        console.log(`Command closed with exit code: ${code}`);

        if (code !== 0) {
          PupilSearch = 1; // No Pupiil deteced
          console.error(`Command error: ${stderr}`);
          return reject(
            new Error(stderr || `Command failed with exit code ${code}`)
          );
        }

        parseOutput(stdout)
          .then((result) => {
            Pupil_result_array[pupil_idx] = result;
            //	console.log('= Parse Data:', Pupil_result_array[pupil_idx]);
            resolve();
          })
          .catch(reject);
      });
    });
  }

  async function parseOutput(pupil_data) {
    const parsedResult = {};
    const lines = pupil_data.split("\n");

    log(`parseOutput Start`);

    lines.forEach((line) => {
      let match;

      //	if ((match = line.match(/circleCenterCoordinates\s*:\s*(\d+),\s*(\d+),\s*radius\s*:\s*([\d.]+)/))) {
      if (
        (match = line.match(
          /pupilCenterCoordinates\s*:\s*(\d+),\s*(\d+),\s*radius\s*:\s*([\d.]+)/
        ))
      ) {
        parsedResult.pupilCenterX = parseInt(match[1]);
        parsedResult.pupilCenterY = parseInt(match[2]);
        //	parsedResult.pupilRadius = parseFloat(match[3]);
      }
      //	else if ((match = line.match(/circleArea\s*:\s*([\d.]+)/))) {
      else if ((match = line.match(/pupilArea\s*:\s*([\d.]+)/))) {
        parsedResult.pupilArea = parseFloat(match[1]);
      } else if ((match = line.match(/searchResult\s*:\s*([\d.]+)/))) {
        parsedResult.searchResult = parseInt(match[1]);
      }
    });
    //	console.log('= Return Result:', parsedResult);

    return parsedResult;
  }
}

let isRepeatLimit = false;
let currentO_ratio = 0;

async function Main_S1_AutoSearchRetina() {
  let white_ratio_array = [];
  let white_ratio_sub_array = []; // 3x3 블록별 화이트 비율을 저장

  let other_ratio_array = [];

  let auto_retina_index = 0;
  let FirstStep_ratio = 80;
  let SencondStep_ratio = 90;
  let ThirdStep_ratio = 94;
  let FourthStep_ratio = 97;
  //	let LastStep_ratio = 99.0 + 0.80;
  let LastStep_ratio = 99.0 + 0.99;

  let wait_timer = 10;
  let X_MoveCnt = 0;
  let Y_MoveCnt = 0;
  let z_go_flag = 0;
  let move_z = 0;
  let currentO_ratio = 0;
  let Z_Limit = 1650; // Human Test

  let Brihtness_Up = 0;

  console.log("== Main_S1_AutoSearchRetina Start ==", Add_sum, Auto_Status);

  isRepeatLimit = false;
  currentO_ratio = 0;
  //	Auto_Status = 1;	// White Ratio Search Step
  log(`== Main_S1_AutoSearchRetina start ==`);
  //	return;

  //	await Node_sleep(740);
  await Node_sleep(300);

  //	return;
  await repeatAutoRetina(0);

  async function autoRetina(c_kind) {
    log(`==  autoRetina Start==`);
    console.log("== autoRetina  Add_sum Auto_Status ==", Add_sum, Auto_Status);

    if (Auto_Status !== 1) {
      return;
    }
    await ffmpeg_capture_proc1(c_kind, auto_retina_index);

    try {
      await cal_whiteratio_proc(c_kind, auto_retina_index);
    } catch (error) {
      console.error(`Error in cal_whiteratio_proc: ${error}`);
    }
  }

  async function cal_whiteratio_proc(c_kind, re_idx) {
    console.log("= cal_whiteratio_proc  START =", c_kind, re_idx);
    const cppExeNoisePath = "/home/nvidia/i-view100/umi_whiteratio_3x3";

    let org_imgPath;

    if (c_kind === 1) {
      org_imgPath = `/home/nvidia/i-view100/AF/AutoS1_W_${re_idx}.png`;
    } else if (c_kind === 3) {
      org_imgPath = `/home/nvidia/i-view100/AF/AutoS1_Y_${re_idx}.png`;
    } else if (c_kind === 4) {
      org_imgPath = `/home/nvidia/i-view100/AF/AutoS1_X_${re_idx}.png`;
    }

    const command = `${cppExeNoisePath} ${org_imgPath}`;

    console.log("= Running command:", command);

    try {
      const stdout = await execPromise(command);
      white_ratio_sub_array = []; // 서브 배열 초기화

      let totalWhiteRatio = 0;

      for (let i = 0; i < 9; i++) {
        let w_ratio_index = stdout.indexOf(
          `White_${Math.floor(i / 3)}${i % 3}_pixel_ratio:`
        ); // "White_ij_pixel_ratio:"의 시작 인덱스
        if (w_ratio_index === -1) {
          throw new Error("Invalid white ratio values in output");
        }

        const whiteString = stdout
          .substring(w_ratio_index + 21, w_ratio_index + 26)
          .trim(); // "White_00_pixel_ratio: "의 길이는 21
        const whiteRatio = parseFloat(whiteString);

        if (isNaN(whiteRatio)) {
          throw new Error("Invalid white ratio value in output");
        }

        white_ratio_sub_array[i] = whiteRatio;
        totalWhiteRatio += whiteRatio; // 전체 블랙 비율 누적

        console.log(
          "= cal_whiteratio_proc  Each white ratio =",
          i,
          white_ratio_sub_array[i]
        );
      }

      totalWhiteRatio /= 9; // 전체 블랙 비율 평균 계산
      white_ratio_array[re_idx] = totalWhiteRatio; // 전체 블랙 비율 저장
      other_ratio_array[re_idx] = 100 - totalWhiteRatio; // 전체 블랙 비율 저장
      console.log(
        `white_ratio_array[${auto_retina_index}] : ${white_ratio_array[auto_retina_index]}`
      );
      console.log(
        `other_ratio_array[${auto_retina_index}] : ${other_ratio_array[auto_retina_index]}`
      );
    } catch (error) {
      console.error(`Error in cal_whiteratio_proc: ${error}`);
      throw error;
    }
  }

  async function findMaxData_moveXYMotor(now_currentO_ratio) {
    let x_deviation, y_deviation, re_deviation, move_dir, rounded1, rounded2;
    console.log("= findMaxData_moveXYMotor Start  =");

    // 최대 화이트 비율과 인덱스 찾기
    const maxWhiteRatio = Math.max(...white_ratio_sub_array);
    const maxIndex = white_ratio_sub_array.indexOf(maxWhiteRatio);
    console.log(`가장 큰 화이트 비율: ${maxWhiteRatio} (인덱스: ${maxIndex})`);

    y_deviation = white_ratio_sub_array[1] - white_ratio_sub_array[7];

    console.log("= findMaxData_moveXYMotor Start 1 =", y_deviation);
    if (y_deviation > 0) {
      move_dir = 0; // 가운데 상단이  크면 아래로 down key와 동일하게 움직임(MY-XXXX)
      //	move_dir = 1;	// 가운데 상단이  크면 아래로 down key와 동일하게 움직임(MY-XXXX)
    } else if (y_deviation < 0) {
      move_dir = 1; // 가운데 하단이  크면 위로 up key와 동일하게 움직임(MY+XXXX)
      //	move_dir = 0;	// 가운데 하단이  크면 위로 up key와 동일하게 움직임(MY+XXXX)
    } else {
      move_dir = -1;
    }
    console.log("= findMaxData_moveXYMotor Start 2 =", move_dir);

    re_deviation = Math.ceil(Math.abs(y_deviation));

    console.log("= findMaxData_moveXYMotor Start 2 =", move_dir, re_deviation);

    if (move_dir !== -1 && re_deviation > 1) {
      rounded1 = Math.round(re_deviation); // 5
      if (rounded1 >= 1) {
        console.log(
          "= findMaxData_moveXYMotor Start 2-1 =",
          re_deviation,
          rounded1
        );
        console.log("= Calculate_movingdata 호출 전 =");

        if (Add_sum < 800) {
          //	await Calculate_movingdata(move_dir,rounded1 * 0.9);	// Move Y 축
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.9));
        } else if (Add_sum >= 800 && Add_sum < 900) {
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.8));
        } else if (Add_sum >= 900 && Add_sum < 1000) {
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.7));
        } else if (Add_sum >= 1000 && Add_sum < 1050) {
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.65));
        } else if (Add_sum >= 1050 && Add_sum < 1100) {
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.6));
        } else if (Add_sum >= 1100 && Add_sum < 1150) {
          //	await Calculate_movingdata(move_dir,rounded1 * 0.45);	// Move Y 축
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.55));
        } else if (Add_sum >= 1150 && Add_sum < 1200) {
          //	await Calculate_movingdata(move_dir,rounded1 * 0.4);	// Move Y 축
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.5));
        } else if (Add_sum >= 1200 && Add_sum < 1250) {
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.45));
        } else if (Add_sum >= 1250 && Add_sum <= 1300) {
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.4));
        } else {
          //	await Calculate_movingdata(move_dir,rounded1 * 0.3);	// Move Y 축
          await Calculate_movingdata(move_dir, Math.ceil(rounded1 * 0.3));
        }
      }
      console.log("= Calculate_movingdata 호출 후 =");
    }

    x_deviation = white_ratio_sub_array[3] - white_ratio_sub_array[5];

    re_deviation = Math.abs(x_deviation); // 절대값으로 변환

    rounded1 = Math.round(re_deviation); // 5
    console.log(
      "= findMaxData_moveXYMotor Start 3 =",
      x_deviation,
      re_deviation
    );

    if (x_deviation > 0) {
      move_dir = 2; // 가운데 왼쪽이 우측으로 right  key와 동일하게 움직임(MX+XXXX)
    } else if (x_deviation < 0) {
      move_dir = 3; // 가운데 우측이  크면 위로 left key와 동일하게 움직임(MX-XXXX)
    } else {
      move_dir = -1;
    }
    console.log("= findMaxData_moveXYMotor Start 3-1 =");

    /*
			if(re_deviation < 1)	{
				console.log('= findMaxData_moveXYMotor x rediviation < 1 Start 3-1  =', re_deviation); 
				move_dir = -1;
			}
			*/
    console.log("= findMaxData_moveXYMotor Start 4 =", move_dir);

    if (move_dir >= 2) {
      Auto_Loop_cnt = Math.floor(Add_sum / 125);
      console.log(
        "= findMaxData_moveXYMotor Start 4-1 =",
        re_deviation,
        rounded1,
        Add_sum,
        Auto_Loop_cnt
      );

      if (rounded1 >= 1) {
        switch (Auto_Loop_cnt) {
          case 1: // Add_sum :  1  ~ 999
          case 2: // Add_sum :   ~ 999
          case 3: // Add_sum :   ~ 999
          case 4: // Add_sum :   ~ 999
          case 5: // Add_sum :   ~ 999
            rounded2 = rounded1 * 0.65; // Move X 축
            break;
          case 6: // Add_sum :   ~ 999
            rounded2 = rounded1 * 0.6; // Move X 축
            break;
          case 7: // Add_sum :   ~ 999
            //	rounded2 = rounded1 * 0.55;	// Move X 축
            rounded2 = rounded1 * 0.5; // Move X 축
            break;

          case 8: // Add_sum :  1000 ~ 1124
            //	rounded2 = rounded1 * 0.4;	// Move X 축
            rounded2 = rounded1 * 0.38; // Move X 축
            break;

          case 9: // Add_sum :  1125 ~ 1249
            //	rounded2 = rounded1 * 0.38;	// Move X 축
            rounded2 = rounded1 * 0.36; // Move X 축
            break;

          case 10: // Add_sum :  1250 ~ 1374
            rounded2 = rounded1 * 0.28; // Move X 축
            break;

          case 11: // Add_sum :  1375 ~
            rounded2 = rounded1 * 0.25; // Move X 축
            break;

          case 12: // Add_sum :  1375 ~
            rounded2 = rounded1 * 0.2; // Move X 축
            break;

          default:
            rounded2 = rounded1 * 0.15; // Move X 축
            break;
        }
        console.log("= Moving X Data =", rounded1, rounded2);
        //	await Calculate_movingdata(move_dir, rounded2);	// Move X 축
        await Calculate_movingdata(move_dir, Math.ceil(rounded2));
      }
    }

    console.log("= findMaxData_moveXYMotor End 1 =");
  }

  async function writeMotorDataSync(dir, loop_cnt) {
    log(`====writeMotorDataSync Start====`);
    console.log("dir, loop_cnt", dir, loop_cnt);

    if (loop_cnt === 0) {
      console.log("loop_cnt = 0, return");
      return;
      digit_cnt = 1; // 0의 자리수는 1
    } else {
      digit_cnt = Math.floor(Math.log10(Math.abs(loop_cnt))) + 1;
    }

    console.log("digit_cnt", digit_cnt);

    try {
      switch (dir) {
        case 0: // Up
          Y_MoveCnt = Y_MoveCnt - loop_cnt;

          switch (digit_cnt) {
            case 1:
              serialport.write("MY-000" + loop_cnt); // Y 축 Up 이동
              break;
            case 2:
              serialport.write("MY-00" + loop_cnt); // Y 축 Up 이동
              break;
            case 3:
              serialport.write("MY-0" + loop_cnt); // Y 축 Up 이동
              break;
          }
          break;

        case 1: // Down
          Y_MoveCnt = Y_MoveCnt + loop_cnt;

          switch (digit_cnt) {
            case 1:
              serialport.write("MY+000" + loop_cnt); // Y 축 Up 이동
              break;
            case 2:
              serialport.write("MY+00" + loop_cnt); // Y 축 Up 이동
              break;
            case 3:
              serialport.write("MY+0" + loop_cnt); // Y 축 Up 이동
              break;
          }
          break;

        case 2: // Left
          X_MoveCnt = X_MoveCnt - loop_cnt;

          switch (digit_cnt) {
            case 1:
              serialport.write("MX+000" + loop_cnt); // Y 축 Up 이동
              break;
            case 2:
              serialport.write("MX+00" + loop_cnt); // Y 축 Up 이동
              break;
            case 3:
              serialport.write("MX+0" + loop_cnt); // Y 축 Up 이동
              break;
          }
          break;

        case 3: // Left
          X_MoveCnt = X_MoveCnt + loop_cnt;

          switch (digit_cnt) {
            case 1:
              serialport.write("MX-000" + loop_cnt); // Y 축 Up 이동
              break;
            case 2:
              serialport.write("MX-00" + loop_cnt); // Y 축 Up 이동
              break;
            case 3:
              serialport.write("MX-0" + loop_cnt); // Y 축 Up 이동
              break;
          }
          break;
      }
    } catch (error) {
      console.error("Error in Z_MotorControl:", error);
    }
  }

  async function Calculate_movingdata(m_dir, xy_deviation) {
    try {
      // re_deviation을 정수로 변환 (반올림)

      const roundedDeviation = Math.round(xy_deviation);

      console.log("= Calculate_movingdata Start 2 =", roundedDeviation);

      await writeMotorDataSync(m_dir, roundedDeviation);

      if (roundedDeviation > 0 && roundedDeviation <= 5) {
        // 1 ~ 5
        wait_timer = 200;
      } else if (roundedDeviation > 5 && roundedDeviation <= 10) {
        // 6 ~ 10
        wait_timer = 250;
      } else if (roundedDeviation > 10 && roundedDeviation <= 15) {
        // 10 ~ 15
        wait_timer = 300;
      } else if (roundedDeviation > 15 && roundedDeviation <= 20) {
        // 16 ~ 20
        wait_timer = 350;
      } else if (roundedDeviation > 20 && roundedDeviation <= 25) {
        // 10 ~ 15
        wait_timer = 350;
      } else if (roundedDeviation > 25 && roundedDeviation <= 30) {
        // 16 ~ 20
        wait_timer = 400;
      } else {
        //	wait_timer = 670;
        wait_timer = 700;
      }

      //wait_timer = wait_timer+500;

      log(`====Node_Sleep before ====`);

      await Node_sleep(wait_timer);

      console.log("= Calculate_movingdata Start 3 =", m_dir);

      /*
			if((m_dir === 0) || (m_dir === 1))	{
				await autoRetina(3); // Y 축 Move
			}
			else if((m_dir === 2) || (m_dir === 3))	{
				await autoRetina(4); // X 축 Move
			}
			*/
    } catch (error) {
      console.error("Error in Calculate_movingdata:", error);
    }
  }

  async function repeatAutoRetina(s_val) {
    log(`======repeatAutoRetina Start======`);
    console.log(
      "= repeatAutoRetina before Auto_Status S1_received =",
      Auto_Status,
      S1_received,
      s_val
    );

    let white_flag;

    await Node_sleep(wait_timer);

    if (Auto_Status === 0 || Auto_Status === 5 || S1_received === 1) {
      console.log("= repeatAutoRetina Shoot Finish =", Auto_Status);
      return;
    }

    console.log("= repeatAutoRetina auto_retina_index =", auto_retina_index);

    wait_timer = 0;

    if (s_val === 0) {
      wait_timer = 700;
    } else if (s_val === 1) {
      //	wait_timer = 430;
      wait_timer = 500;
    } else {
    }
    wait_timer = 0;

    if (wait_timer !== 0) {
      await Node_sleep(wait_timer);
    }

    await autoRetina(1);

    currentO_ratio = other_ratio_array[auto_retina_index];

    white_flag = await Part_white_ratio();
    if (currentO_ratio >= LastStep_ratio - 9) {
      //	white_flag = await Part_white_ratio();

      if (white_flag === 1) {
        console.log(
          "= Stop Retina search complete (White ratio reversed=",
          currentO_ratio
        );
        Retina_S1_Step();
        return;
      }
    }

    if (auto_retina_index <= 0) {
      if (currentO_ratio >= 94) {
        console.log(
          "= First Time White ratio >= 95, =",
          Add_sum,
          currentO_ratio,
          auto_retina_index
        );
        if (currentO_ratio >= 94 && currentO_ratio < 95) {
          z_back = 80;
          serialport.write("MZ-00" + z_back);
          wait_timer = 350;
        }
        if (currentO_ratio >= 95 && currentO_ratio < 96) {
          z_back = 90;
          serialport.write("MZ-00" + z_back);
          wait_timer = 350;
        } else if (currentO_ratio >= 96 && currentO_ratio < 97) {
          z_back = 100;
          serialport.write("MZ-0" + z_back);
          //	wait_timer = 550;
          wait_timer = 350;
        } else if (currentO_ratio >= 97 && currentO_ratio < 98) {
          z_back = 120;
          serialport.write("MZ-0" + z_back);
          //	wait_timer = 600;
          wait_timer = 400;
        } else if (currentO_ratio >= 98 && currentO_ratio < 99) {
          z_back = 130;
          serialport.write("MZ-0" + z_back);
          //	wait_timer = 650;
          wait_timer = 500;
        } else if (currentO_ratio >= 99 && currentO_ratio < 100) {
          z_back = 140;
          serialport.write("MZ-0" + z_back);
          //	wait_timer = 700;
          wait_timer = 500;
        } else {
          // 100 이상
          z_back = 160;
          serialport.write("MZ-0" + z_back);
          //	wait_timer = 750;
          wait_timer = 650;
        }

        auto_retina_index++;
        Add_sum = Add_sum - z_back;
        console.log("= Retry Serach Retina =", Add_sum);
        await Node_sleep(wait_timer);
        wait_timer = 1;

        await repeatAutoRetina(1);
        return;
      }
    }

    if (auto_retina_index > 20) {
      console.log("= auto_retina_index over 20 =");
      Retina_S1_Step();
      return;
    }

    if (Add_sum >= Z_Limit) {
      z_go_flag = 1;
      console.log(
        "====== Add_sum >= Z_MlimitrepeatAutoRetina Go to S1 step 1==",
        Add_sum,
        z_go_flag
      );
      await Retina_S1_Step();
      return;
    }

    if (other_ratio_array[auto_retina_index] < 30) {
      console.log("= other_ratio < 30, White Noise  =");
      auto_retina_index++;
      await repeatAutoRetina(2);
      return;
    }

    const cal_ratio = currentO_ratio - other_ratio_array[auto_retina_index - 1];

    if (auto_retina_index >= 2) {
      //	if(currentO_ratio >= LastStep_ratio){
      if (currentO_ratio >= LastStep_ratio && white_flag === 1) {
        console.log("= currentO_ratio >= LastStep_ratio =");
        z_go_flag = 1;
        serialport.write("MZ+0010");
        Add_sum = Add_sum + 10;
        console.log("Add_sum", Add_sum);
        await Node_sleep(100);
        Retina_S1_Step();

        return;
      } else if (
        currentO_ratio < LastStep_ratio &&
        currentO_ratio >= LastStep_ratio - 0.2
      ) {
        console.log("값이 Other Color Limit ±0.2 이내입니다.");

        if (isRepeatLimit === false) {
          // 한번 더 반복 (Z 축 전진은 하지 않고)
          isRepeatLimit = true;
          serialport.write("MZ+0010");
          Add_sum = Add_sum + 10;
          auto_retina_index++;
          await Node_sleep(150);
          await repeatAutoRetina(1);
          return;
        } else {
          // Repeat Limit Other Ratio
          console.log("= Already Limit Other Ratio =");
          z_go_flag = 1;
          Retina_S1_Step();
          return;
        }
      } else {
        if (cal_ratio <= -3 && Brihtness_Up === 0) {
          console.log(
            "= reverse now currnt ratio < other_ratio white Noise ",
            cal_ratio
          );
          auto_retina_index++;
          await repeatAutoRetina(2);
          return;
        }
      }
    }

    currentO_ratio = other_ratio_array[auto_retina_index];
    let diff_white =
      white_ratio_array[auto_retina_index] -
      white_ratio_array[auto_retina_index - 1];
    let diff_other =
      other_ratio_array[auto_retina_index] -
      other_ratio_array[auto_retina_index - 1];

    if (auto_retina_index > 0) {
      currentO_ratio = other_ratio_array[auto_retina_index];

      console.log("= diff white, diff_other=", diff_white, diff_other);

      if (diff_white > 30) {
        console.log("= white_rator < other_ratio (over 20) before =");
        auto_retina_index++;
        await repeatAutoRetina(2);
        return;
      }
    }

    if (currentO_ratio >= 99.4) {
      if (diff_other < 0.1) {
        console.log("= diff data min  Go To S1 Step");
        await Retina_S1_Step();
        return;
      }
    }

    if (z_go_flag === 1) {
      console.log(
        "====== z_go_flag 1 repeatAutoRetina Go to S1 step 1==",
        currentO_ratio,
        Add_sum,
        z_go_flag
      );
      await Retina_S1_Step();
      return;
    } else if (currentO_ratio >= 100) {
      await Retina_S1_Step();
      return;
    } else if (currentO_ratio < LastStep_ratio) {
      // 99.0 ~99.9

      console.log("= Call findMaxData_moveXYMotor before =", currentO_ratio);
      await findMaxData_moveXYMotor(currentO_ratio);
      currentO_ratio = other_ratio_array[auto_retina_index];
      console.log("= Call findMaxData_moveXYMotor after=", currentO_ratio);

      if (currentO_ratio < LastStep_ratio) {
        if (Add_sum <= Z_Limit) {
          await Z_MotorControl(0);

          if (Brihtness_Up === 0) {
            if (now_pupil_Area >= 40_000) {
              if (currentO_ratio > 50) {
                Brihtness_Up = 1;
                await setBrightnessMode(1, 8);
              }
            } else {
              if (currentO_ratio > 80) {
                Brihtness_Up = 1;
                await setBrightnessMode(1, 8);
              }
            }
          }

          console.log("====== wait_timer ======", wait_timer, Add_sum);
          // wait_timer 시간만큼 지연시킵니다.

          await Node_sleep(wait_timer + 100);

          if (z_go_flag === 1) {
            if (currentO_ratio <= LastStep_ratio) {
              console.log(
                "====== Again repeatAutoRetina Again z_go_flag =====",
                z_go_flag
              );
              //	auto_retina_index++;
              await repeatAutoRetina(1);
              //	await Retina_S1_Step();
            } else {
              console.log(
                "====== repeatAutoRetina finish  z_go_flag =====",
                z_go_flag
              );
              await Retina_S1_Step();
              return;
            }
          } else {
            console.log(
              "====== repeatAutoRetina finish 1 z_go_flag =====",
              z_go_flag
            );
            //	auto_retina_index++;
            await repeatAutoRetina(1);
          }
        } else {
          console.log(
            "====== repeatAutoRetina finish 1-1 z_go_flag, Add_sum =====",
            z_go_flag,
            Add_sum
          );
          z_go_flag = 1;
          await Retina_S1_Step();
          return;
        }
      } else {
        console.log(
          "====== repeatAutoRetina finish 1-2 z_go_flag, Add_sum =====",
          z_go_flag,
          Add_sum
        );
        if (z_go_flag === 0) {
          auto_retina_index++;
          await repeatAutoRetina(2);
        } else {
          console.log(
            "====== repeatAutoRetina Go to S1 step 2==",
            currentO_ratio,
            Add_sum,
            z_go_flag
          );
          await Retina_S1_Step();
          return;
        }
      }
    } else {
      wait_timer = 10;
      if (currentO_ratio > LastStep_ratio) {
        // 99.0 ~ 99.1
        console.log(
          "= repeatAutoRetina currentO_ratio > LastStep_ratio + 0.5 || currentO_ratio > LastStep_ratio + 0.7 =="
        );
      }

      await Node_sleep(wait_timer);

      await Retina_S1_Step();
      return;
    }
  }

  async function Retina_S1_Step() {
    log(
      `Retina_S1_Step data : ${auto_retina_index}, ${Auto_Status}, ${Add_sum}`
    );
    console.log(
      "==== Retina_S1_Step ==== Index, Auto_Status, Add_sum, S1_received, currentO_ratio =",
      auto_retina_index,
      Auto_Status,
      Add_sum,
      S1_received,
      currentO_ratio
    );
    //	return;

    if (Auto_Status !== 1) {
      return;
    }

    // S1 Function
    AybcutoNextStep = 3; // Next Process Auto  Focusing
    await setSaturationMode(1, 45);
    await setBrightnessMode(1, 1);
    //	await setExposure_absolute(1,800);
    await setExposure_absolute(1, 1000);

    //	await AutoPupil_LI_Serial(1,99);
    //		await Node_sleep(50);

    if (currentO_ratio < 100) {
      serialport.write("MZ" + Add_C_Z);
      console.log("currentO_ratio < 100");
      Add_sum = Add_sum + Add_Z;
    } else {
      console.log("currentO_ratio >= 100");
      const numericC_Z = parseInt(Add_C_Z); // 문자열 → 숫자
      const reducedC_Z = numericC_Z - 10;
      console.log("numericC_Z reducedC_Z", numericC_Z, reducedC_Z);
      serialport.write("MZ+00" + String(reducedC_Z)); // 숫자 → 문자열
      //	serialport.write('MZ+0030');
      Add_sum = Add_sum + reducedC_Z;
    }

    console.log("After Add_sum", Add_sum);
    isRepeatLimit = false;
    await Node_sleep(10);
    await AutoPupil_LI_Serial(1, 99);

    setTimeout(async () => {
      log(`send data to FW : S1`);
      serialport.write("S1");

      log(`channel data : ${"S1"}`);
      channel.send("S1");
      await Node_sleep(40);

      console.log("After Add_sum", Add_sum);

      await Node_sleep(400);

      // Main AuroFocu3
      log(`Finish for search retina & Go To S1 On`);

      await Main_Ratio_AutoSearchIR();
    }, 50);
  }

  /*

		async function Part_white_ratio() { 

			let white_flag = 0;

			if((white_ratio_sub_array[1] === 0) && (white_ratio_sub_array[3] === 0) && (white_ratio_sub_array[5] === 0) && (white_ratio_sub_array[7] === 0))	{
				console.log('= Stop Retina search complete (1,3,5,7 Part White ratio Zero=');
				white_flag = 1;
			}
			return white_flag;
		}
		*/

  async function Part_white_ratio() {
    log(`======Part_white_ratio Start======`);
    // 방어 코드: 배열 유효성 검사
    if (
      !Array.isArray(white_ratio_sub_array) ||
      white_ratio_sub_array.length < 8
    ) {
      console.error("white_ratio_sub_array is invalid");
      return 0;
    }

    // 1,3,5,7 인덱스 값이 모두 0인지 검사
    if ([1, 3, 5, 7].every((i) => white_ratio_sub_array[i] === 0)) {
      console.log(
        "= Stop Retina search complete (1,3,5,7 Part White ratio Zero="
      );
      return 1;
    }
    return 0;
  }

  async function Z_MotorControl(z_dir) {
    let remain_zdata = 0;
    let absolute_z_value = 0;
    let realm_m_data;

    log(`======Z_MotorControl Start======`);

    remain_zdata = Z_Limit - Add_sum;
    console.log(
      "== Z_MotorControl Z_Limit, Add_sum remain_data z_go_flag==",
      Z_Limit,
      Add_sum,
      remain_zdata,
      z_go_flag
    );

    if (Add_sum <= Z_Limit && z_go_flag === 0) {
      console.log("== Z_MotorControl Positive ==");

      absolute_z_value = Math.abs(remain_zdata); // 절대값으로 변환

      if (absolute_z_value === 0) {
        z_go_flag = 1;
        return;
      }

      // 동공 크기 별로 depth? , 일정 step 전진하면 전진 step 조정
      auto_retina_index++;
      if (absolute_z_value === 0) {
        move_z = 1; // 0의 자리수는 1
      } else {
        move_z = Math.floor(Math.log10(Math.abs(absolute_z_value))) + 1;
      }

      console.log(
        "== Z_MotorControl absolute_z_value, move_z ==",
        absolute_z_value,
        move_z
      );

      real_m_data = absolute_z_value;

      if (currentO_ratio >= 100) {
        console.log("== Z_MotorControl currentO_ratio >= 100", move_z);
        real_m_data = real_m_data / 2;

        switch (move_z) {
          case 1:
            serialport.write("MZ-000" + real_m_data);
            wait_timer = 216;
            break;

          case 2:
            serialport.write("MZ-00" + real_m_data);
            wait_timer = 448;
            break;

          case 3:
            if (real_m_data <= 255) {
              serialport.write("MZ-0" + real_m_data);
            } else {
              real_m_data = 255;
              serialport.write("MZ-0" + real_m_data);
            }
            wait_timer = 680;
            break;

          case 4:
            real_m_data = 255;
            serialport.write("MZ-0" + real_m_data);
            wait_timer = 680;
            break;
        }
      } else if (currentO_ratio >= 99 && currentO_ratio < 100) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 98 && currentO_ratio < 100 ===",
          currentO_ratio
        );
        real_m_data = 10;
        serialport.write("MZ+00" + real_m_data);
        wait_timer = 250;
      } else if (currentO_ratio >= 98 && currentO_ratio < 99) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 98 && currentO_ratio < 99 ===",
          currentO_ratio
        );
        //	real_m_data = 25;
        real_m_data = 20;
        //		serialport.write('MZ+00'+real_m_data);
        wait_timer = 300;
      } else if (currentO_ratio >= 96 && currentO_ratio < 98) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 96 && currentO_ratio < 98 ===",
          currentO_ratio
        );
        real_m_data = 30;
        //	serialport.write('MZ+00'+real_m_data);
        wait_timer = 350;
      } else if (currentO_ratio >= 94 && currentO_ratio < 96) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 94 && currentO_ratio < 96 ===",
          currentO_ratio
        );
        real_m_data = 45;
        //	serialport.write('MZ+00'+real_m_data);
        wait_timer = 400;
      } else if (currentO_ratio >= 92 && currentO_ratio < 94) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 92 && currentO_ratio < 94 ===",
          currentO_ratio
        );
        real_m_data = 50;
        //	serialport.write('MZ+00'+real_m_data);
        wait_timer = 400;
      } else if (currentO_ratio >= 90 && currentO_ratio < 92) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 90 && currentO_ratio < 92 ===",
          currentO_ratio
        );
        real_m_data = 65;
        //	serialport.write('MZ+00'+real_m_data);
        wait_timer = 400;
      } else if (currentO_ratio >= 88 && currentO_ratio < 90) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 88 && currentO_ratio < 92 ===",
          currentO_ratio
        );
        real_m_data = 80;
        //	serialport.write('MZ+00'+real_m_data);
        wait_timer = 450;
      } else if (currentO_ratio >= 86 && currentO_ratio < 88) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 86 && currentO_ratio < 88 ===",
          currentO_ratio
        );
        real_m_data = 90;
        //	serialport.write('MZ+00'+real_m_data);
        wait_timer = 450;
      } else if (currentO_ratio >= 84 && currentO_ratio < 86) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 84 && currentO_ratio < 86 ===",
          currentO_ratio
        );
        real_m_data = 110;
        //	serialport.write('MZ+0'+real_m_data);
        wait_timer = 500;
      } else if (currentO_ratio >= 80 && currentO_ratio < 84) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 80 && currentO_ratio < 84 ===",
          currentO_ratio
        );
        real_m_data = 120;
        //	serialport.write('MZ+0'+real_m_data);
        wait_timer = 500;
      } else if (currentO_ratio >= 70 && currentO_ratio < 80) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 70 && currentO_ratio < 80 ===",
          currentO_ratio
        );
        real_m_data = 130;
        //	serialport.write('MZ+0'+real_m_data);
        wait_timer = 500;
      } else if (currentO_ratio >= 66 && currentO_ratio < 70) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 66 && currentO_ratio < 70 ===",
          currentO_ratio
        );
        real_m_data = 140;
        //	serialport.write('MZ+0'+real_m_data);
        wait_timer = 500;
      } else if (currentO_ratio >= 60 && currentO_ratio < 66) {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio >= 60 && currentO_ratio < 66 ===",
          currentO_ratio
        );
        real_m_data = 145;
        //	serialport.write('MZ+0'+real_m_data);
        wait_timer = 550;
      } else {
        console.log(
          "== Z_MotorControl currentO_ratio currentO_ratio > 60 ==",
          currentO_ratio
        );
        real_m_data = 150;
        //	serialport.write('MZ+0'+real_m_data);
        wait_timer = 550;
      }

      if (Brihtness_Up === 1) {
        //	real_m_data = Math.ceil(real_m_data * 2 / 3);

        if (real_m_data > 30) {
          let percent = 80; // 퍼센트 값
          real_m_data = Math.ceil(real_m_data * (percent / 100));

          console.log(
            "= Now Brightnee UP Status and New real_z_data=",
            Brihtness_Up,
            real_m_data
          );
        }
      }

      let str = String(real_m_data).padStart(4, "0"); // 4자리로 0 채우기
      serialport.write("MZ+" + str);

      Add_sum = Add_sum + real_m_data;
      console.log("== Z_MotorControl Add_sum ==", absolute_z_value, Add_sum);

      await Node_sleep(wait_timer);

      if (Add_sum >= Z_Limit) {
        z_go_flag = 1;
      } else {
        console.log(
          "== Z_MotorControl Negative remain data==",
          remain_zdata,
          z_go_flag
        );
      }
    }
  }
}

// sleep 함수를 생성합니다.
async function Node_sleep(ms) {
  log(`Node_sleep`);
  console.log("ms  =", ms);
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function ffmpeg_capture_proc1(auto_kind, auto_index) {
  let auto_imgpath;
  let command;

  log(`== ffmpeg_capture_proc1  START ==`);
  console.log("= kind, index =", auto_kind, auto_index);

  const username = "nvidia"; // 실행하고자 하는 일반 사용자의 이름

  // 저장할 이미지의 경로와 파일명
  switch (auto_kind) {
    case 0:
      if (eye_position === "OD") {
        // 오른쪽눈
        //	auto_imgpath = `/home/nvidia/i-view100/AF/s1_od_${auto_index}.jpg`;
        auto_imgpath = `/home/nvidia/i-view100/AF/AutoS1_ODF${auto_index}.jpg`;
        x_position = 270; // 오른쪽 눈의 경우 X 좌표 }
      } else {
        //	auto_imgpath = `/home/nvidia/i-view100/AF/s1_os_${auto_index}.jpg`;
        auto_imgpath = `/home/nvidia/i-view100/AF/AutoS1_OSF${auto_index}.jpg`;
        x_position = 140; // 왼쪽 눈의 경우 X 좌표
      }
      break;

    case 1:
      auto_imgpath = `/home/nvidia/i-view100/AF/AutoS1_W_${auto_index}.png`;
      break;
    case 2:
      auto_imgpath = `/home/nvidia/i-view100/AF/AutoS1_U_${auto_index}.png`;
      break;
    case 3:
      auto_imgpath = `/home/nvidia/i-view100/AF/AutoS1_Y_${auto_index}.png`;
      break;
    case 4:
      auto_imgpath = `/home/nvidia/i-view100/AF/AutoS1_X_${auto_index}.png`;
      break;
    case 5:
      auto_imgpath = `/home/nvidia/i-view100/AF/AutoS1_B_X_${auto_index}.png`;
      break;
    case 6:
      auto_imgpath = `/home/nvidia/i-view100/AF/AutoS1_B_Y_${auto_index}.png`;
      break;
    case 7:
      auto_imgpath = `/home/nvidia/i-view100/AF/AutoPupil_IN_${auto_index}.jpg`;
      break;
  }

  if (auto_kind === 0) {
    //	command = `sudo -u ${username} ffmpeg -y -f x11grab -video_size 650x450 -framerate 30 -i :0.0+${eye_position === "OD" ? 270 : 140},50 -frames:v 1 ${auto_imgpath}`;
    command = `sudo -u ${username} ffmpeg -y -f x11grab -video_size 1024x600 -framerate 30 -i :0.0 -vf "crop=800:600:112:0" -vsync vfr -frames:v 1 ${auto_imgpath}`;
  } else if (auto_kind === 7) {
    command = `sudo -u ${username} ffmpeg -y -f x11grab -video_size 1024x600 -framerate 30 -i :0.0 -vf "crop=800:600:112:0" -vsync vfr -frames:v 1 ${auto_imgpath}`;
  } else {
    command = `sudo -u ${username} ffmpeg -y -f x11grab -video_size 1024x600 -framerate 30 -i :0.0 -vf "crop=800:600:112:0" -frames:v 1 ${auto_imgpath}`;
  }

  try {
    const { stdout, stderr } = await execPromise(command);
    // `stdout`과 `stderr` 출력
    if (stdout) {
      console.log(`FFmpeg stdout: ${stdout}`);
    }
    if (stderr) {
      console.error(`FFmpeg stderr: ${stderr}`);
    }

    console.log(`Image saved to: ${auto_imgpath}`);
  } catch (error) {
    console.error(`Error executing ffmpeg command: ${error}`);
  } finally {
    console.log("= ffmpeg_capture_proc1  END =");
  }
}

async function Main_Ratio_AutoSearchIR() {
  let uniformity_ratio_array = [];
  //	let brightness_single_ratio_array = [ ];
  let total_brightness_X_array = [];
  let total_brightness_Y_array = [];

  let brightness_sub_X_ratio_array = [];
  let brightness_sub_Y_ratio_array = [];

  let auto_IR_index = 0;
  let auto_bright_x_index = 0;
  let auto_bright_y_index = 0;

  let before_currentU_ratio = 0;
  let wtimer_IR = 0;

  let currentU_ratio = 0;
  let currentB_ratio = 0;

  let repeat_uniform = 0;

  let repeat_step = 0;

  let repeat_up = 0;
  let repeat_down = 0;

  let IR_dir = 0xff;
  let IR_FailCnt = 0;

  console.log("= Main_Ratio_AutoSearchIR Auto_Status =", Auto_Status);
  log(`== Main_Ratio_AutoSearchIR start ==`);
  Auto_Status = 2; // IR Search Step

  serialport.write("YSZM51");

  await Node_sleep(250);

  if (Auto_Status !== 2) {
    return;
  }

  await repeatAutoRetinaIR();

  async function repeatAutoRetinaIR() {
    //		return;
    log(`== repeatAutoRetinaIR start ==`);

    console.log(
      "= repeatAutoRetinaIR Auto_Status, Add_sum =",
      Auto_Status,
      Add_sum
    );

    if (Auto_Status !== 2) {
      console.log("= repeatAutoRetinaIR Process Stop =", Auto_Status);
      return;
    }

    if (auto_IR_index === 0) {
      console.log(
        "= repeatAutoRetinaIR First Step waiting for IR Mode =",
        Auto_Status
      );
      wtimer_IR = 800; // 216 msec IR and White Mix
    } else {
      //	wtimer_IR = 400; // 216 msec
    }

    await Node_sleep(wtimer_IR);

    log(`==================repeatAutoRetinaIR Start==================`);
    console.log("= Start repeatAutoRetinaIR Cnt =", auto_IR_index, Add_sum);

    log(`==================repeatAutoRetinaIR Step 0==================`);
    await autoRetinaIR();
    currentU_ratio = uniformity_ratio_array[auto_IR_index];

    //	await cal_brightness_single_ratio_proc(auto_IR_index);
    //	currentB_ratio = brightness_single_ratio_array[auto_IR_index];

    log(`==================repeatAutoRetinaIR Step 1==================`);

    if (IR_FailCnt > 10) {
      console.log("= Fail due to abnormal uniformity data =", IR_FailCnt);
      await GoToAutoFocusProcess();
      return;
    }

    console.log(
      "= auto_IR_index  currentU_ratio currentB_ratio =",
      auto_IR_index,
      currentU_ratio,
      currentB_ratio
    );
    if (currentU_ratio > 10) {
      IR_FailCnt++;
      console.log(
        "= Retry white noise happen=",
        auto_IR_index,
        currentU_ratio,
        IR_FailCnt
      );
      //	return;
      await repeatAutoRetinaIR();
      return;
    }

    log(`==================repeatAutoRetinaIR Step 2==================`);
    if (auto_IR_index === 0) {
      console.log("= repeatAutoRetinaIR index = 0");

      IR_dir = 1; // Firsrt, focus direction is forward
      await moveZ_direction(1);

      auto_IR_index++;
      wtimer_IR = 400; // 216 msec
      await repeatAutoRetinaIR();
    } else if (auto_IR_index === 1) {
      console.log("= repeatAutoRetinaIR index = 1");

      IR_dir = -1; // focus direction is backward
      await moveZ_direction(2); // Z Position is 1 -> 0 -> -1

      auto_IR_index++;
      wtimer_IR = 400; // 216 msec
      await repeatAutoRetinaIR();
    }
    //	else if(auto_IR_index === 2)	{
    else if (auto_IR_index >= 2) {
      console.log("= repeatAutoRetinaIR index = 2");

      // 최대 Uniformity 비율과 인덱스 찾기
      let maxUniformity = Math.max(...uniformity_ratio_array);
      let maxUIndex = uniformity_ratio_array.indexOf(maxUniformity);
      console.log("uniformity_ratio_array의 전체 값:", uniformity_ratio_array);
      console.log(
        `가장 큰 Uniformity 비율: ${maxUniformity} (인덱스: ${maxUIndex})`
      );

      switch (maxUIndex) {
        case 0:
          IR_dir = 1; // Z Motor position 0
          await moveZ_direction(1); // Z Motor posion 0 is Max.
          IR_dir = 0; // focus direction is backward
          console.log("= Now position is Uniformity Max");
          break;

        case 1:
          IR_dir = 1; // focus direction is forward
          //	await 	moveZ_direction(3);	// Z Motor Navi. forward
          await moveZ_direction(2); // Z Motor Navi. forward
          break;
        case 2:
          IR_dir = -1; // focus direction is backward
          //	await 	moveZ_direction(1);	// Z Motor Navi. backward
          break;
        default:
          // No Move, Now best position
          break;
      }
      await GoToAutoFocusProcess();
      return;
    }
    /*
			else if(auto_IR_index >= 3 && auto_IR_index < 8)       {

				log(`==================repeatAutoRetinaIR Step 5==================`)

				let diff_data = 0;

				if(IR_dir === 1 && auto_IR_index === 3)	{
					console.log('= repeatAutoRetinaIR index = 4-1');
					diff_data = uniformity_ratio_array[auto_IR_index] - uniformity_ratio_array[auto_IR_index-2]
				}
				else	{
					console.log('= repeatAutoRetinaIR index = 4-1');
					diff_data = uniformity_ratio_array[auto_IR_index] - uniformity_ratio_array[auto_IR_index-1]
				}

				let re_diff = Math.abs(diff_data); // 절대값으로 변환

				console.log('= repeatAutoRetinaIR index = 3', diff_data, re_diff);

				let m_cnt = 1;

				if(diff_data < 0)	{
					console.log('= diff_data Negative');
					
					IR_dir = IR_dir * -1;
					await 	moveZ_direction(m_cnt);	// Z Motor posion 0 is Max.
					IR_dir = 0;	// Z Motor move stop

					console.log('=== Previous position moved to maximumd and AutoFocusProcess');

					await	GoToAutoFocusProcess();

				}
				else	{ 
					//	await moveXY_with_brightness(0);
					//	await moveXY_with_brightness(1);

					//	await 	moveZ_direction(m_cnt);
						auto_IR_index++; 

						wtimer_IR = 400; // 216 msec 
						await repeatAutoRetinaIR();
				}
			}
			else	{
				console.log('= auto_IR_index > 8  Go To AutoFocusProcess'); 
				await	GoToAutoFocusProcess();
			}
			*/
  }

  async function GoToAutoFocusProcess() {
    console.log("= GoToAutoFocusProcess=");
    //	return;
    await Node_sleep(200);
    //	auto_IR_index++;
    //	await autoRetinaIR();
    //	await Node_sleep(10);
    Auto_Status = 3; // Auto Focusing Step
    Main_AutoFocusProcess();
  }

  async function moveZ_direction(z_cnt) {
    console.log("= moveZ_direction proces start=", z_cnt);

    let real_move = 20 * z_cnt;

    if (IR_dir === 1) {
      // focus direction is forward
      serialport.write("MZ+00" + real_move);
      Add_sum = Add_sum + real_move;
    } else if (IR_dir === -1) {
      serialport.write("MZ-00" + real_move);
      Add_sum = Add_sum - real_move;
    } else {
      console.log("= IR_dir =", IR_dir);
    }

    switch (z_cnt) {
      case 0:
        wtimer_IR = 0; // 0 msec
        break;

      case 1: // Z step 20
        wtimer_IR = 216; // 216 msec
        break;

      case 2: // Z step 40
        wtimer_IR = 336; // 336 msec
        break;

      case 3: // Z step 60
        wtimer_IR = 460; // 336 msec
        break;
    }

    await Node_sleep(wtimer_IR);

    console.log("= Add_sum =", Add_sum);
  }

  async function moveXY_with_brightness(xy_move) {
    console.log("= moveXY_with_brightness xy_move =", xy_move);

    wtimer_IR = 0;

    if (xy_move === 0) {
      await autoRetinaBright(auto_bright_x_index, 0);

      let x_dev =
        brightness_sub_X_ratio_array[0] - brightness_sub_X_ratio_array[2];
      console.log(
        "=X_ x_dev b_sub00, b_sub01, b_sub02 =",
        x_dev,
        brightness_sub_X_ratio_array[0],
        brightness_sub_X_ratio_array[2]
      );

      let absolute_x_val = Math.abs(x_dev); // 절대값으로 변환
      let rounded_x_val = Math.round(absolute_x_val); //
      console.log(
        "=X_ absolute_x_val, rounded_x_val =",
        absolute_x_val,
        rounded_x_val
      );

      if (rounded_x_val > 10) {
        auto_bright_x_index++;

        if (x_dev > 5) {
          // 값이 0 크면 왼쪽이 더 밝음므로 왼쪽으로 이동
          serialport.write("MX-0005");
          wtimer_IR = 110; // 216 msec
        } else if (x_dev < 0) {
          // 0 보다 작으면 오른쪽이 더 밝음으로  오른쪽으로 이동
          serialport.write("MX+0005");
          wtimer_IR = 110; // 216 msec
        } else {
          wtimer_IR = 0;
        }
      }
    } else if (xy_move === 1) {
      await autoRetinaBright(auto_bright_y_index, 1);

      let y_dev =
        brightness_sub_Y_ratio_array[0] - brightness_sub_Y_ratio_array[2];
      console.log(
        "=Y y_dev b_sub00, b_sub01, b_sub02 =",
        y_dev,
        brightness_sub_Y_ratio_array[0],
        brightness_sub_Y_ratio_array[2]
      );

      let absolute_y_val = Math.abs(y_dev); // 절대값으로 변환
      let rounded_y_val = Math.round(absolute_y_val); //
      console.log(
        "=Y_ absolute_y_val, rounded_y_val =",
        absolute_y_val,
        rounded_y_val
      );

      wtimer_IR = 0;

      if (rounded_y_val > 5) {
        auto_bright_y_index++;

        if (y_dev > 0) {
          // 값이 0보다 크면 상측이 더 밝음으로 위로 이동 (
          serialport.write("MY-0005");
          wtimer_IR = 110; // 216 msec
        } else if (y_dev < 0) {
          // 0 보자 작으면 하측이 더 어두으므로위로 이동
          serialport.write("MY+0005");
          wtimer_IR = 110; // 216 msec
        }
      }
    }

    await Node_sleep(wtimer_IR);
  }

  async function autoRetinaIR() {
    console.log("==  autoRetinaIR Start==", auto_IR_index, Auto_Status); // 로그 추가
    if (Auto_Status !== 2) {
      console.log("==  autoRetinaIR Fail Auto_Status=="); // 로그 추가
      return;
    }

    await ffmpeg_capture_proc1(2, auto_IR_index);

    try {
      console.log("==  cal_uniformity_ratio_proc Before==", auto_IR_index); // 로그 추가
      await cal_uniformity_ratio_proc(auto_IR_index);
      console.log("==  cal_uniformity_ratio_proc After==", auto_IR_index); // 로그 추가
      console.log(
        `cal uniformity_ratio_array[${auto_IR_index}] : ${uniformity_ratio_array[auto_IR_index]}`
      );
    } catch (error) {
      console.error(`Error in cal_uniformity_ratio_proc: ${error}`);
    }
  }

  async function autoRetinaBright(auto_bright_x_index, bright_division) {
    if (bright_division === 0) {
      console.log("==  autoRetinaBright Start==", auto_bright_x_index); // 로그 추가
      await ffmpeg_capture_proc1(5, auto_bright_x_index);
      try {
        await cal_brightness_ratio_proc(auto_bright_x_index, 0); // X축
        console.log(
          `cal brightness_sub_X_ratio_array: ${brightness_sub_X_ratio_array}`
        );
      } catch (error) {
        console.error(`Error in cal_brightness_x_ratio_proc: ${error}`);
      }
    } else {
      console.log("==  autoRetinaBright Start==", auto_bright_y_index); // 로그 추가
      await ffmpeg_capture_proc1(6, auto_bright_y_index);

      try {
        await cal_brightness_ratio_proc(auto_bright_y_index, 1); //  Y 축
        console.log(
          `cal brightness_sub_X_ratio_array: ${brightness_sub_X_ratio_array}`
        );
      } catch (error) {
        console.error(`Error in cal_brightness_y_ratio_proc: ${error}`);
      }
    }
  }

  async function cal_uniformity_ratio_proc(u_idx) {
    console.log("= cal_uniformity_ratio_proc START =", u_idx);

    const cppExec_uniformityPath = "/home/nvidia/i-view100/umi_uniformity";
    const org_UniFormImgPath = `/home/nvidia/i-view100/AF/AutoS1_U_${u_idx}.png`;
    const command = `${cppExec_uniformityPath} ${org_UniFormImgPath}`;

    console.log("= Running command:", command);

    try {
      const stdout = await execPromise(command);
      console.log("Command output:", stdout); // 명령어 출력 로그 추가

      // "Uniformity Index:" 문자열이 포함된 부분의 인덱스 찾기
      let u_ratio_index = stdout.indexOf("Uniformity Index:");

      if (u_ratio_index === -1) {
        throw new Error(
          `"Uniformity Index:" not found in output for u_idx: ${u_idx}`
        );
      }

      // 유니포미티 비율 추출
      const uniformityString = stdout.substring(u_ratio_index + 18).trim(); // "Uniformity Index: "의 길이는 16
      const uniformityRatio = parseFloat(uniformityString);

      if (isNaN(uniformityRatio)) {
        throw new Error(
          `"Uniformity Index:" not found in output for u_idx: ${u_idx}`
        );
      }

      // 유니포미티 비율 저장
      uniformity_ratio_array[u_idx] = uniformityRatio;

      console.log(
        `uniformity_ratio_array[${u_idx}] : ${uniformity_ratio_array[u_idx]}`
      );
    } catch (error) {
      console.error(`Error in cal_uniformity_ratio_proc: ${error}`);
      throw error;
    }
  }

  async function cal_brightness_ratio_proc(re_idx, bright_divide) {
    console.log("= cal_brightness_ratio_proc  START =", re_idx, bright_divide);

    let cppExeBrightPath;
    let org_imgPath;

    let Total_bright_common_ratio_array = [];
    let bright_sub_common_ratio_array = [];

    brightness_sub_X_ratio_array = []; // 여기서 초기화합니다.
    brightness_sub_Y_ratio_array = []; // 여기서 초기화합니다.
    if (bright_divide === 0) {
      cppExeBrightPath =
        "/home/nvidia/i-view100/umi_autoS1_brigtness_org_3x1_img"; // 가로 3등분
      org_imgPath = `/home/nvidia/i-view100/AF/AutoS1_B_X_${re_idx}.png`;
      Total_bright_common_ratio_array = [...total_brightness_X_array];
      //	bright_sub_common_ratio_array = [... brightness_sub_X_ratio_array];
    } else if (bright_divide === 1) {
      cppExeBrightPath =
        "/home/nvidia/i-view100/umi_autoS1_brigtness_org_1x3_img"; // 세로 3등분
      org_imgPath = `/home/nvidia/i-view100/AF/AutoS1_B_Y_${re_idx}.png`;
      Total_bright_common_ratio_array = [...total_brightness_Y_array];
      bright_sub_common_ratio_array = [...brightness_sub_Y_ratio_array];
    }

    brightness_sub_X_ratio_array = []; // 여기서 초기화합니다.
    brightness_sub_Y_ratio_array = []; // 여기서 초기화합니다.
    bright_sub_common_ratio_array = [...brightness_sub_Y_ratio_array];

    const command = `${cppExeBrightPath} ${org_imgPath}`;

    try {
      console.log("Running command:", command);
      const stdout = await execPromise(command);

      if (!stdout) {
        throw new Error("Command did not return any output.");
      }

      console.log("Command output:", stdout); // stdout 내용을 로깅하여 확인
      const lines = stdout.split("\n");

      let totalBrightness = 0;

      bright_sub_common_ratio_array.reduce.length = 0;

      // 전체 밝기와 블록 밝기를 추출
      for (let line of lines) {
        line = line.trim();
        if (line.startsWith("Total image brightness:")) {
          const totalBrightString = line.split(":")[1].trim();
          totalBrightness = parseFloat(totalBrightString);
        } else if (line.startsWith("Block_")) {
          const blockBrightnessString = line.split(":")[1].trim();
          const blockBrightness = parseFloat(blockBrightnessString);
          bright_sub_common_ratio_array.push(blockBrightness);
        }
      }

      // 밝기 비율 계산
      const totalBrightRatio =
        bright_sub_common_ratio_array.reduce((acc, val) => acc + val, 0) /
        bright_sub_common_ratio_array.length;
      console.log("Total image brightness:", totalBrightness);

      for (let i = 0; i < bright_sub_common_ratio_array.length; i++) {
        console.log(`Block_${i}_brightness:`, bright_sub_common_ratio_array[i]);
      }

      // 결과를 다른 배열에 저장
      const bright_ratio_array = new Array(3).fill(0);

      // 전체 밝기와 블록 밝기 저장
      Total_bright_common_ratio_array[re_idx] = totalBrightness; // 전체 이미지 밝기 저장

      for (let i = 0; i < bright_sub_common_ratio_array.length; i++) {
        bright_ratio_array[i] = bright_sub_common_ratio_array[i]; // 밝기 값 저장
      }

      console.log("Total brightness array:", Total_bright_common_ratio_array);
      console.log(
        "brightness_sub_commonr_atio_array:",
        bright_sub_common_ratio_array
      );

      // Sample calculation to verify results
      let b_div =
        bright_sub_common_ratio_array[0] - bright_sub_common_ratio_array[2];
      console.log(
        "= A b_div b_sub00, b_sub02 =",
        b_div,
        bright_sub_common_ratio_array[0],
        bright_sub_common_ratio_array[2]
      );

      if (bright_divide === 0) {
        total_brightness_X_array = [...Total_bright_common_ratio_array];
        brightness_sub_X_ratio_array = [...bright_sub_common_ratio_array];
      } else {
        total_brightness_Y_array = [...Total_bright_common_ratio_array];
        brightness_sub_Y_ratio_array = [...bright_sub_common_ratio_array];
      }
    } catch (error) {
      console.error(`Error in cal_brightness_ratio_proc: ${error}`);
      throw error;
    }
  }
}

function AF_LW_systemData() {
  console.log("AF_LW_systemData: Start");

  const path = OPER_HOME_DIR + "led_set.dat";
  console.log(path);

  fs.readFile(path, "utf8", (err, data) => {
    if (err) {
      console.error("파일을 읽는 중 오류가 발생했습니다:", err);
      return;
    }

    // 파일 내용에서 'LW' 뒤의 숫자를 추출하는 정규식
    const lwMatch = data.match(/LW\s+(\d+)/);

    if (lwMatch) {
      LWE_Data = lwMatch[1]; // 'LW' 뒤의 첫 번째 숫자 추출
      Atuto_Retina_UniformityDataSeve();
      console.log("LW 뒤의 숫자:", LWE_Data);
    } else {
      console.log("LW 패턴을 찾을 수 없습니다.");
    }
  });
}

const execPromise = (command, timeout = 5000) => {
  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => {
      reject(new Error(`Command timed out: ${command}`));
    }, timeout);

    exec(command, (error, stdout, stderr) => {
      clearTimeout(timeoutId); // 타임아웃 해제
      if (error) {
        console.error(`Error executing command: ${error.message}`);
        return reject(new Error(`Execution failed: ${error.message}`));
      }
      if (stderr) {
        console.error(`Command returned an error: ${stderr}`);
        return reject(new Error(`Error output: ${stderr}`));
      }
      resolve(stdout);
    });
  });
};

let retina_level = 5;

function Atuto_Retina_UniformityDataSeve() {
  console.log("AutoRetinaDataSeve: Start", LWE_Data);

  // LWE_Data를 숫자로 변환 (문자열인 경우)
  LWE_Data = Number(LWE_Data);

  console.log("AutoRetinaDataSeve: Start 1", LWE_Data);
  if (LWE_Data >= 30 && LWE_Data <= 39) {
    // 31 ~ 35	: 1단계
    retina_level = 1;
    //		Auto_Loop_cnt = 4;
  } else if (LWE_Data >= 40 && LWE_Data <= 44) {
    // 36 ~ 40	: 2단계
    retina_level = 2;
    //		Auto_Loop_cnt = 5;
  } else if (LWE_Data >= 45 && LWE_Data <= 49) {
    // 41 ~ 45	: 3단계
    retina_level = 3;
    //		Auto_Loop_cnt = 5;
  } else if (LWE_Data >= 50 && LWE_Data <= 57) {
    // 46 ~ 50	: 4단계
    retina_level = 4;
    //		Auto_Loop_cnt = 5;
  } else if (LWE_Data >= 58) {
    // 51 ~ 60	: 5단계
    retina_level = 5;
    //		Auto_Loop_cnt = 5;
  } else {
    retina_level = 3;
    //		Auto_Loop_cnt = 5;
  }

  console.log("AutoRetinaDataSeve: End", LWE_Data);
}

async function Pre_ImageProcess() {
  //	console.log('= Pre_ImageProcess START =');
  log(`== Pre_ImageProcess START ==`);

  console.log("copy org_file  start before ImageProcessing.");

  const cp_org_command = `cp ${capture_pngPath} ${cp_org_pngPath}`;
  await new Promise((resolve, reject) => {
    exec(cp_org_command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error during file copy: ${error.message}`);
        reject(error);
        return;
      }
      if (stderr) {
        console.error(`copy stderr: ${stderr}`);
      }
      console.log("copy  completed.");
      resolve();
    });
  });
  console.log("copy End.");

  try {
    console.log("= Call cal_brightness_single_ratio_proc =");
    await cal_brightness_single_ratio_proc(); // All
    console.log("= total_brightness =", total_brightness);
  } catch (error) {
    console.error(`Error in cal_brightness_ratio_proc: ${error}`);
  }
  return;

  let chg_bright = 0;
  let chg_saturation = 0;
  let chg_contrast = 0;
  let chg_resolution = 3156;
  let Tuning_nedd = 1;

  /*
		if (total_brightness < 20)	{
			chg_bright = 50;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 20 && total_brightness < 30)	{	// 60 ~ 83
			chg_bright = 40;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 30 && total_brightness < 40)	{	// 60 ~ 83
			chg_bright = 30;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 40 && total_brightness < 50)	{	// 60 ~ 83
			chg_bright = 25;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 50 && total_brightness < 60)	{	// 60 ~ 83
			chg_bright = 20;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 60 && total_brightness < 70)	{	// 60 ~ 83
			chg_bright = 15;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 70 && total_brightness < 80)	{	// 60 ~ 83
			chg_bright = 8;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 80 && total_brightness < 90)	{	// 60 ~ 83
			chg_bright = 5;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 90 && total_brightness < 100)	{	// 60 ~ 83
			chg_bright = 0;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 100 && total_brightness < 105)	{
			chg_bright = -10;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 105 && total_brightness < 110)	{
			chg_bright = -15;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 110 && total_brightness < 115)	{
			chg_bright = -20;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 115 && total_brightness < 120)	{
			chg_bright = -25;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 120 && total_brightness < 125)	{
			chg_bright = -30;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 125 && total_brightness < 130)	{
			total_brightness = total_brightness - 90
			chg_bright = -35;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 130 && total_brightness < 140)	{
			chg_bright = -40;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		else if (total_brightness >= 140 && total_brightness < 150)	{
			chg_bright = -50;
			chg_contrast = 1.1;
			chg_saturation =1.1;
		}
		else if (total_brightness >= 150 && total_brightness < 160)	{
			chg_bright = -60;
			chg_contrast = 1.1;
			chg_saturation =1.1;
		}
		else if (total_brightness >= 160)	{
			chg_bright = total_brightness - 90;
			chg_contrast = 1.1;
			chg_saturation = 1.1;
		}
		*/

  if (total_brightness >= 85 && total_brightness <= 95) {
    console.log(
      "=  Do not image processing when original brightness is 85 to 95 ==:",
      total_brightness
    );
    return;
  }

  if (total_brightness < 20) {
    //	chg_bright = 30;
    chg_bright = 32;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 20 && total_brightness < 30) {
    // 60 ~ 83
    //	chg_bright = 28;
    chg_bright = 30;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 30 && total_brightness < 40) {
    // 60 ~ 83
    //	chg_bright = 26;
    chg_bright = 28;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 40 && total_brightness < 50) {
    // 60 ~ 83
    //	chg_bright = 24;
    chg_bright = 26;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 50 && total_brightness < 60) {
    // 60 ~ 83
    //	chg_bright = 20;
    chg_bright = 24;
    chg_contrast = 1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 60 && total_brightness < 70) {
    // 60 ~ 83
    //	chg_bright = 16;
    chg_bright = 20;
    chg_contrast = 1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 70 && total_brightness < 75) {
    // 60 ~ 83
    //	chg_bright = 8;
    chg_bright = 10;
    chg_contrast = 1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 75 && total_brightness < 80) {
    // 60 ~ 83
    //	chg_bright = 4;
    chg_bright = 6;
    //	chg_contrast = 1.1;
    chg_contrast = 1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 80 && total_brightness < 85) {
    // 85 ~ 95
    //	chg_bright = 2;
    chg_bright = 4;
    chg_contrast = 1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 85 && total_brightness < 90) {
    // 85 ~ 95
    //	chg_bright = 4;
    chg_bright = 2;
    chg_contrast = 1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 90 && total_brightness < 95) {
    // 85 ~ 95
    //	chg_bright = -2;
    chg_bright = 0;
    chg_contrast = 1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 95 && total_brightness <= 100) {
    // 85 ~ 95
    //	chg_bright = -6;
    chg_bright = -4;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 100 && total_brightness < 105) {
    //	chg_bright = -10;
    chg_bright = -9;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 105 && total_brightness < 110) {
    //	chg_bright = -16;
    chg_bright = -15;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 110 && total_brightness < 115) {
    //	chg_bright = -18;
    chg_bright = -17;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 115 && total_brightness < 120) {
    //	chg_bright = -20;
    chg_bright = -19;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 120 && total_brightness < 125) {
    chg_bright = -25;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 125 && total_brightness < 130) {
    chg_bright = -30;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 130 && total_brightness < 140) {
    chg_bright = -40;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 140 && total_brightness < 150) {
    chg_bright = -50;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 150 && total_brightness < 160) {
    chg_bright = -60;
    chg_contrast = 1.1;
    chg_saturation = 1.1;
  } else if (total_brightness >= 160) {
    chg_bright = -70;
    chg_contrast = 1.0;
    chg_saturation = 1.1;
  }

  console.log(
    "= Image Processing Data c_b, c_c, cs :",
    chg_bright,
    chg_contrast,
    chg_saturation
  );

  //		return;
  if (Tuning_nedd === 1) {
    try {
      await Chg_ImageDataProcess(
        chg_bright,
        chg_contrast,
        chg_saturation,
        chg_resolution
      );
    } catch (error) {
      console.error(`Error in chg_ImageDataProcess: ${error}`);
    }
  }
}

let total_brightness;

async function cal_brightness_single_ratio_proc() {
  console.log("= cal_brightness_single_ratio_proc START =");

  //	const cppExec_brightness_single_Path = '/home/nvidia/i-view100/umi_autoS1_brigtness';
  const cppExec_brightness_single_Path =
    "/home/nvidia/i-view100/umi_brightness";
  const org_BrightnessSinglePath = `/home/nvidia/i-view100/CAP/capture.png`;
  const command = `${cppExec_brightness_single_Path} ${org_BrightnessSinglePath}`;

  console.log("= Running command:", command);

  try {
    const stdout = await execPromise(command);
    console.log("Command output:", stdout); // 명령어 출력 로그 추가

    // "Brightness Single Index:" 문자열이 포함된 부분의 인덱스 찾기
    let b_ratio_index = stdout.indexOf("Average Brightness:");

    if (b_ratio_index === -1) {
      //	throw new Error(`"Cal_AvrDBright:" not found in output for b_idx: ${b_idx}`);
      throw new Error(
        `"Average Brightness:" not found in output for b_idx: ${b_idx}`
      );
    }

    // Brightness 비율 추출
    const brightsingleString = stdout.substring(b_ratio_index + 20).trim(); // "Average Brightness: "의 길이는 20
    const brightsingleRatio = parseFloat(brightsingleString);

    if (isNaN(brightsingleRatio)) {
      throw new Error(
        `"Average Brightness:" not found in output for b_idx: ${b_idx}`
      );
    }

    // Brightness Single 비율 저장
    total_brightness = brightsingleRatio;

    console.log("total_brightness", total_brightness);
  } catch (error) {
    console.error(`Error in cal_brightness_single_ratio_proc: ${error}`);
    throw error;
  }
}

async function Chg_ImageDataProcess(
  chg_bright,
  chg_contrast,
  chg_saturation,
  chg_resolution
) {
  console.log(
    "= chg_ImageDataProcess START n=",
    chg_bright,
    chg_contrast,
    chg_saturation,
    chg_resolution
  );

  const cppExeChgImgDataPath = "/home/nvidia/i-view100/umi_b_s_size_c_control4";
  const inputImagePath = "/home/nvidia/i-view100/CAP/capture.png";
  const backupImagePath = "/home/nvidia/i-view100/CAP/capture_org.png";
  const outputImagePath = "/home/nvidia/i-view100/CAP/capture.png";

  // C++ 실행 파일 호출
  const args = [
    inputImagePath, // 입력 이미지 경로
    chg_bright.toString(), // 밝기 값
    chg_contrast.toString(), // 대비 값
    chg_saturation.toString(), // 채도 비율
    chg_resolution.toString(), // 너비 값
    outputImagePath, // 출력 이미지 경로
  ];

  try {
    // Step 1: capture.png 파일을 capture_org.png로 백업
    // console.log('Checking if capture.png exists...');
    // `cp` 명령을 사용하여 파일 백업
    console.log("Backing up capture.png...");

    const cpCommand = `cp ${inputImagePath} ${backupImagePath}`;

    await new Promise((resolve, reject) => {
      exec(cpCommand, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error during file backup: ${error.message}`);
          reject(error);
          return;
        }
        if (stderr) {
          console.error(`cp stderr: ${stderr}`);
        }
        console.log("Backup completed.");
        resolve();
      });
    });

    // Step 2: C++ 실행 파일 호출
    console.log("Executing C++ program...");

    const command = `${cppExeChgImgDataPath} ${args.join(" ")}`; // C++ 실행 파일 호출
    await new Promise((resolve, reject) => {
      exec(command, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error executing C++ program: ${error.message}`);
          reject(error);
          return;
        }
        if (stderr) {
          console.error(`C++ Program stderr: ${stderr}`);
        }
        console.log(`C++ Program stdout: ${stdout}`);
        resolve();
      });
    });
  } catch (err) {
    console.error(`Unexpected error: ${err.message}`);
  }
}
